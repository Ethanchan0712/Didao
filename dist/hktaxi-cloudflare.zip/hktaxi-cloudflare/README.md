# 香港飛的叫車 App — Cloudflare Workers + D1 部署版

呢個係原版 HK Taxi App 嘅 Cloudflare 遷移版本。前端部署喺 Cloudflare Pages，後端 API 用 Hono + Cloudflare Workers，數據庫用 Cloudflare D1（SQLite-compatible）。

## 架構差異

| 原版 | Cloudflare 版 | 說明 |
|------|--------------|------|
| Express.js (Node) | Hono (Workers) | Workers 係 serverless，唔支援 Node 原生模塊 |
| better-sqlite3 (本地檔) | Cloudflare D1 | D1 係 Cloudflare 提供嘅 SQLite 服務 |
| jsonwebtoken | hono/jwt | 用 Hono 內置 JWT |
| SSE (長連接) | Polling (輪詢) | Workers 無狀態，唔支援長連接，改用 2-3s 輪詢 |
| 前端 `@lark-apaas/client-toolkit-lite` axios | 原生 fetch | 移除飛書 SDK 依賴 |
| 前端 scopedStorage | 原生 localStorage | 移除飛書 SDK 依賴 |

## 目錄結構

```
├── worker/              # Cloudflare Worker (Hono API)
│   ├── src/
│   │   ├── index.ts     # Worker 入口
│   │   └── routes/
│   │       ├── auth.ts    # 註冊 / 登入
│   │       ├── orders.ts  # 訂單 CRUD + 狀態流轉
│   │       ├── chat.ts    # 車內對話
│   │       └── admin.ts   # 後台管理
│   ├── wrangler.toml    # Worker 配置
│   ├── tsconfig.json
│   └── package.json
│
├── frontend/            # Cloudflare Pages (React + Vite)
│   ├── src/             # 前端源碼（從原版修改）
│   ├── wrangler.toml    # Pages 配置
│   ├── vite.config.ts
│   └── package.json
│
└── migrations/          # D1 數據庫遷移
    └── 0001_init.sql    # 初始 schema + seed admin
```

## 部署步驟

### 0. 前置準備

```bash
# 安裝 wrangler CLI
npm install -g wrangler

# 登入 Cloudflare
wrangler login
```

### 1. 建立 D1 數據庫

```bash
# 建立數據庫
wrangler d1 create hktaxi-db

# 將返返嚟嘅 database_id 填入 worker/wrangler.toml
```

### 2. 執行數據庫遷移

```bash
cd worker

# 本地開發用
wrangler d1 migrations apply hktaxi-db --local

# 生產環境
wrangler d1 migrations apply hktaxi-db
```

> 管理員預設帳號：`admin / lovevivi815`（首次 migration 自動 seed）

### 3. 部署 Worker (後端 API)

```bash
cd worker
npm install

# 本地開發
npm run dev

# 部署到 Cloudflare
npm run deploy
```

部署完成後會得到一個 `*.workers.dev` 域名，例如 `https://hktaxi-api.yourname.workers.dev`。

### 4. 部署前端 (Pages)

```bash
cd frontend
npm install

# 建立 .env.local，填入 Worker API 地址
echo 'VITE_API_URL=https://hktaxi-api.yourname.workers.dev/api' > .env.local

# 本地開發
npm run dev

# 構建
npm run build

# 部署到 Cloudflare Pages
npm run deploy
```

### 5. 配置 CORS

部署完成後，喺 `worker/wrangler.toml` 將 `FRONTEND_ORIGIN` 改成你 Pages 嘅域名，再 redeploy worker：

```toml
[vars]
FRONTEND_ORIGIN = "https://your-app.pages.dev"
JWT_SECRET = "請改為一長串隨機字符"
```

> ⚠️ **生產環境一定要改 `JWT_SECRET`**，唔可以用預設值。

## API 一覽

所有 API 都喺 `/api` 前綴下。

### Auth
- `POST /api/auth/passenger/register` — 乘客註冊
- `POST /api/auth/passenger/login` — 乘客登入
- `GET  /api/auth/passenger/me` — 乘客資料
- `POST /api/auth/driver/register` — 司機註冊
- `POST /api/auth/driver/login` — 司機登入
- `GET  /api/auth/driver/me` — 司機資料
- `POST /api/auth/admin/login` — 管理員登入

### Orders
- `POST /api/orders/passenger/request` — 乘客叫車
- `POST /api/orders/passenger/cancel` — 取消叫車
- `GET  /api/orders/passenger/current` — 乘客當前訂單
- `GET  /api/orders/passenger/history` — 乘客歷史訂單
- `POST /api/orders/passenger/rate` — 乘客評分司機
- `POST /api/orders/passenger/pay` — 乘客付款
- `POST /api/orders/passenger/location` — 更新乘客位置
- `GET  /api/orders/driver/hall` — 司機接單大廳
- `POST /api/orders/driver/accept/:orderId` — 司機接單
- `POST /api/orders/driver/reject/:orderId` — 司機拒單
- `GET  /api/orders/driver/current` — 司機當前訂單
- `POST /api/orders/driver/arrive-pickup` — 到達上車點
- `POST /api/orders/driver/complete` — 完成行程
- `GET  /api/orders/driver/earnings` — 司機收入記錄
- `POST /api/orders/driver/rate` — 司機評分乘客
- `POST /api/orders/driver/online` — 司機上線/落線
- `POST /api/orders/driver/location` — 更新司機位置
- `GET  /api/orders/:id` — 訂單詳情

### Chat
- `POST /api/chat/passenger/send` — 乘客發訊息
- `POST /api/chat/driver/send` — 司機發訊息
- `GET  /api/chat/order/:orderId` — 訂單訊息列表

### Admin
- `GET  /api/admin/stats` — 統計數據
- `GET  /api/admin/drivers` — 司機申請列表
- `POST /api/admin/drivers/:id/approve` — 批准司機
- `POST /api/admin/drivers/:id/reject` — 拒絕司機
- `GET  /api/admin/orders` — 訂單列表

## Polling 同步機制

原版用 SSE（Server-Sent Events）做實時同步，但 Cloudflare Workers 係無狀態 request-response 模型，唔支援長連接。

Cloudflare 版改用 **輪詢（Polling）** 實現：

- **訂單狀態同步**：前端每 2 秒 call 一次 `GET /orders/:id`，偵測 status 變化
- **司機大廳新單**：前端每 3 秒 call 一次 `GET /orders/driver/hall`，偵測新訂單
- **位置同步**：司機端每 2 秒 POST 一次位置，乘客端輪詢訂單詳情獲取最新位置

如果需要更強嘅實時性，可以考慮：
- Cloudflare Durable Objects（有狀態 Worker）
- Cloudflare Pub/Sub
- Pusher / Ably 等第三方服務

## 已知限制

1. **唔支援 SSE/WebSocket** — 已用 polling 替代
2. **無原生 Node.js 模塊** — 已用 Hono 生態替代（jwt、cors 等）
3. **D1 有讀寫次數限制** — 免費 plan 有 5M reads / 100k writes 每日，足夠原型測試
4. **`bcryptjs` 純 JS 版本** — Workers 可跑，比原生慢少少，但註冊/登入場景 acceptable

## 遷移清單 (Checklist)

- [ ] 建立 Cloudflare 帳號同 Workers 計劃
- [ ] `wrangler login` 登入
- [ ] `wrangler d1 create hktaxi-db` 建立數據庫
- [ ] 將 `database_id` 填入 `worker/wrangler.toml`
- [ ] 改 `JWT_SECRET` 做隨機長字符串
- [ ] `wrangler d1 migrations apply hktaxi-db` 執行 migration
- [ ] `cd worker && npm install && npm run deploy` 部署後端
- [ ] 將 Worker 域名填入 `frontend/.env.local` 嘅 `VITE_API_URL`
- [ ] `cd frontend && npm install && npm run deploy` 部署前端
- [ ] 將 Pages 域名填入 `worker/wrangler.toml` 嘅 `FRONTEND_ORIGIN`
- [ ] Redeploy worker
- [ ] 測試：註冊乘客 → 叫車 → 註冊司機 → 管理員批准 → 司機接單 → 完成行程 → 付款 → 評分
