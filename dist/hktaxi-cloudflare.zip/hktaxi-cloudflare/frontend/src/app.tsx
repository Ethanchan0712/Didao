import { Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import NotFoundPage from '@/pages/NotFoundPage/NotFoundPage';
import WelcomePage from '@/pages/WelcomePage/WelcomePage';
import PassengerHomePage from '@/pages/PassengerHomePage/PassengerHomePage';
import PassengerWaitingPage from '@/pages/PassengerWaitingPage/PassengerWaitingPage';
import PassengerRidingPage from '@/pages/PassengerRidingPage/PassengerRidingPage';
import PassengerPaymentPage from '@/pages/PassengerPaymentPage/PassengerPaymentPage';
import PassengerRatingPage from '@/pages/PassengerRatingPage/PassengerRatingPage';
import PassengerHistoryPage from '@/pages/PassengerHistoryPage/PassengerHistoryPage';
import PassengerProfilePage from '@/pages/PassengerProfilePage/PassengerProfilePage';
import DriverHallPage from '@/pages/DriverHallPage/DriverHallPage';
import DriverRidingPage from '@/pages/DriverRidingPage/DriverRidingPage';
import DriverRatingPage from '@/pages/DriverRatingPage/DriverRatingPage';
import DriverEarningsPage from '@/pages/DriverEarningsPage/DriverEarningsPage';
import DriverProfilePage from '@/pages/DriverProfilePage/DriverProfilePage';
import DriverVerifyPage from '@/pages/DriverVerifyPage/DriverVerifyPage';
import AdminPage from '@/pages/AdminPage/AdminPage';
import AdminLoginPage from '@/pages/AdminLoginPage/AdminLoginPage';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<WelcomePage />} />

        {/* Passenger side */}
        <Route path="passenger" element={<PassengerHomePage />} />
        <Route path="passenger/waiting" element={<PassengerWaitingPage />} />
        <Route path="passenger/riding" element={<PassengerRidingPage />} />
        <Route path="passenger/payment" element={<PassengerPaymentPage />} />
        <Route path="passenger/rating" element={<PassengerRatingPage />} />
        <Route path="passenger/history" element={<PassengerHistoryPage />} />
        <Route path="passenger/profile" element={<PassengerProfilePage />} />

        {/* Driver side */}
        <Route path="driver" element={<DriverHallPage />} />
        <Route path="driver/riding" element={<DriverRidingPage />} />
        <Route path="driver/rating" element={<DriverRatingPage />} />
        <Route path="driver/earnings" element={<DriverEarningsPage />} />
        <Route path="driver/profile" element={<DriverProfilePage />} />
        <Route path="driver/verify" element={<DriverVerifyPage />} />

        {/* Admin side */}
        <Route path="admin/login" element={<AdminLoginPage />} />
        <Route path="admin" element={<AdminPage />} />

        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
}
