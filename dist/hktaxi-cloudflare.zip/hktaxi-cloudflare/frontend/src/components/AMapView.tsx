import { useEffect, useRef, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { MOCK_LANDMARKS } from '@/data/landmarks';
import type { IDriver } from '@/data/drivers';

interface AMapViewProps {
  pickupName?: string;
  destinationName?: string;
  pickupLat?: number;
  pickupLng?: number;
  destLat?: number;
  destLng?: number;
  driverLat?: number;
  driverLng?: number;
  passengerLat?: number;
  passengerLng?: number;
  nearbyDrivers?: IDriver[];
  showRoute?: boolean;
  routePath?: Array<[number, number]>; // [lng, lat] pairs
  height?: string;
  centerLat?: number;
  centerLng?: number;
  zoom?: number;
}

const AMAP_KEY = '75e09e701f85fabf849e5ff5ef36c01f';
const AMAP_SECURITY_CODE = ''; // 可选：安全密钥，冇就留空

let amapLoadPromise: Promise<typeof window.AMap> | null = null;

function loadAMap(): Promise<typeof window.AMap> {
  if (amapLoadPromise) return amapLoadPromise;

  amapLoadPromise = new Promise((resolve, reject) => {
    // 已經 load 咗
    if (window.AMap) {
      resolve(window.AMap);
      return;
    }

    // 安全碼配置（如果有）
    if (AMAP_SECURITY_CODE) {
      (window as any)._AMapSecurityConfig = {
        securityJsCode: AMAP_SECURITY_CODE,
      };
    }

    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.src = `https://webapi.amap.com/maps?v=2.0&key=${AMAP_KEY}&plugin=AMap.Driving,AMap.AutoComplete,AMap.PlaceSearch,AMap.Geocoder`;
    script.onerror = () => {
      reject(new Error('地圖載入失敗，請檢查網絡或域名權限'));
    };
    script.onload = () => {
      if (window.AMap) {
        resolve(window.AMap);
      } else {
        reject(new Error('地圖 SDK 初始化失敗'));
      }
    };
    document.head.appendChild(script);
  });

  return amapLoadPromise;
}

export default function AMapView({
  pickupName,
  destinationName,
  pickupLat,
  pickupLng,
  destLat,
  destLng,
  driverLat,
  driverLng,
  passengerLat,
  passengerLng,
  nearbyDrivers = [],
  showRoute = false,
  routePath,
  height = 'auto',
  centerLat,
  centerLng,
  zoom = 13,
}: AMapViewProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markersRef = useRef<Record<string, any>>({});
  const routeLineRef = useRef<any>(null);
  const [loadError, setLoadError] = useState<string>('');
  const [isReady, setIsReady] = useState(false);

  // 初始化地圖
  useEffect(() => {
    let cancelled = false;

    loadAMap()
      .then((AMap) => {
        if (cancelled || !mapContainerRef.current) return;
        if (mapRef.current) return; // 已經初始化

        // 如果有 pickup 坐標就用坐標做中心，否則睇名稱搵地標
        let lat = centerLat ?? 22.3080;
        let lng = centerLng ?? 114.1729;

        if (pickupLat !== undefined && pickupLng !== undefined) {
          lat = pickupLat;
          lng = pickupLng;
        } else {
          const pickup = pickupName
            ? MOCK_LANDMARKS.find((l) => l.name === pickupName)
            : undefined;
          if (pickup) {
            lat = pickup.lat;
            lng = pickup.lng;
          }
        }

        mapRef.current = new AMap.Map(mapContainerRef.current, {
          zoom,
          center: [lng, lat],
          mapStyle: 'amap://styles/darkblue',
          viewMode: '2D',
          resizeEnable: true,
        });

        setIsReady(true);
      })
      .catch((err) => {
        if (!cancelled) {
          setLoadError(err.message || '地圖載入失敗');
        }
      });

    return () => {
      cancelled = true;
    };
  }, []);

  // 更新地圖中心同縮放
  useEffect(() => {
    if (!isReady || !mapRef.current) return;

    let pLat: number | undefined;
    let pLng: number | undefined;
    let dLat: number | undefined;
    let dLng: number | undefined;

    if (pickupLat !== undefined && pickupLng !== undefined) {
      pLat = pickupLat;
      pLng = pickupLng;
    } else if (pickupName) {
      const p = MOCK_LANDMARKS.find((l) => l.name === pickupName);
      if (p) { pLat = p.lat; pLng = p.lng; }
    }

    if (destLat !== undefined && destLng !== undefined) {
      dLat = destLat;
      dLng = destLng;
    } else if (destinationName) {
      const d = MOCK_LANDMARKS.find((l) => l.name === destinationName);
      if (d) { dLat = d.lat; dLng = d.lng; }
    }

    if (pLat !== undefined && dLat !== undefined && showRoute) {
      const bounds = new window.AMap!.Bounds(
        [Math.min(pLng, dLng) - 0.005, Math.min(pLat, dLat) - 0.005],
        [Math.max(pLng, dLng) + 0.005, Math.max(pLat, dLat) + 0.005],
      );
      mapRef.current.setBounds(bounds, false, [40, 40, 40, 40]);
    } else if (pLat !== undefined) {
      mapRef.current.setZoomAndCenter(zoom, [pLng, pLat]);
    } else if (centerLat !== undefined && centerLng !== undefined) {
      mapRef.current.setZoomAndCenter(zoom, [centerLng, centerLat]);
    }
  }, [isReady, pickupName, destinationName, pickupLat, pickupLng, destLat, destLng, showRoute, centerLat, centerLng, zoom]);

  // 上車點 marker
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    if (markersRef.current.pickup) {
      mapRef.current.remove(markersRef.current.pickup);
      delete markersRef.current.pickup;
    }

    let lat: number | undefined;
    let lng: number | undefined;

    if (pickupLat !== undefined && pickupLng !== undefined) {
      lat = pickupLat;
      lng = pickupLng;
    } else if (pickupName) {
      const pickup = MOCK_LANDMARKS.find((l) => l.name === pickupName);
      if (pickup) { lat = pickup.lat; lng = pickup.lng; }
    }

    if (lat !== undefined && lng !== undefined) {
      const marker = new window.AMap.Marker({
        position: [lng, lat],
        title: `上車點：${pickupName || ''}`,
        icon: new window.AMap.Icon({
          image: 'https://webapi.amap.com/theme/v1.3/markers/n/start.png',
          size: new window.AMap.Size(25, 34),
          imageSize: new window.AMap.Size(25, 34),
        }),
        offset: new window.AMap.Pixel(-12, -34),
        zIndex: 100,
      });
      marker.setMap(mapRef.current);
      markersRef.current.pickup = marker;
    }
  }, [isReady, pickupName, pickupLat, pickupLng]);

  // 目的地 marker
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    if (markersRef.current.destination) {
      mapRef.current.remove(markersRef.current.destination);
      delete markersRef.current.destination;
    }

    let lat: number | undefined;
    let lng: number | undefined;

    if (destLat !== undefined && destLng !== undefined) {
      lat = destLat;
      lng = destLng;
    } else if (destinationName) {
      const dest = MOCK_LANDMARKS.find((l) => l.name === destinationName);
      if (dest) { lat = dest.lat; lng = dest.lng; }
    }

    if (lat !== undefined && lng !== undefined) {
      const marker = new window.AMap.Marker({
        position: [lng, lat],
        title: `目的地：${destinationName || ''}`,
        icon: new window.AMap.Icon({
          image: 'https://webapi.amap.com/theme/v1.3/markers/n/end.png',
          size: new window.AMap.Size(25, 34),
          imageSize: new window.AMap.Size(25, 34),
        }),
        offset: new window.AMap.Pixel(-12, -34),
        zIndex: 100,
      });
      marker.setMap(mapRef.current);
      markersRef.current.destination = marker;
    }
  }, [isReady, destinationName, destLat, destLng]);

  // 附近司機 markers
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    // 清舊嘅
    if (markersRef.current.nearbyDrivers) {
      markersRef.current.nearbyDrivers.forEach((m: any) => {
        mapRef.current.remove(m);
      });
      delete markersRef.current.nearbyDrivers;
    }

    if (nearbyDrivers.length === 0) return;

    const drivers = nearbyDrivers.map((d) => {
      const marker = new window.AMap.Marker({
        position: [d.currentLng, d.currentLat],
        title: d.name,
        content: `
          <div style="
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: #ef4444;
            border: 2px solid #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
          ">
            <span style="font-size: 14px;">🚕</span>
          </div>
        `,
        offset: new window.AMap.Pixel(-14, -14),
        zIndex: 50,
      });
      marker.setMap(mapRef.current);
      return marker;
    });

    markersRef.current.nearbyDrivers = drivers;
  }, [isReady, nearbyDrivers]);

  // 接單司機位置 marker
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    if (markersRef.current.driver) {
      mapRef.current.remove(markersRef.current.driver);
      delete markersRef.current.driver;
    }

    if (driverLat !== undefined && driverLng !== undefined) {
      const marker = new window.AMap.Marker({
        position: [driverLng, driverLat],
        title: '你的司機',
        content: `
          <div style="
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #ef4444;
            border: 3px solid #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 12px rgba(239,68,68,0.5);
            animation: pulse 2s infinite;
          ">
            <span style="font-size: 16px;">🚕</span>
          </div>
        `,
        offset: new window.AMap.Pixel(-18, -18),
        zIndex: 150,
      });
      marker.setMap(mapRef.current);
      markersRef.current.driver = marker;
    }
  }, [isReady, driverLat, driverLng]);

  // 乘客位置 marker（藍色，同司機紅色區分）
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    if (markersRef.current.passenger) {
      mapRef.current.remove(markersRef.current.passenger);
      delete markersRef.current.passenger;
    }

    if (passengerLat !== undefined && passengerLng !== undefined) {
      const marker = new window.AMap.Marker({
        position: [passengerLng, passengerLat],
        title: '乘客位置',
        content: `
          <div style="
            width: 32px;
            height: 32px;
            border-radius: 50%;
            background: #3b82f6;
            border: 3px solid #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 2px 10px rgba(59,130,246,0.5);
            animation: pulse 2s infinite;
          ">
            <span style="font-size: 14px;">👤</span>
          </div>
        `,
        offset: new window.AMap.Pixel(-16, -16),
        zIndex: 120,
      });
      marker.setMap(mapRef.current);
      markersRef.current.passenger = marker;
    }
  }, [isReady, passengerLat, passengerLng]);

  // 路線 polyline
  useEffect(() => {
    if (!isReady || !mapRef.current || !window.AMap) return;

    // 清舊線
    if (routeLineRef.current) {
      mapRef.current.remove(routeLineRef.current);
      routeLineRef.current = null;
    }

    if (!showRoute) return;

    // 優先用傳入嘅真實路徑
    if (routePath && routePath.length > 1) {
      const path = routePath.map(([lng, lat]) => [lng, lat]);
      const polyline = new window.AMap.Polyline({
        path,
        strokeColor: '#ef4444',
        strokeWeight: 5,
        strokeOpacity: 0.8,
        lineJoin: 'round',
        zIndex: 80,
      });
      polyline.setMap(mapRef.current);
      routeLineRef.current = polyline;
      return;
    }

    // 冇真實路徑嘅話，用駕駛路線規劃
    let pLat: number | undefined;
    let pLng: number | undefined;
    let dLat: number | undefined;
    let dLng: number | undefined;

    if (pickupLat !== undefined && pickupLng !== undefined) {
      pLat = pickupLat; pLng = pickupLng;
    } else if (pickupName) {
      const p = MOCK_LANDMARKS.find((l) => l.name === pickupName);
      if (p) { pLat = p.lat; pLng = p.lng; }
    }

    if (destLat !== undefined && destLng !== undefined) {
      dLat = destLat; dLng = destLng;
    } else if (destinationName) {
      const d = MOCK_LANDMARKS.find((l) => l.name === destinationName);
      if (d) { dLat = d.lat; dLng = d.lng; }
    }

    if (pLat !== undefined && dLat !== undefined && window.AMap.Driving) {
      const driving = new window.AMap.Driving({
        map: mapRef.current,
        panel: null,
        hideMarkers: true,
        autoFitView: false,
        strokeColor: '#ef4444',
        strokeWeight: 5,
        strokeOpacity: 0.8,
      });

      driving.search(
        [pLng, pLat],
        [dLng, dLat],
        (status: string, result: any) => {
          if (status === 'complete' && result.routes?.[0]) {
            routeLineRef.current = driving;
          }
        },
      );
    }
  }, [isReady, showRoute, routePath, pickupName, destinationName, pickupLat, pickupLng, destLat, destLng]);

  // 清理
  useEffect(() => {
    return () => {
      if (mapRef.current) {
        mapRef.current.destroy?.();
        mapRef.current = null;
      }
      markersRef.current = {};
      routeLineRef.current = null;
    };
  }, []);

  // 加載失敗顯示
  if (loadError) {
    return (
      <div
        className={`relative w-full overflow-hidden rounded-2xl border border-slate-200/60 flex items-center justify-center bg-slate-900 ${height === 'auto' ? 'h-64' : height}`}
      >
        <div className="text-center px-6">
          <div className="size-12 rounded-full bg-red-500/10 flex items-center justify-center mx-auto mb-3">
            <AlertTriangle className="size-6 text-red-500" />
          </div>
          <p className="text-sm font-medium text-white mb-1">地圖暫時無法顯示</p>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">{loadError}</p>
          <p className="text-xs text-slate-500 mt-3">
            可能原因：域名未加入高德 Key 白名單、或網絡限制
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={mapContainerRef}
      className={`relative w-full overflow-hidden rounded-2xl border border-slate-200/60 bg-slate-800 ${height === 'auto' ? 'h-64' : height}`}
      style={{ minHeight: '200px' }}
    >
      {!isReady && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900 z-10">
          <div className="text-center">
            <div className="size-8 border-2 border-white/20 border-t-primary rounded-full animate-spin mx-auto mb-2" />
            <p className="text-xs text-slate-400">載入地圖中...</p>
          </div>
        </div>
      )}
    </div>
  );
}
