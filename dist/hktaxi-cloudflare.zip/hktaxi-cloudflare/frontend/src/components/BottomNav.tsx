import { NavLink } from 'react-router-dom';
import { Home, Clock, User, Car, Wallet } from 'lucide-react';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';

interface BottomNavProps {
  role: 'passenger' | 'driver';
}

export default function BottomNav({ role }: BottomNavProps) {
  const { order } = useOrder();
  const { t } = useI18n();

  const passengerItems = [
    { path: '/passenger', label: t.nav.passengerHome, icon: Home },
    { path: '/passenger/history', label: t.nav.passengerHistory, icon: Clock },
    { path: '/passenger/profile', label: t.nav.passengerProfile, icon: User },
  ];

  const driverItems = [
    { path: '/driver', label: t.nav.driverHome, icon: Car },
    { path: '/driver/earnings', label: t.nav.driverEarnings, icon: Wallet },
    { path: '/driver/profile', label: t.nav.driverProfile, icon: User },
  ];

  const items = role === 'passenger' ? passengerItems : driverItems;

  // Hide bottom nav during active order flow (secondary pages)
  const isSecondary =
    order &&
    order.status !== 'idle' &&
    order.status !== 'finished';

  if (isSecondary) return null;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/90 backdrop-blur-lg border-t border-slate-200/60 pb-[env(safe-area-inset-bottom)]">
      <div className="max-w-md mx-auto flex items-center justify-around h-16">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/passenger' || item.path === '/driver'}
              className={({ isActive }) =>
                `flex flex-col items-center gap-1 px-4 py-2 transition-colors ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`
              }
            >
              <Icon className="size-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}
