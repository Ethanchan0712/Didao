import { useState, useRef, useEffect, useCallback, type FormEvent } from 'react';
import { X, Send, Phone, PhoneOff, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';
import { useOrder } from '@/lib/order-context';
import { logger } from '@lark-apaas/client-toolkit-lite';

interface ChatSheetProps {
  open: boolean;
  onClose: () => void;
  /** 當前角色：乘客 or 司機，決定訊息顯示喺左定右 */
  role: 'passenger' | 'driver';
  /** 對方嘅名稱，顯示喺頂部 */
  otherName: string;
  /** 對方嘅圖片（可選），冇就用首字母 */
  otherAvatar?: string;
}

export default function ChatSheet({ open, onClose, role, otherName, otherAvatar }: ChatSheetProps) {
  const { order, sendOrderMessage } = useOrder();
  const [inputValue, setInputValue] = useState('');
  const [showCallDialog, setShowCallDialog] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const listRef = useRef<HTMLDivElement>(null);
  const callTimerRef = useRef<number | null>(null);

  const messages = order?.messages ?? [];

  // 自動滾到底
  useEffect(() => {
    if (listRef.current) {
      listRef.current.scrollTop = listRef.current.scrollHeight;
    }
  }, [messages.length, open]);

  // 關閉時清輸入
  useEffect(() => {
    if (!open) {
      setInputValue('');
      setShowCallDialog(false);
      if (callTimerRef.current) {
        window.clearInterval(callTimerRef.current);
        callTimerRef.current = null;
      }
      setCallDuration(0);
    }
  }, [open]);

  const handleSend = useCallback(
    (e: FormEvent) => {
      e.preventDefault();
      const text = inputValue.trim();
      if (!text || !order) return;
      try {
        sendOrderMessage(text, role);
        setInputValue('');
      } catch (err) {
        logger.error('sendOrderMessage failed:', String(err));
        toast.error('訊息發送失敗，請重試');
      }
    },
    [inputValue, order, role, sendOrderMessage]
  );

  // 快捷訊息
  const quickReplies =
    role === 'passenger'
      ? ['我嚟到啦', '仲要等幾耐？', '麻煩你快少少', '我有大件行李']
      : ['我就到', '請係路邊等', '已經到咗', '塞車遲少少'];

  const sendQuick = (text: string) => {
    if (!order) return;
    sendOrderMessage(text, role);
  };

  // 模擬致電
  const handleCall = () => {
    setShowCallDialog(true);
    setCallDuration(0);
    toast.info(`正在致電 ${otherName}...`);
    callTimerRef.current = window.setInterval(() => {
      setCallDuration((d) => d + 1);
    }, 1000);
  };

  const handleHangUp = () => {
    if (callTimerRef.current) {
      window.clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    setShowCallDialog(false);
    toast.success('通話已結束');
  };

  const formatDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const otherInitial = otherName?.slice(0, 1) ?? '?';

  return (
    <>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={onClose}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="w-full bg-white rounded-t-3xl max-h-[80vh] flex flex-col"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="p-4 border-b border-slate-100 flex items-center gap-3">
                <div className="size-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 font-bold text-primary">
                  {otherInitial}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-semibold text-foreground text-sm">{otherName}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <span className="size-1.5 rounded-full bg-green-500" />
                    在線
                  </div>
                </div>
                <button
                  onClick={handleCall}
                  className="size-9 rounded-full bg-green-50 flex items-center justify-center hover:bg-green-100 transition-colors shrink-0"
                  aria-label="致電"
                >
                  <Phone className="size-4 text-green-600" />
                </button>
                <button
                  onClick={onClose}
                  className="size-9 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors shrink-0"
                  aria-label="關閉"
                >
                  <X className="size-4 text-slate-500" />
                </button>
              </div>

              {/* Messages */}
              <div ref={listRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50/50">
                {messages.length === 0 && (
                  <div className="text-center py-8">
                    <div className="size-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-2">
                      <MessageCircle className="size-6 text-slate-400" />
                    </div>
                    <div className="text-xs text-muted-foreground">
                      仲未有訊息，send 個 hi 打招呼啦
                    </div>
                  </div>
                )}
                {messages.map((msg) => {
                  const isMine = msg.from === role;
                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${
                          isMine
                            ? 'bg-primary text-white rounded-br-md'
                            : 'bg-white border border-slate-200 text-foreground rounded-bl-md'
                        }`}
                      >
                        <div className="leading-relaxed break-words">{msg.text}</div>
                        <div
                          className={`text-[10px] mt-1 ${
                            isMine ? 'text-white/70' : 'text-muted-foreground'
                          }`}
                        >
                          {new Date(msg.timestamp).toLocaleTimeString('zh-HK', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Quick replies */}
              <div className="px-3 pt-2 flex gap-2 overflow-x-auto no-scrollbar">
                {quickReplies.map((q) => (
                  <button
                    key={q}
                    onClick={() => sendQuick(q)}
                    className="shrink-0 px-3 py-1.5 rounded-full bg-white border border-slate-200 text-xs text-foreground hover:bg-slate-50 hover:border-slate-300 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>

              {/* Input */}
              <form onSubmit={handleSend} className="p-3 border-t border-slate-100 flex items-center gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder="輸入訊息..."
                  className="flex-1 h-10 px-4 rounded-full bg-slate-100 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30 focus:bg-white transition-all"
                />
                <button
                  type="submit"
                  disabled={!inputValue.trim()}
                  className="size-10 rounded-full bg-primary flex items-center justify-center text-white shrink-0 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-primary/90 transition-colors"
                  aria-label="發送"
                >
                  <Send className="size-4" />
                </button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 通話中 Dialog */}
      <AnimatePresence>
        {showCallDialog && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md flex items-center justify-center"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="text-center text-white"
            >
              <div className="size-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-5 animate-pulse">
                <div className="size-16 rounded-full bg-green-500/30 flex items-center justify-center">
                  <Phone className="size-7 text-green-400" />
                </div>
              </div>
              <div className="text-lg font-semibold mb-1">{otherName}</div>
              <div className="text-sm text-white/60 mb-1">
                {callDuration === 0 ? '正在呼叫...' : '通話中'}
              </div>
              {callDuration > 0 && (
                <div className="text-xs text-white/50 tabular-nums mb-6">
                  {formatDuration(callDuration)}
                </div>
              )}
              {callDuration === 0 && <div className="h-6 mb-6" />}
              <button
                onClick={handleHangUp}
                className="size-14 rounded-full bg-red-500 flex items-center justify-center mx-auto hover:bg-red-600 transition-colors shadow-lg shadow-red-500/30"
                aria-label="掛線"
              >
                <PhoneOff className="size-6 text-white" />
              </button>
              <div className="text-xs text-white/40 mt-2">掛線</div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
