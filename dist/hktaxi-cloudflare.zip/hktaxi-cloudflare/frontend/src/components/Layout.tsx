import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { OrderProvider, useOrder } from '@/lib/order-context';
import { ThemeProvider, useTheme } from '@/lib/theme-context';
import { I18nProvider, useI18n } from '@/lib/i18n';
import BottomNav from '@/components/BottomNav';
import ThemeSwitcher from '@/components/ThemeSwitcher';
import { Car, Globe } from 'lucide-react';
import { useState } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { useIsMobile } from '@/hooks/use-mobile';

function AppShell() {
  const location = useLocation();
  const navigate = useNavigate();
  const { currentRole, setCurrentRole } = useOrder();
  const { t, lang, setLang } = useI18n();
  const { theme } = useTheme();
  const isMobile = useIsMobile();
  const [langSheetOpen, setLangSheetOpen] = useState(false);

  const isPassengerSide = location.pathname.startsWith('/passenger');
  const isDriverSide = location.pathname.startsWith('/driver');
  const isWelcome = location.pathname === '/' || location.pathname === '';
  const isAdmin = location.pathname.startsWith('/admin');

  // 歡迎頁同管理員頁唔顯示底部導航同頂部切換
  if (isWelcome || isAdmin) {
    return <Outlet />;
  }

  const role: 'passenger' | 'driver' = isDriverSide ? 'driver' : 'passenger';

  // 顯示頂 bar（主頁 + profile + history / earnings 等一級頁）
  const showTopBar =
    location.pathname === '/passenger' ||
    location.pathname === '/driver' ||
    location.pathname === '/passenger/history' ||
    location.pathname === '/passenger/profile' ||
    location.pathname === '/driver/earnings' ||
    location.pathname === '/driver/profile';

  return (
    <div className="min-h-screen bg-background">
      {showTopBar && (
        <div className="fixed top-0 left-0 right-0 z-50 pt-3 px-4">
          <div className="max-w-md mx-auto flex items-center gap-2">
            {/* 版本切換（紅的／綠的）*/}
            <div className="flex-1">
              <ThemeSwitcher />
            </div>
            {/* 語言切換 */}
            <Sheet open={langSheetOpen} onOpenChange={setLangSheetOpen}>
              <SheetTrigger asChild>
                <button
                  className="size-10 rounded-full bg-card/95 backdrop-blur border border-border flex items-center justify-center hover:bg-muted transition-colors shadow-sm shrink-0"
                  aria-label="Language"
                >
                  <Globe className="size-4 text-muted-foreground" />
                </button>
              </SheetTrigger>
              <SheetContent side="bottom" className="rounded-t-3xl pb-8">
                <SheetHeader>
                  <SheetTitle>{t.language.title}</SheetTitle>
                </SheetHeader>
                <div className="px-5 pt-4 space-y-2">
                  {(['zh-Hant', 'en', 'ja'] as const).map((l) => (
                    <button
                      key={l}
                      onClick={() => {
                        setLang(l);
                        setLangSheetOpen(false);
                      }}
                      className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                        lang === l
                          ? 'border-primary bg-primary/5'
                          : 'border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <span className={`font-medium ${lang === l ? 'text-primary' : 'text-foreground'}`}>
                        {t.language[l === 'zh-Hant' ? 'zhHant' : l]}
                      </span>
                      {lang === l && (
                        <div className="size-5 rounded-full bg-primary flex items-center justify-center">
                          <svg className="size-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                      )}
                    </button>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      )}
      <main className={showTopBar ? 'pt-16' : ''}>
        <Outlet />
      </main>
      {(isPassengerSide || isDriverSide) && <BottomNav role={role} />}
    </div>
  );
}

export const Layout = () => {
  return (
    <ThemeProvider>
      <I18nProvider>
        <OrderProvider>
          <AppShell />
        </OrderProvider>
      </I18nProvider>
    </ThemeProvider>
  );
};
