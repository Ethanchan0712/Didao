import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Search, MapPin, Loader2, AlertTriangle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { MOCK_LANDMARKS } from '@/data/landmarks';
import { useTheme } from '@/lib/theme-context';
import { scToTc, tcToSc } from '@/lib/sc-tc';

export interface PoiResult {
  name: string;
  address: string;
  lat: number;
  lng: number;
  district?: string;
}

interface LocationSearchSheetProps {
  open: boolean;
  title: string;
  onClose: () => void;
  onSelect: (poi: PoiResult) => void;
  defaultCity?: string;
}

export default function LocationSearchSheet({
  open,
  title,
  onClose,
  onSelect,
  defaultCity = '香港',
}: LocationSearchSheetProps) {
  const [keyword, setKeyword] = useState('');
  const [poiResults, setPoiResults] = useState<PoiResult[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  const autoCompleteRef = useRef<any>(null);
  const timerRef = useRef<number | null>(null);

  // 初始化高德 AutoComplete
  const initAutoComplete = useCallback(() => {
    if (!window.AMap) return false;
    if (autoCompleteRef.current) return true;

    try {
      autoCompleteRef.current = new window.AMap.AutoComplete({
        city: defaultCity,
        citylimit: false,
      });
      return true;
    } catch {
      return false;
    }
  }, [defaultCity]);

  // 高德 POI 搜尋（防抖），支持簡體自動轉繁體
  const searchPoi = useCallback(
    (text: string) => {
      const trimmed = text.trim();
      if (!trimmed) {
        setPoiResults([]);
        setIsSearching(false);
        return;
      }

      // 簡體自動轉繁體再搜尋
      const tcText = scToTc(trimmed);

      if (timerRef.current) window.clearTimeout(timerRef.current);
      setIsSearching(true);
      setSearchError('');

      timerRef.current = window.setTimeout(() => {
        const ready = initAutoComplete();
        if (!ready || !autoCompleteRef.current) {
          setSearchError('地圖服務暫未就緒');
          setIsSearching(false);
          return;
        }

        // 用繁體字搜尋
        autoCompleteRef.current.search(tcText, (status: string, result: any) => {
          setIsSearching(false);
          if (status === 'complete' && result.tips?.length) {
            const tips: PoiResult[] = result.tips
              .filter((t: any) => t.location && t.location.lat && t.location.lng)
              .map((t: any) => ({
                name: t.name,
                address: t.address || t.district || '',
                lat: Number(t.location.lat),
                lng: Number(t.location.lng),
                district: t.district || '',
              }));
            setPoiResults(tips);
          } else {
            setPoiResults([]);
          }
        });
      }, 300);
    },
    [initAutoComplete],
  );

  // 模糊兜底：用本地地標數據做 substring 匹配（簡繁都試）
  const fallbackResults = useMemo((): PoiResult[] => {
    const kw = keyword.trim();
    if (!kw) return [];
    const tcKw = scToTc(kw);
    const scKw = tcToSc(kw);
    const lowerKw = kw.toLowerCase();
    const lowerTc = tcKw.toLowerCase();
    const lowerSc = scKw.toLowerCase();
    const matched = MOCK_LANDMARKS.filter((l) => {
      const name = l.name;
      const lowerName = name.toLowerCase();
      return (
        name.includes(tcKw) ||
        name.includes(scKw) ||
        name.includes(kw) ||
        lowerName.includes(lowerTc) ||
        lowerName.includes(lowerSc) ||
        lowerName.includes(lowerKw) ||
        l.district.includes(tcKw) ||
        l.district.includes(scKw)
      );
    });
    return matched.slice(0, 8).map((l) => ({
      name: l.name,
      address: l.district,
      lat: l.lat,
      lng: l.lng,
      district: l.district,
    }));
  }, [keyword]);

  useEffect(() => {
    if (open) {
      setKeyword('');
      setPoiResults([]);
      setSearchError('');
      setIsSearching(false);
    }
    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [open]);

  const handleSelect = (poi: PoiResult) => {
    onSelect(poi);
    onClose();
  };

  const handleSelectLandmark = (name: string) => {
    const lm = MOCK_LANDMARKS.find((l) => l.name === name);
    if (lm) {
      onSelect({
        name: lm.name,
        address: lm.district,
        lat: lm.lat,
        lng: lm.lng,
        district: lm.district,
      });
    }
    onClose();
  };

  const { theme } = useTheme();

  const hotPlaces = theme === 'green'
    ? ['沙田', '元朗', '屯門', '荃灣', '大埔', '上水']
    : ['中環', '尖沙咀', '旺角', '銅鑼灣', '金鐘', '香港國際機場'];

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
          onClick={onClose}
        >
          <motion.div
            initial={{ y: '100%' }}
            animate={{ y: 0 }}
            exit={{ y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="w-full bg-white rounded-t-3xl max-h-[75vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 border-b border-slate-100">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-foreground">{title}</h3>
                <button
                  onClick={onClose}
                  className="size-8 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors"
                >
                  <X className="size-4 text-slate-500" />
                </button>
              </div>
              <div className="relative">
                <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="text"
                  value={keyword}
                  onChange={(e) => {
                    setKeyword(e.target.value);
                    searchPoi(e.target.value);
                  }}
                  placeholder="輸入地址、大廈或地方名..."
                  autoFocus
                  className="w-full h-11 pl-9 pr-3 rounded-xl bg-slate-100 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/30"
                />
                {isSearching && (
                  <Loader2 className="absolute right-3 top-1/2 size-4 -translate-y-1/2 text-primary animate-spin" />
                )}
              </div>
            </div>

            {/* Results */}
            <div className="flex-1 overflow-y-auto">
              {searchError && (
                <div className="p-4 flex items-start gap-3 text-sm text-amber-700 bg-amber-50 border-b border-amber-100">
                  <AlertTriangle className="size-4 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-medium">{searchError}</div>
                    <div className="text-xs text-amber-600 mt-0.5">
                      你可以使用下方快捷選擇揀地點
                    </div>
                  </div>
                </div>
              )}

              {/* 高德搜尋結果 */}
              {keyword.trim() && poiResults.length > 0 && (
                <div className="p-2">
                  <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground">
                    搜尋結果
                  </div>
                  {poiResults.slice(0, 10).map((poi, idx) => (
                    <button
                      key={`${poi.name}-${idx}`}
                      onClick={() => handleSelect(poi)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors text-left"
                    >
                      <div className="size-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                        <MapPin className="size-4 text-primary" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-foreground truncate">
                          {poi.name}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {poi.address || poi.district}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* 本地地標模糊兜底（高德冇結果或者結果少時顯示） */}
              {keyword.trim() && fallbackResults.length > 0 && poiResults.length < 5 && (
                <div className="p-2 border-t border-slate-100">
                  <div className="px-2 py-1.5 text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <span>相關地點</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-500">建議</span>
                  </div>
                  {fallbackResults.map((poi, idx) => (
                    <button
                      key={`fb-${poi.name}-${idx}`}
                      onClick={() => handleSelect(poi)}
                      className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors text-left"
                    >
                      <div className="size-9 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                        <MapPin className="size-4 text-slate-500" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-foreground truncate">
                          {poi.name}
                        </div>
                        <div className="text-xs text-muted-foreground truncate">
                          {poi.address || poi.district}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* 完全冇結果 */}
              {keyword.trim() && !isSearching && poiResults.length === 0 && fallbackResults.length === 0 && !searchError && (
                <div className="p-8 text-center">
                  <div className="size-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-3">
                    <Search className="size-5 text-slate-400" />
                  </div>
                  <div className="text-sm text-foreground font-medium mb-1">
                    搵唔到「{keyword}」相關地點
                  </div>
                  <div className="text-xs text-muted-foreground mt-1 space-y-0.5">
                    <div>💡 試下用繁體字或者更詳細嘅地址</div>
                    <div>💡 可以揀下方熱門地點快速出發</div>
                  </div>
                </div>
              )}

              {/* 快捷選擇（冇輸入時顯示） */}
              {!keyword.trim() && (
                <div className="p-4 space-y-4">
                  <div>
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      熱門地點
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      {hotPlaces.map((name) => (
                        <button
                          key={name}
                          onClick={() => handleSelectLandmark(name)}
                          className="py-2 px-3 rounded-xl bg-slate-50 border border-slate-200/50 text-sm font-medium text-foreground hover:bg-primary/5 hover:border-primary/20 transition-colors text-center truncate"
                        >
                          {name}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="text-xs font-medium text-muted-foreground mb-2">
                      更多地區
                    </div>
                    <div className="space-y-1">
                      {MOCK_LANDMARKS.slice(0, 15).map((l) => (
                        <button
                          key={l.id}
                          onClick={() => handleSelectLandmark(l.name)}
                          className="w-full flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 transition-colors text-left"
                        >
                          <div className="size-8 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                            <MapPin className="size-3.5 text-slate-500" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="text-sm font-medium text-foreground truncate">
                              {l.name}
                            </div>
                            <div className="text-xs text-muted-foreground">{l.district}</div>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
