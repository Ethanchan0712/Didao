import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { latLngToSvg } from '@/lib/taxi-utils';
import { MOCK_LANDMARKS } from '@/data/landmarks';
import type { IDriver } from '@/data/drivers';

interface MockMapProps {
  pickupName?: string;
  destinationName?: string;
  driverLat?: number;
  driverLng?: number;
  nearbyDrivers?: IDriver[];
  showRoute?: boolean;
  driverIconLabel?: string;
  height?: string;
}

const BOUNDS = {
  minLat: 22.27,
  maxLat: 22.34,
  minLng: 114.13,
  maxLng: 114.20,
};

const WIDTH = 400;
const HEIGHT = 320;

export default function MockMap({
  pickupName,
  destinationName,
  driverLat,
  driverLng,
  nearbyDrivers = [],
  showRoute = false,
  driverIconLabel,
  height = 'auto',
}: MockMapProps) {
  const pickup = pickupName
    ? MOCK_LANDMARKS.find((l) => l.name === pickupName)
    : undefined;
  const destination = destinationName
    ? MOCK_LANDMARKS.find((l) => l.name === destinationName)
    : undefined;

  const pickupPt = pickup
    ? latLngToSvg(pickup.lat, pickup.lng, BOUNDS, WIDTH, HEIGHT)
    : null;
  const destPt = destination
    ? latLngToSvg(destination.lat, destination.lng, BOUNDS, WIDTH, HEIGHT)
    : null;

  const driverPt =
    driverLat !== undefined && driverLng !== undefined
      ? latLngToSvg(driverLat, driverLng, BOUNDS, WIDTH, HEIGHT)
      : null;

  const nearbyPts = useMemo(
    () =>
      nearbyDrivers.map((d) => ({
        id: d.id,
        ...latLngToSvg(d.currentLat, d.currentLng, BOUNDS, WIDTH, HEIGHT),
      })),
    [nearbyDrivers]
  );

  // Generate realistic route path through road network
  const routePath = useMemo(() => {
    if (!pickupPt || !destPt) return '';
    const midX = (pickupPt.x + destPt.x) / 2 + (Math.sin(pickupPt.x * 0.1) * 20);
    const midY = (pickupPt.y + destPt.y) / 2 - 12;
    return `M ${pickupPt.x} ${pickupPt.y} Q ${midX} ${midY} ${destPt.x} ${destPt.y}`;
  }, [pickupPt, destPt]);

  // Hong Kong island + Kowloon peninsula shapes
  const landShapes = (
    <>
      {/* Hong Kong Island (bottom) */}
      <path
        d="M -20 240 Q 50 220 120 230 T 250 225 T 420 235 L 420 340 L -20 340 Z"
        fill="#c8e6c9"
        opacity="0.6"
      />
      {/* Kowloon peninsula (top-middle) */}
      <path
        d="M 80 -10 Q 120 30 160 40 Q 200 50 240 45 Q 280 40 320 35 Q 360 25 380 -10 L 80 -10 Z"
        fill="#c8e6c9"
        opacity="0.6"
      />
      {/* New Territories hint (top) */}
      <path
        d="M -20 -20 Q 100 10 200 5 Q 300 0 420 15 L 420 -20 Z"
        fill="#dcedc8"
        opacity="0.4"
      />
    </>
  );

  // Victoria Harbour water
  const harbour = (
    <path
      d="M 0 130 Q 80 110 160 125 Q 240 140 320 130 Q 380 122 400 135 L 400 195 Q 320 210 240 200 Q 160 190 80 200 Q 20 205 0 195 Z"
      fill="#81d4fa"
      opacity="0.55"
    />
  );

  // Major roads / highways
  const majorRoads = (
    <g stroke="#fff" strokeWidth="3" opacity="0.7" fill="none" strokeLinecap="round">
      {/* Nathan Road corridor */}
      <path d="M 180 50 Q 185 100 190 130" />
      {/* HK Island north coast road */}
      <path d="M 50 245 Q 150 240 250 242 T 400 240" />
      {/* Cross-harbour tunnel route */}
      <path d="M 185 130 Q 190 165 200 200 Q 205 225 210 242" strokeDasharray="4 6" strokeWidth="2" opacity="0.5" />
      {/* East Kowloon road */}
      <path d="M 280 50 Q 290 90 300 120" />
      {/* West Kowloon highway */}
      <path d="M 100 55 Q 110 90 120 125" />
    </g>
  );

  // Secondary streets
  const secondaryRoads = (
    <g stroke="#fff" strokeWidth="1.5" opacity="0.5" fill="none" strokeLinecap="round">
      {/* HK Island streets */}
      <path d="M 80 250 L 350 248" />
      <path d="M 100 260 L 320 258" />
      <path d="M 120 270 L 300 268" />
      {/* Kowloon streets - horizontal */}
      <path d="M 100 70 L 340 65" />
      <path d="M 90 90 L 350 85" />
      <path d="M 110 110 L 330 105" />
      {/* Kowloon streets - vertical */}
      <path d="M 140 45 L 145 120" />
      <path d="M 220 45 L 225 120" />
      <path d="M 260 45 L 265 120" />
      <path d="M 300 45 L 305 115" />
    </g>
  );

  // Parks / green areas
  const parks = (
    <g fill="#81c784" opacity="0.5">
      <ellipse cx="200" cy="85" rx="25" ry="15" />
      <ellipse cx="310" cy="270" rx="20" ry="12" />
      <ellipse cx="100" cy="265" rx="18" ry="10" />
    </g>
  );

  // Built-up area hints
  const builtUp = (
    <g fill="#e0e0e0" opacity="0.35">
      {/* Mong Kok / Yau Ma Tei dense area */}
      <rect x="140" y="60" width="80" height="55" rx="4" />
      {/* Tsim Sha Tsui */}
      <rect x="160" y="115" width="50" height="20" rx="3" />
      {/* Central */}
      <rect x="160" y="235" width="70" height="25" rx="3" />
      {/* Wan Chai / Causeway Bay */}
      <rect x="240" y="237" width="80" height="22" rx="3" />
    </g>
  );

  // Area labels
  const areaLabels = (
    <g fill="currentColor" opacity="0.4" fontSize="9" fontWeight="500">
      <text x="180" y="165" textAnchor="middle">維多利亞港</text>
      <text x="200" y="280" textAnchor="middle">港島</text>
      <text x="220" y="80" textAnchor="middle">九龍</text>
    </g>
  );

  return (
    <div
      className={`relative w-full overflow-hidden rounded-2xl border border-slate-200/60 ${height === 'auto' ? '' : height}`}
      style={{
        background: 'linear-gradient(180deg, #b3e5fc 0%, #e1f5fe 30%, #c8e6c9 100%)',
      }}
    >
      <svg
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        className="w-full h-full"
        preserveAspectRatio="xMidYMid slice"
      >
        {/* Land masses */}
        {landShapes}

        {/* Victoria Harbour */}
        {harbour}

        {/* Built-up areas */}
        {builtUp}

        {/* Parks */}
        {parks}

        {/* Road network */}
        {majorRoads}
        {secondaryRoads}

        {/* Area labels */}
        {areaLabels}

        {/* Route line */}
        {showRoute && routePath && (
          <>
            {/* Outer glow */}
            <path
              d={routePath}
              fill="none"
              stroke="#f97316"
              strokeWidth="8"
              strokeLinecap="round"
              opacity="0.2"
            />
            {/* Main route - dashed */}
            <motion.path
              d={routePath}
              fill="none"
              stroke="#f97316"
              strokeWidth="3"
              strokeLinecap="round"
              strokeDasharray="0 10 5 10"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 0.9 }}
              transition={{ duration: 0.8, ease: 'easeOut' }}
            />
          </>
        )}

        {/* Nearby idle drivers */}
        {nearbyPts.map((pt) => (
          <g key={pt.id}>
            <circle cx={pt.x} cy={pt.y} r="10" fill="#fbbf24" opacity="0.4">
              <animate
                attributeName="r"
                values="7;14;7"
                dur="2.5s"
                repeatCount="indefinite"
              />
              <animate
                attributeName="opacity"
                values="0.5;0.15;0.5"
                dur="2.5s"
                repeatCount="indefinite"
              />
            </circle>
            <circle cx={pt.x} cy={pt.y} r="5.5" fill="#f59e0b" stroke="#fff" strokeWidth="1.5" />
          </g>
        ))}

        {/* Pickup point */}
        {pickupPt && (
          <g>
            <circle cx={pickupPt.x} cy={pickupPt.y} r="18" fill="#10b981" opacity="0.15">
              <animate
                attributeName="r"
                values="14;24;14"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <circle
              cx={pickupPt.x}
              cy={pickupPt.y}
              r="7"
              fill="#10b981"
              stroke="#fff"
              strokeWidth="2"
            />
          </g>
        )}

        {/* Destination point */}
        {destPt && (
          <g>
            <circle cx={destPt.x} cy={destPt.y - 6} r="16" fill="#ef4444" opacity="0.15">
              <animate
                attributeName="r"
                values="12;20;12"
                dur="2s"
                repeatCount="indefinite"
              />
            </circle>
            <path
              d={`M ${destPt.x} ${destPt.y - 14} c -6 0 -10 5.5 -10 12 c 0 8.5 10 16 10 16 s 10 -7.5 10 -16 c 0 -6.5 -4 -12 -10 -12 z`}
              fill="#ef4444"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <circle cx={destPt.x} cy={destPt.y - 2} r="3.5" fill="#fff" />
          </g>
        )}

        {/* Active driver (accepted order) */}
        {driverPt && (
          <motion.g
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          >
            <circle cx={driverPt.x} cy={driverPt.y} r="16" fill="#3b82f6" opacity="0.15">
              <animate
                attributeName="r"
                values="12;20;12"
                dur="1.5s"
                repeatCount="indefinite"
              />
            </circle>
            <rect
              x={driverPt.x - 9}
              y={driverPt.y - 6}
              width="18"
              height="12"
              rx="3"
              fill="#3b82f6"
              stroke="#fff"
              strokeWidth="1.5"
            />
            <rect
              x={driverPt.x - 6}
              y={driverPt.y - 4}
              width="4"
              height="3"
              rx="1"
              fill="#93c5fd"
            />
            <rect
              x={driverPt.x + 2}
              y={driverPt.y - 4}
              width="4"
              height="3"
              rx="1"
              fill="#93c5fd"
            />
          </motion.g>
        )}
      </svg>

      {/* Legend / Labels */}
      {pickupName && (
        <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2.5 py-1.5 rounded-lg text-xs font-medium text-emerald-700 shadow-sm border border-emerald-100">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 mr-1.5 align-middle" />
          上車：{pickupName}
        </div>
      )}
      {destinationName && (
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2.5 py-1.5 rounded-lg text-xs font-medium text-red-700 shadow-sm border border-red-100">
          <span className="inline-block w-2 h-2 rounded-full bg-red-500 mr-1.5 align-middle" />
          目的地：{destinationName}
        </div>
      )}
      {driverIconLabel && (
        <div className="absolute bottom-3 left-3 bg-blue-600 text-white px-2.5 py-1.5 rounded-lg text-xs font-medium shadow-sm">
          {driverIconLabel}
        </div>
      )}

      {/* Map attribution */}
      <div className="absolute bottom-1 right-2 text-[9px] text-slate-500/70">
        示範地圖
      </div>
    </div>
  );
}
