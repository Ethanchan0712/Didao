import { useOrder } from '@/lib/order-context';
import { Users, Car, ArrowRightLeft } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface RoleSwitcherProps {
  compact?: boolean;
}

export default function RoleSwitcher({ compact = false }: RoleSwitcherProps) {
  const { currentRole, setCurrentRole } = useOrder();

  if (compact) {
    return (
      <button
        onClick={() => setCurrentRole(currentRole === 'passenger' ? 'driver' : 'passenger')}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 backdrop-blur border border-slate-200 text-sm font-medium text-foreground hover:bg-white transition-colors shadow-sm"
      >
        <ArrowRightLeft className="size-3.5 text-muted-foreground" />
        <span>{currentRole === 'passenger' ? '司機端' : '乘客端'}</span>
      </button>
    );
  }

  return (
    <div className="flex items-stretch bg-slate-100 rounded-full p-1 w-full max-w-xs mx-auto">
      <AnimatePresence initial={false}>
        <button
          onClick={() => setCurrentRole('passenger')}
          className={`relative flex-1 flex items-center justify-center gap-2 py-2 rounded-full text-sm font-medium transition-colors z-10 ${
            currentRole === 'passenger' ? 'text-white' : 'text-muted-foreground'
          }`}
        >
          {currentRole === 'passenger' && (
            <motion.span
              layoutId="roleBg"
              className="absolute inset-0 rounded-full bg-primary shadow-sm"
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          )}
          <Users className="size-4 relative z-10" />
          <span className="relative z-10">乘客端</span>
        </button>
        <button
          onClick={() => setCurrentRole('driver')}
          className={`relative flex-1 flex items-center justify-center gap-2 py-2 rounded-full text-sm font-medium transition-colors z-10 ${
            currentRole === 'driver' ? 'text-white' : 'text-muted-foreground'
          }`}
        >
          {currentRole === 'driver' && (
            <motion.span
              layoutId="roleBg"
              className="absolute inset-0 rounded-full bg-primary shadow-sm"
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          )}
          <Car className="size-4 relative z-10" />
          <span className="relative z-10">司機端</span>
        </button>
      </AnimatePresence>
    </div>
  );
}
