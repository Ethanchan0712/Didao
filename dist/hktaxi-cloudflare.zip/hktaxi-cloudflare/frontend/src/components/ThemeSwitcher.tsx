import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/lib/theme-context';
import { useI18n } from '@/lib/i18n';
import { Car } from 'lucide-react';

export default function ThemeSwitcher() {
  const { theme, setTheme } = useTheme();
  const { t } = useI18n();

  return (
    <div className="flex items-stretch bg-slate-100/80 backdrop-blur rounded-full p-1 w-full">
      <AnimatePresence initial={false}>
        <button
          onClick={() => setTheme('red')}
          className={`relative flex-1 flex items-center justify-center gap-1.5 py-2 rounded-full text-xs font-medium transition-colors z-10 ${
            theme === 'red' ? 'text-white' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          {theme === 'red' && (
            <motion.span
              layoutId="themeBg"
              className="absolute inset-0 rounded-full bg-primary shadow-sm"
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          )}
          <Car className="size-3.5 relative z-10" />
          <span className="relative z-10">{t.nav.taxiRed}</span>
        </button>
        <button
          onClick={() => setTheme('green')}
          className={`relative flex-1 flex items-center justify-center gap-1.5 py-2 rounded-full text-xs font-medium transition-colors z-10 ${
            theme === 'green' ? 'text-white' : 'text-muted-foreground hover:text-foreground'
          }`}
        >
          {theme === 'green' && (
            <motion.span
              layoutId="themeBg"
              className="absolute inset-0 rounded-full bg-primary shadow-sm"
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          )}
          <Car className="size-3.5 relative z-10" />
          <span className="relative z-10">{t.nav.taxiGreen}</span>
        </button>
      </AnimatePresence>
    </div>
  );
}
