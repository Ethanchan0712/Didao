// EXPORTS: IDriver, MOCK_DRIVERS
export interface IDriver {
  id: string
  name: string
  plate: string
  carModel: string
  rating: number
  currentLat: number
  currentLng: number
  imageUrl: string
}

export const MOCK_DRIVERS: IDriver[] = [
  {
    id: '1',
    name: '陳師傅',
    plate: 'AB1234',
    carModel: '豐田 Crown',
    rating: 4.8,
    currentLat: 22.2819,
    currentLng: 114.1585,
    imageUrl: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/1.jpg',
  },
  {
    id: '2',
    name: '李師傅',
    plate: 'CD5678',
    carModel: '豐田 Comfort',
    rating: 4.6,
    currentLat: 22.2855,
    currentLng: 114.1602,
    imageUrl: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/2.jpg',
  },
  {
    id: '3',
    name: '黃師傅',
    plate: 'EF9012',
    carModel: '日產 Serena',
    rating: 4.9,
    currentLat: 22.2790,
    currentLng: 114.1550,
    imageUrl: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/3.jpg',
  },
]