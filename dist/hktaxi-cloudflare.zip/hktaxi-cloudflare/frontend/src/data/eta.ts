// EXPORTS: IEta, MOCK_ETAS
export interface IEta {
  id: string
  minutes: number        // 剩餘分鐘數
  distanceKm: number     // 剩餘距離（公里）
  statusText: string     // 狀態文案，如「司機趕來中」「前往目的地中」
  lastUpdated: number    // 最後更新時間戳
}

export const MOCK_ETAS: IEta[] = [
  {
    id: '1',
    minutes: 3,
    distanceKm: 1.2,
    statusText: '司機趕來中',
    lastUpdated: Date.now(),
  },
  {
    id: '2',
    minutes: 8,
    distanceKm: 3.5,
    statusText: '前往目的地中',
    lastUpdated: Date.now(),
  },
  {
    id: '3',
    minutes: 1,
    distanceKm: 0.3,
    statusText: '即將到達',
    lastUpdated: Date.now(),
  },
]