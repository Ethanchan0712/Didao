// EXPORTS: ILandmark, MOCK_LANDMARKS, getLandmarkDistrict, DistrictType, TaxiZone

export type DistrictType = '港島中西區' | '港島灣仔' | '港島東區' | '港島南區' | '九龍油尖旺' | '九龍深水埗' | '九龍黃大仙' | '九龍觀塘' | '新界荃灣' | '新界沙田' | '新界元朗' | '新界北區' | '新界西貢' | '新界屯門' | '離島' | '大嶼山';

export type TaxiZone = 'urban' | 'new-territories' | 'lantau';

export interface ILandmark {
  id: string;
  name: string;
  district: DistrictType;
  zone: TaxiZone;
  lat: number;
  lng: number;
}

export const MOCK_LANDMARKS: ILandmark[] = [
  // 港島
  { id: '1', name: '中環', district: '港島中西區', zone: 'urban', lat: 22.2819, lng: 114.1585 },
  { id: '2', name: '銅鑼灣', district: '港島灣仔', zone: 'urban', lat: 22.2807, lng: 114.1855 },
  { id: '3', name: '灣仔', district: '港島灣仔', zone: 'urban', lat: 22.2790, lng: 114.1720 },
  { id: '4', name: '金鐘', district: '港島中西區', zone: 'urban', lat: 22.2790, lng: 114.1660 },
  { id: '5', name: '上環', district: '港島中西區', zone: 'urban', lat: 22.2865, lng: 114.1503 },
  { id: '6', name: '西環', district: '港島中西區', zone: 'urban', lat: 22.2896, lng: 114.1383 },
  { id: '7', name: '北角', district: '港島東區', zone: 'urban', lat: 22.2888, lng: 114.1985 },
  { id: '8', name: '太古', district: '港島東區', zone: 'urban', lat: 22.2855, lng: 114.2170 },
  { id: '9', name: '柴灣', district: '港島東區', zone: 'urban', lat: 22.2660, lng: 114.2400 },
  { id: '10', name: '鰂魚涌', district: '港島東區', zone: 'urban', lat: 22.2847, lng: 114.2100 },
  { id: '11', name: '黃竹坑', district: '港島南區', zone: 'urban', lat: 22.2490, lng: 114.1715 },
  { id: '12', name: '香港仔', district: '港島南區', zone: 'urban', lat: 22.2470, lng: 114.1560 },
  { id: '13', name: '赤柱', district: '港島南區', zone: 'urban', lat: 22.2110, lng: 114.2080 },
  // 九龍
  { id: '14', name: '旺角', district: '九龍油尖旺', zone: 'urban', lat: 22.3193, lng: 114.1700 },
  { id: '15', name: '尖沙咀', district: '九龍油尖旺', zone: 'urban', lat: 22.2978, lng: 114.1729 },
  { id: '16', name: '油麻地', district: '九龍油尖旺', zone: 'urban', lat: 22.3130, lng: 114.1710 },
  { id: '17', name: '佐敦', district: '九龍油尖旺', zone: 'urban', lat: 22.3050, lng: 114.1710 },
  { id: '18', name: '深水埗', district: '九龍深水埗', zone: 'urban', lat: 22.3310, lng: 114.1620 },
  { id: '19', name: '九龍塘', district: '九龍深水埗', zone: 'urban', lat: 22.3360, lng: 114.1780 },
  { id: '20', name: '黃大仙', district: '九龍黃大仙', zone: 'urban', lat: 22.3390, lng: 114.1970 },
  { id: '21', name: '樂富', district: '九龍黃大仙', zone: 'urban', lat: 22.3340, lng: 114.1880 },
  { id: '22', name: '觀塘', district: '九龍觀塘', zone: 'urban', lat: 22.3120, lng: 114.2250 },
  { id: '23', name: '九龍灣', district: '九龍觀塘', zone: 'urban', lat: 22.3230, lng: 114.2090 },
  { id: '24', name: '藍田', district: '九龍觀塘', zone: 'urban', lat: 22.3070, lng: 114.2360 },
  // 新界
  { id: '25', name: '荃灣', district: '新界荃灣', zone: 'new-territories', lat: 22.3730, lng: 114.1180 },
  { id: '26', name: '葵芳', district: '新界荃灣', zone: 'new-territories', lat: 22.3590, lng: 114.1290 },
  { id: '27', name: '沙田', district: '新界沙田', zone: 'new-territories', lat: 22.3820, lng: 114.1880 },
  { id: '28', name: '大圍', district: '新界沙田', zone: 'new-territories', lat: 22.3700, lng: 114.1780 },
  { id: '29', name: '大埔', district: '新界北區', zone: 'new-territories', lat: 22.4510, lng: 114.1710 },
  { id: '30', name: '上水', district: '新界北區', zone: 'new-territories', lat: 22.5030, lng: 114.1290 },
  { id: '31', name: '元朗', district: '新界元朗', zone: 'new-territories', lat: 22.4450, lng: 114.0220 },
  { id: '32', name: '屯門', district: '新界屯門', zone: 'new-territories', lat: 22.3960, lng: 113.9760 },
  { id: '33', name: '將軍澳', district: '新界西貢', zone: 'new-territories', lat: 22.3140, lng: 114.2580 },
  { id: '34', name: '西貢', district: '新界西貢', zone: 'new-territories', lat: 22.3810, lng: 114.2710 },
  { id: '35', name: '馬鞍山', district: '新界沙田', zone: 'new-territories', lat: 22.4180, lng: 114.2270 },
  // 大嶼山/離島
  { id: '36', name: '香港國際機場', district: '離島', zone: 'lantau', lat: 22.3080, lng: 113.9185 },
  { id: '37', name: '東涌', district: '離島', zone: 'lantau', lat: 22.2860, lng: 113.9430 },
  { id: '38', name: '愉景灣', district: '離島', zone: 'lantau', lat: 22.2930, lng: 114.0160 },
  { id: '39', name: '梅窩', district: '離島', zone: 'lantau', lat: 22.2660, lng: 113.9960 },
  { id: '40', name: '昂坪', district: '離島', zone: 'lantau', lat: 22.2580, lng: 113.9090 },
];

export function getLandmarkDistrict(name: string): DistrictType | '' {
  const lm = MOCK_LANDMARKS.find((l) => l.name === name);
  return lm?.district ?? '';
}
