import { scopedStorage } from '@lark-apaas/client-toolkit-lite';

const ADMIN_TOKEN_KEY = 'hktaxi_adminToken';
const ADMIN_USER_KEY = 'hktaxi_adminUser';

export function getAdminToken(): string | null {
  return scopedStorage.getItem(ADMIN_TOKEN_KEY) || localStorage.getItem(ADMIN_TOKEN_KEY) || null;
}

export function setAdminAuth(token: string, user: any) {
  scopedStorage.setItem(ADMIN_TOKEN_KEY, token);
  scopedStorage.setItem(ADMIN_USER_KEY, JSON.stringify(user));
  localStorage.setItem('hktaxi_adminToken', token);
}

export function clearAdminToken() {
  scopedStorage.removeItem(ADMIN_TOKEN_KEY);
  scopedStorage.removeItem(ADMIN_USER_KEY);
  localStorage.removeItem('hktaxi_adminToken');
}

export function getAdminUser(): any {
  const raw = scopedStorage.getItem(ADMIN_USER_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}
