// HK Taxi - Cloudflare 版本 API 封裝
// 與原版差異：
// 1. API base 改做環境變數 VITE_API_URL（Cloudflare Worker 域名）
// 2. SSE 長連接唔支援 Workers（無狀態），改用 setInterval polling

const API_BASE = (import.meta as any).env?.VITE_API_URL || '/api';

// 簡單 fetch wrapper，替代 axios
async function request(path: string, options: RequestInit = {}): Promise<any> {
  const token = localStorage.getItem('dikdou_token') || '';
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers,
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Request failed');
  }
  return data;
}

// ========== Auth Storage ==========
const TOKEN_KEY = 'dikdou_token';
const USER_KEY = 'dikdou_user';
const ROLE_KEY = 'dikdou_role';

export function getToken() {
  return localStorage.getItem(TOKEN_KEY) || '';
}

export function setAuth(token: string, user: any, role: 'passenger' | 'driver' | 'admin') {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  localStorage.setItem(ROLE_KEY, role);
  if (role === 'driver') localStorage.setItem('hktaxi_driverToken', token);
  if (role === 'admin') localStorage.setItem('hktaxi_adminToken', token);
  if (role === 'passenger') localStorage.setItem('hktaxi_passengerToken', token);
}

export function clearAuth() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
  localStorage.removeItem(ROLE_KEY);
  localStorage.removeItem('hktaxi_driverToken');
  localStorage.removeItem('hktaxi_adminToken');
  localStorage.removeItem('hktaxi_passengerToken');
}

export function getStoredUser(): any {
  const raw = localStorage.getItem(USER_KEY);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

export function getStoredRole(): string {
  return localStorage.getItem(ROLE_KEY) || '';
}

// ========== Auth API ==========
export async function passengerRegister(data: { username: string; password: string; name?: string; phone?: string }) {
  const res = await request('/auth/passenger/register', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res;
}

export async function passengerLogin(data: { username: string; password: string }) {
  const res = await request('/auth/passenger/login', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res;
}

export async function driverRegister(data: {
  username: string; password: string; name?: string; phone?: string;
  plate?: string; carModel?: string; driverLicense?: string;
}) {
  const res = await request('/auth/driver/register', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res;
}

export async function driverLogin(data: { username: string; password: string }) {
  const res = await request('/auth/driver/login', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res;
}

export async function adminLogin(data: { username: string; password: string }) {
  const res = await request('/auth/admin/login', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res;
}

export async function fetchPassengerMe() {
  const res = await request('/auth/passenger/me');
  return res.user;
}

export async function fetchDriverMe() {
  const res = await request('/auth/driver/me');
  return res;
}

// ========== Orders API ==========
export async function requestOrder(data: any) {
  const res = await request('/orders/passenger/request', {
    method: 'POST',
    body: JSON.stringify(data),
  });
  return res.order;
}

export async function cancelOrder() {
  const res = await request('/orders/passenger/cancel', { method: 'POST' });
  return res;
}

export async function getPassengerCurrentOrder() {
  const res = await request('/orders/passenger/current');
  return res.order;
}

export async function getPassengerHistory() {
  const res = await request('/orders/passenger/history');
  return res.orders;
}

export async function rateDriver(orderId: string, rating: number) {
  const res = await request('/orders/passenger/rate', {
    method: 'POST',
    body: JSON.stringify({ orderId, rating }),
  });
  return res;
}

export async function getDriverHallOrders() {
  const res = await request('/orders/driver/hall');
  return res.orders;
}

export async function acceptOrder(orderId: string) {
  const res = await request(`/orders/driver/accept/${orderId}`, { method: 'POST' });
  return res.order;
}

export async function rejectOrder(orderId: string) {
  const res = await request(`/orders/driver/reject/${orderId}`, { method: 'POST' });
  return res;
}

export async function getDriverCurrentOrder() {
  const res = await request('/orders/driver/current');
  return res.order;
}

export async function driverArrivePickup() {
  const res = await request('/orders/driver/arrive-pickup', { method: 'POST' });
  return res.order;
}

export async function driverComplete(actualFare: number) {
  const res = await request('/orders/driver/complete', {
    method: 'POST',
    body: JSON.stringify({ actualFare }),
  });
  return res.order;
}

export async function getDriverEarnings() {
  const res = await request('/orders/driver/earnings');
  return res.orders;
}

export async function ratePassenger(orderId: string, rating: number) {
  const res = await request('/orders/driver/rate', {
    method: 'POST',
    body: JSON.stringify({ orderId, rating }),
  });
  return res;
}

export async function setDriverOnline(online: boolean, lat?: number, lng?: number) {
  const res = await request('/orders/driver/online', {
    method: 'POST',
    body: JSON.stringify({ online, lat, lng }),
  });
  return res;
}

export async function updateDriverLocation(lat: number, lng: number, orderId?: string) {
  const res = await request('/orders/driver/location', {
    method: 'POST',
    body: JSON.stringify({ lat, lng, orderId }),
  });
  return res;
}

export async function updatePassengerLocation(lat: number, lng: number, orderId: string) {
  const res = await request('/orders/passenger/location', {
    method: 'POST',
    body: JSON.stringify({ lat, lng, orderId }),
  });
  return res;
}

export async function payOrder(orderId: string, method: string) {
  const res = await request('/orders/passenger/pay', {
    method: 'POST',
    body: JSON.stringify({ orderId, method }),
  });
  return res.order;
}

export async function getOrderDetail(orderId: string) {
  const res = await request(`/orders/${orderId}`);
  return res.order;
}

// ========== Chat API ==========
export async function sendPassengerMessage(orderId: string, text: string) {
  const res = await request('/chat/passenger/send', {
    method: 'POST',
    body: JSON.stringify({ orderId, text }),
  });
  return res.message;
}

export async function sendDriverMessage(orderId: string, text: string) {
  const res = await request('/chat/driver/send', {
    method: 'POST',
    body: JSON.stringify({ orderId, text }),
  });
  return res.message;
}

export async function getOrderMessages(orderId: string) {
  const res = await request(`/chat/order/${orderId}`);
  return res.messages;
}

// ========== Admin API ==========
export async function getAdminStats() {
  return request('/admin/stats');
}

export async function getAdminDrivers(status: string = 'pending') {
  const res = await request(`/admin/drivers?status=${status}`);
  return res.drivers;
}

export async function approveDriver(id: string) {
  return request(`/admin/drivers/${id}/approve`, { method: 'POST' });
}

export async function rejectDriver(id: string, reason: string) {
  return request(`/admin/drivers/${id}/reject`, {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });
}

export async function getAdminOrders(status?: string) {
  const url = status ? `/admin/orders?status=${status}` : '/admin/orders?status=all';
  const res = await request(url);
  return res.orders;
}

// ========== Polling (替代 SSE) ==========
// Cloudflare Workers 係無狀態，唔支援 SSE/WebSocket 長連接
// 改用 setInterval 輪詢，前端只需替換 createOrderStream → createOrderPoller

export interface Poller {
  start: () => void;
  stop: () => void;
  on: (event: string, callback: (data: any) => void) => void;
}

/**
 * 訂單狀態輪詢器 — 替代 SSE createOrderStream
 * 用法同 SSE 差不多：建立 → 掛 callback → start
 */
export function createOrderPoller(orderId: string, intervalMs = 2000): Poller {
  let timer: number | null = null;
  let lastStatus = '';
  let lastDriverLat = 0;
  let lastDriverLng = 0;
  const listeners: Record<string, ((data: any) => void)[]> = {};

  function emit(event: string, data: any) {
    const cbs = listeners[event];
    if (cbs) cbs.forEach((cb) => cb(data));
  }

  async function tick() {
    try {
      const order = await getOrderDetail(orderId);
      if (!order) return;

      // 狀態變更事件
      if (order.status !== lastStatus) {
        const prev = lastStatus;
        lastStatus = order.status;

        if (prev === '' && order.status) {
          // 第一次輪詢，唔觸發事件，只做 baseline
        } else {
          emit('order-status-change', { order });
          // 個別狀態事件，對應返原版 SSE event 名
          if (order.status === 'accepted') emit('order-accepted', { order });
          if (order.status === 'picked_up') emit('order-picked-up', { order });
          if (order.status === 'completed') emit('order-completed', { order });
          if (order.status === 'paid') emit('order-paid', { order });
          if (order.status === 'cancelled') emit('order-cancelled', { orderId });
          if (order.status === 'finished') emit('order-finished', { order });
        }
      }

      // 司機位置變更事件
      if (order.driver?.currentLat && order.driver?.currentLng) {
        if (
          order.driver.currentLat !== lastDriverLat ||
          order.driver.currentLng !== lastDriverLng
        ) {
          lastDriverLat = order.driver.currentLat;
          lastDriverLng = order.driver.currentLng;
          emit('driver-location', {
            lat: order.driver.currentLat,
            lng: order.driver.currentLng,
            orderId,
          });
        }
      }
    } catch {
      // 網絡錯誤靜默，下一輪再試
    }
  }

  return {
    on(event: string, callback: (data: any) => void) {
      if (!listeners[event]) listeners[event] = [];
      listeners[event].push(callback);
    },
    start() {
      if (timer) return;
      tick(); // 立即執行一次
      timer = window.setInterval(tick, intervalMs);
    },
    stop() {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    },
  };
}

/**
 * 司機大廳輪詢器 — 替代 SSE createDriverHallStream
 */
export function createDriverHallPoller(intervalMs = 3000): Poller {
  let timer: number | null = null;
  let lastIds: string[] = [];
  const listeners: Record<string, ((data: any) => void)[]> = {};

  function emit(event: string, data: any) {
    const cbs = listeners[event];
    if (cbs) cbs.forEach((cb) => cb(data));
  }

  async function tick() {
    try {
      const orders = await getDriverHallOrders();
      const currentIds = orders.map((o: any) => o.id);

      // 偵測新訂單
      const newOrders = orders.filter((o: any) => !lastIds.includes(o.id));
      if (newOrders.length > 0 && lastIds.length > 0) {
        newOrders.forEach((o: any) => {
          emit('new-order', { order: o });
        });
      }

      // 偵測已被接走嘅訂單
      const takenIds = lastIds.filter((id) => !currentIds.includes(id));
      if (takenIds.length > 0 && lastIds.length > 0) {
        takenIds.forEach((id) => {
          emit('order-taken', { orderId: id });
        });
      }

      lastIds = currentIds;
      emit('orders-updated', { orders });
    } catch {
      // 網絡錯誤靜默
    }
  }

  return {
    on(event: string, callback: (data: any) => void) {
      if (!listeners[event]) listeners[event] = [];
      listeners[event].push(callback);
    },
    start() {
      if (timer) return;
      tick();
      timer = window.setInterval(tick, intervalMs);
    },
    stop() {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    },
  };
}

// 保留原版 EventSource 風格嘅名，方便前端替換
export function createOrderStream(orderId: string) {
  const poller = createOrderPoller(orderId);
  poller.start();
  return {
    addEventListener: (event: string, cb: (e: any) => void) => {
      poller.on(event, (data) => cb({ data: JSON.stringify(data) }));
    },
    close: () => poller.stop(),
  };
}

export function createDriverHallStream() {
  const poller = createDriverHallPoller();
  poller.start();
  return {
    addEventListener: (event: string, cb: (e: any) => void) => {
      poller.on(event, (data) => cb({ data: JSON.stringify(data) }));
    },
    close: () => poller.stop(),
  };
}

/**
 * Admin 後台輪詢器 — 替代 SSE createAdminStream
 * 每 5 秒拉一次統計數據，有變化就觸發事件
 */
export function createAdminStream() {
  const listeners: Record<string, ((data: any) => void)[]> = {};
  let lastDriverCount = 0;
  let lastOrderCount = 0;
  let timer: number | null = null;

  async function tick() {
    try {
      const stats = await getAdminStats();
      const totalDrivers = (stats.pending || 0) + (stats.approved || 0) + (stats.rejected || 0);
      const totalOrders = stats.totalOrders || 0;

      if (lastDriverCount > 0 && totalDrivers !== lastDriverCount) {
        emit('driver-application-updated', { stats });
      }
      if (lastOrderCount > 0 && totalOrders !== lastOrderCount) {
        emit('order-updated', { stats });
      }

      lastDriverCount = totalDrivers;
      lastOrderCount = totalOrders;
    } catch {
      // 靜默
    }
  }

  function emit(event: string, data: any) {
    const cbs = listeners[event];
    if (cbs) cbs.forEach((cb) => cb({ data: JSON.stringify(data) }));
  }

  timer = window.setInterval(tick, 5000);
  tick();

  return {
    addEventListener(event: string, callback: (e: any) => void) {
      if (!listeners[event]) listeners[event] = [];
      listeners[event].push(callback);
    },
    close() {
      if (timer) {
        clearInterval(timer);
        timer = null;
      }
    },
  };
}

export default { request };
