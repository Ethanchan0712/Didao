/**
 * @lark-apaas/client-toolkit-lite shim for Cloudflare Pages deployment
 * 
 * 原版 App 依賴飛書 client toolkit，但 Cloudflare 獨立部署唔需要。
 * 呢個 shim 提供同款 API 嘅簡單實現，令原有代碼可以零修改運行。
 * 
 * 用 vite alias 將 '@lark-apaas/client-toolkit-lite' 指向呢個檔案
 */

// ========== logger ==========
export const logger = {
  info: (...args: any[]) => console.log('[INFO]', ...args),
  warn: (...args: any[]) => console.warn('[WARN]', ...args),
  error: (...args: any[]) => console.error('[ERROR]', ...args),
  debug: (...args: any[]) => console.debug('[DEBUG]', ...args),
};

// ========== scopedStorage ==========
// 原版有 appId 前綴，獨立部署直接用 localStorage
const STORAGE_PREFIX = 'hktaxi_';

export const scopedStorage = {
  getItem(key: string): string | null {
    return localStorage.getItem(STORAGE_PREFIX + key);
  },
  setItem(key: string, value: string): void {
    localStorage.setItem(STORAGE_PREFIX + key, value);
  },
  removeItem(key: string): void {
    localStorage.removeItem(STORAGE_PREFIX + key);
  },
  clear(): void {
    const keys: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(STORAGE_PREFIX)) keys.push(k);
    }
    keys.forEach((k) => localStorage.removeItem(k));
  },
};

// ========== UniversalLink ==========
// 獨立部署直接用原生 <a> 就得
// 呢度用 createElement 寫，避免 .ts 檔唔支援 JSX 嘅問題
import { createElement, forwardRef, type AnchorHTMLAttributes } from 'react';

export const UniversalLink = forwardRef<
  HTMLAnchorElement,
  AnchorHTMLAttributes<HTMLAnchorElement>
>(function UniversalLink(props, ref) {
  return createElement('a', { ref, ...props });
});

// ========== 其他可能用到嘅導出 ==========
export function getAppId(): string {
  return 'hktaxi-local';
}

export function resolveAppUrl(path: string): string {
  return path;
}

export function copyToClipboard(text: string): Promise<void> {
  return navigator.clipboard.writeText(text);
}

export const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(
  typeof navigator !== 'undefined' ? navigator.userAgent : ''
);

export const isIOS = /iPad|iPhone|iPod/.test(
  typeof navigator !== 'undefined' ? navigator.userAgent : ''
);
