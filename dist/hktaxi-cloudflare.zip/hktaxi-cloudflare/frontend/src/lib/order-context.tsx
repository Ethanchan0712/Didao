'use client';

import { createContext, useContext, useState, useCallback, useEffect, useRef, type ReactNode } from 'react';
import { scopedStorage, logger } from '@lark-apaas/client-toolkit-lite';
import { MOCK_DRIVERS, type IDriver } from '@/data/drivers';
import {
  requestOrder as apiRequestOrder,
  cancelOrder as apiCancelOrder,
  getPassengerCurrentOrder as apiPassengerCurrent,
  getDriverCurrentOrder as apiDriverCurrent,
  acceptOrder as apiAcceptOrder,
  driverArrivePickup,
  driverComplete,
  payOrder,
  rateDriver as apiRateDriver,
  ratePassenger as apiRatePassenger,
  setDriverOnline as apiSetOnline,
  sendPassengerMessage,
  sendDriverMessage,
  getOrderMessages,
  createOrderStream,
  getDriverHallOrders,
  getPassengerHistory,
  getDriverEarnings,
  getToken,
  clearAuth,
  getStoredRole,
} from '@/lib/api';

export type OrderStatus =
  | 'idle'
  | 'searching'
  | 'accepted'
  | 'picked_up'
  | 'completed'
  | 'paid'
  | 'finished'
  | 'cancelled';

export interface ILatLng {
  name: string;
  lat: number;
  lng: number;
}

export type CarType = '4-seater' | '6-seater';

export interface IChatMessage {
  id: string;
  text: string;
  from: 'passenger' | 'driver';
  timestamp: number;
}

export type DriverApplicationStatus = 'pending' | 'approved' | 'rejected';

export interface IDriverApplication {
  id: string;
  driverName: string;
  licenseNo: string;
  plate: string;
  carType: CarType;
  status: DriverApplicationStatus;
  rejectReason?: string;
  createdAt: number;
  reviewedAt?: number;
}

export interface IOrder {
  id: string;
  status: OrderStatus;
  pickup: ILatLng;
  destination: ILatLng;
  carType: CarType;
  tip: number;
  estimatedFare: number;
  discount85?: boolean;
  actualFare?: number;
  driver?: IDriver & { imageUrl?: string };
  passenger?: {
    id: string;
    name: string;
    rating: number;
  };
  etaMinutes?: number;
  distanceKm?: number;
  createdAt: number;
  driverRating?: number;
  passengerRating?: number;
  fareExtras?: {
    luggageCount: number;
    isNight: boolean;
    taxiTypeName: string;
    paymentMethod?: string;
    fareBreakdown?: {
      flagfall: number;
      mileageFare: number;
      waitingFare: number;
      nightSurcharge: number;
      luggageSurcharge: number;
      tunnelSurcharge: number;
      comfort6Surcharge?: number;
      tip?: number;
    };
  };
  messages?: IChatMessage[];
  taxiType?: 'red' | 'green';
}

interface IOrderContext {
  order: IOrder | null;
  driverOnline: boolean;
  currentRole: 'passenger' | 'driver' | 'admin';
  driverVerified: boolean;
  driverApplication: IDriverApplication | null;
  driverApplications: IDriverApplication[];
  historyOrders: IOrder[];
  hallOrders: IOrder[];
  user: any;
  isLoggedIn: boolean;
  createOrder: (
    pickup: ILatLng, destination: ILatLng, estimatedFare: number,
    carType: CarType, tip: number,
    extras?: { luggageCount: number; isNight: boolean; taxiTypeName: string; fareBreakdown?: IOrder['fareExtras']['fareBreakdown'] },
    discount85?: boolean,
    taxiType?: 'red' | 'green',
  ) => Promise<void>;
  acceptOrder: (driverId: string) => Promise<void>;
  rejectOrder: () => Promise<void>;
  updateDriverPosition: (lat: number, lng: number, etaMinutes: number) => void;
  markPickedUp: () => Promise<void>;
  markCompleted: (actualFare: number) => Promise<void>;
  markPaid: (method: string) => Promise<void>;
  submitDriverRating: (rating: number) => Promise<void>;
  submitPassengerRating: (rating: number) => Promise<void>;
  cancelOrder: () => Promise<void>;
  sendOrderMessage: (text: string, from: 'passenger' | 'driver') => Promise<void>;
  setDriverOnline: (online: boolean, lat?: number, lng?: number) => Promise<void>;
  setCurrentRole: (role: 'passenger' | 'driver' | 'admin') => void;
  setDriverVerified: (verified: boolean) => void;
  submitDriverApplication: (data: { driverName: string; licenseNo: string; plate: string; carType: CarType }) => void;
  approveDriver: (applicationId: string) => void;
  rejectDriver: (applicationId: string, reason: string) => void;
  refreshDriverApplications: () => void;
  resetToIdle: () => void;
  resetDemoData: () => void;
  login: (role: 'passenger' | 'driver' | 'admin', user: any, token: string) => void;
  logout: () => void;
  refreshCurrentOrder: () => Promise<void>;
  refreshHallOrders: () => Promise<void>;
  refreshHistory: () => Promise<void>;
}

const OrderContext = createContext<IOrderContext | null>(null);

const ROLE_KEY = 'hktaxi_currentRole';
const DRIVER_VERIFIED_KEY = 'hktaxi_driverVerified';
const DRIVER_APPLICATION_KEY = 'hktaxi_driverApplication';
const DRIVER_APPLICATIONS_KEY = 'hktaxi_driverApplications';

function readRole(): 'passenger' | 'driver' | 'admin' {
  const storedRole = getStoredRole();
  if (storedRole === 'driver') return 'driver';
  if (storedRole === 'admin') return 'admin';
  // fallback to old key
  const r = scopedStorage.getItem(ROLE_KEY);
  if (r === 'driver') return 'driver';
  if (r === 'admin') return 'admin';
  return 'passenger';
}

function writeRole(role: 'passenger' | 'driver' | 'admin') {
  scopedStorage.setItem(ROLE_KEY, role);
  window.dispatchEvent(new Event('hktaxi-role-updated'));
}

function genAppId(): string {
  return 'APP' + Math.random().toString(36).slice(2, 8).toUpperCase();
}

function readDriverApplication(): IDriverApplication | null {
  try {
    const raw = scopedStorage.getItem(DRIVER_APPLICATION_KEY);
    return raw ? (JSON.parse(raw) as IDriverApplication) : null;
  } catch {
    return null;
  }
}

function writeDriverApplication(app: IDriverApplication | null) {
  try {
    if (app) {
      scopedStorage.setItem(DRIVER_APPLICATION_KEY, JSON.stringify(app));
    } else {
      scopedStorage.removeItem(DRIVER_APPLICATION_KEY);
    }
    window.dispatchEvent(new Event('hktaxi-application-updated'));
  } catch {
    // ignore
  }
}

function readDriverApplications(): IDriverApplication[] {
  try {
    const raw = scopedStorage.getItem(DRIVER_APPLICATIONS_KEY);
    if (!raw) {
      const defaults: IDriverApplication[] = [
        { id: 'APP001', driverName: '陳志強', licenseNo: 'TP88231', plate: 'TD 8823', carType: '4-seater', status: 'pending', createdAt: Date.now() - 1000 * 60 * 30 },
        { id: 'APP002', driverName: '李國輝', licenseNo: 'TP76543', plate: 'VM 1234', carType: '4-seater', status: 'approved', createdAt: Date.now() - 1000 * 60 * 60 * 24 * 3, reviewedAt: Date.now() - 1000 * 60 * 60 * 24 * 2 },
        { id: 'APP003', driverName: '黃永安', licenseNo: 'TP91234', plate: 'PH 9876', carType: '6-seater', status: 'approved', createdAt: Date.now() - 1000 * 60 * 60 * 24 * 7, reviewedAt: Date.now() - 1000 * 60 * 60 * 24 * 6 },
      ];
      scopedStorage.setItem(DRIVER_APPLICATIONS_KEY, JSON.stringify(defaults));
      return defaults;
    }
    return JSON.parse(raw) as IDriverApplication[];
  } catch {
    return [];
  }
}

function writeDriverApplications(apps: IDriverApplication[]) {
  try {
    scopedStorage.setItem(DRIVER_APPLICATIONS_KEY, JSON.stringify(apps));
    window.dispatchEvent(new Event('hktaxi-applications-updated'));
  } catch {
    // ignore
  }
}

// Convert API order shape to local IOrder shape
function apiOrderToLocal(apiOrder: any): IOrder {
  if (!apiOrder) return null as any;
  const carType: CarType = apiOrder.carType === '6pax' || apiOrder.carType === '6-seater' ? '6-seater' : '4-seater';
  return {
    id: apiOrder.id,
    status: apiOrder.status as OrderStatus,
    pickup: { name: apiOrder.pickup.name, lat: apiOrder.pickup.lat, lng: apiOrder.pickup.lng },
    destination: { name: apiOrder.destination.name, lat: apiOrder.destination.lat, lng: apiOrder.destination.lng },
    carType,
    tip: apiOrder.tipAmount ?? 0,
    estimatedFare: apiOrder.estimatedFare,
    actualFare: apiOrder.actualFare,
    discount85: apiOrder.hasDiscount,
    driver: apiOrder.driver ? {
      id: apiOrder.driver.id,
      name: apiOrder.driver.name,
      plate: apiOrder.driver.plate,
      carModel: apiOrder.driver.carModel,
      rating: apiOrder.driver.rating,
      currentLat: apiOrder.driver.currentLat,
      currentLng: apiOrder.driver.currentLng,
      imageUrl: '',
    } : undefined,
    passenger: apiOrder.passenger,
    etaMinutes: apiOrder.etaMinutes,
    distanceKm: apiOrder.distanceKm,
    createdAt: apiOrder.createdAt,
    driverRating: apiOrder.driverRating,
    passengerRating: apiOrder.passengerRating,
    taxiType: apiOrder.taxiType as 'red' | 'green',
    messages: [],
  };
}

export function OrderProvider({ children }: { children: ReactNode }) {
  const [order, setOrder] = useState<IOrder | null>(null);
  const [hallOrders, setHallOrders] = useState<IOrder[]>([]);
  const [driverOnline, setDriverOnlineState] = useState<boolean>(false);
  const [currentRole, setCurrentRoleState] = useState<'passenger' | 'driver' | 'admin'>(() => readRole());
  const [driverVerified, setDriverVerifiedState] = useState<boolean>(() => {
    return scopedStorage.getItem(DRIVER_VERIFIED_KEY) === 'true';
  });
  const [driverApplication, setDriverApplicationState] = useState<IDriverApplication | null>(() => readDriverApplication());
  const [driverApplications, setDriverApplicationsState] = useState<IDriverApplication[]>(() => readDriverApplications());
  const [historyOrders, setHistoryOrders] = useState<IOrder[]>([]);
  const [user, setUser] = useState<any>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(!!getToken());

  const sseRef = useRef<EventSource | null>(null);
  const hallSseRef = useRef<EventSource | null>(null);

  // Sync role across tabs
  useEffect(() => {
    const syncRole = () => setCurrentRoleState(readRole());
    const syncApplication = () => setDriverApplicationState(readDriverApplication());
    const syncApplications = () => setDriverApplicationsState(readDriverApplications());
    window.addEventListener('hktaxi-role-updated', syncRole);
    window.addEventListener('hktaxi-application-updated', syncApplication);
    window.addEventListener('hktaxi-applications-updated', syncApplications);
    window.addEventListener('storage', (e) => {
      if (e.key?.includes('hktaxi_currentRole')) syncRole();
      if (e.key?.includes('hktaxi_driverApplication')) syncApplication();
      if (e.key?.includes('hktaxi_driverApplications')) syncApplications();
    });
    return () => {
      window.removeEventListener('hktaxi-role-updated', syncRole);
      window.removeEventListener('hktaxi-application-updated', syncApplication);
      window.removeEventListener('hktaxi-applications-updated', syncApplications);
    };
  }, []);

  // SSE subscription for order updates
  useEffect(() => {
    if (!order || order.status === 'finished' || order.status === 'cancelled') {
      if (sseRef.current) {
        sseRef.current.close();
        sseRef.current = null;
      }
      return;
    }

    if (sseRef.current) return; // already subscribed

    try {
      const es = createOrderStream(order.id);
      sseRef.current = es;

      es.addEventListener('order-accepted', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder(apiOrderToLocal(data.order));
      });
      es.addEventListener('order-picked-up', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder(apiOrderToLocal(data.order));
      });
      es.addEventListener('order-completed', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder(apiOrderToLocal(data.order));
      });
      es.addEventListener('order-paid', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder(apiOrderToLocal(data.order));
      });
      es.addEventListener('order-cancelled', () => {
        setOrder(null);
      });
      es.addEventListener('driver-location', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder((prev) => {
          if (!prev || !prev.driver) return prev;
          return {
            ...prev,
            driver: { ...prev.driver, currentLat: data.lat, currentLng: data.lng },
          };
        });
      });
      es.addEventListener('passenger-location', (e: any) => {
        // passenger location update - update UI if needed
        logger.info('passenger location update:', e.data);
      });
      es.addEventListener('new-message', (e: any) => {
        const data = JSON.parse(e.data);
        setOrder((prev) => {
          if (!prev) return prev;
          const msgs = prev.messages ?? [];
          if (msgs.some((m) => m.id === data.message.id)) return prev;
          return { ...prev, messages: [...msgs, data.message] };
        });
      });
      es.addEventListener('driver-rated', () => {
        refreshCurrentOrder();
      });
      es.addEventListener('passenger-rated', () => {
        refreshCurrentOrder();
      });

      es.onerror = () => {
        // reconnect on error - EventSource auto-reconnects
      };
    } catch (err) {
      logger.error('SSE connect failed:', String(err));
    }

    return () => {
      if (sseRef.current) {
        sseRef.current.close();
        sseRef.current = null;
      }
    };
  }, [order?.id, order?.status]);

  const refreshCurrentOrder = useCallback(async () => {
    try {
      const role = getStoredRole() || currentRole;
      let apiOrder: any = null;
      if (role === 'passenger') {
        apiOrder = await apiPassengerCurrent();
      } else if (role === 'driver') {
        apiOrder = await apiDriverCurrent();
      }
      if (apiOrder) {
        const local = apiOrderToLocal(apiOrder);
        // load messages
        try {
          const msgs = await getOrderMessages(local.id);
          local.messages = msgs;
        } catch { /* ignore */ }
        setOrder(local);
      } else {
        setOrder(null);
      }
    } catch (err) {
      logger.error('refresh order failed:', String(err));
    }
  }, [currentRole]);

  const refreshHallOrders = useCallback(async () => {
    try {
      const list = await getDriverHallOrders();
      setHallOrders(list.map(apiOrderToLocal));
    } catch (err) {
      logger.error('refresh hall failed:', String(err));
    }
  }, []);

  const refreshHistory = useCallback(async () => {
    try {
      const role = getStoredRole() || currentRole;
      if (role === 'passenger') {
        const list = await getPassengerHistory();
        setHistoryOrders(list.map(apiOrderToLocal));
      } else if (role === 'driver') {
        const list = await getDriverEarnings();
        setHistoryOrders(list.map(apiOrderToLocal));
      }
    } catch (err) {
      logger.error('refresh history failed:', String(err));
    }
  }, [currentRole]);

  const createOrder = useCallback(
    async (
      pickup: ILatLng, destination: ILatLng, estimatedFare: number,
      carType: CarType, tip: number,
      extras?: { luggageCount: number; isNight: boolean; taxiTypeName: string; fareBreakdown?: IOrder['fareExtras']['fareBreakdown'] },
      discount85?: boolean,
      taxiType?: 'red' | 'green',
    ) => {
      try {
        const apiCarType = carType === '6-seater' ? '6pax' : '4pax';
        const apiOrder = await apiRequestOrder({
          pickup, destination,
          carType: apiCarType,
          hasDiscount: !!discount85,
          tipAmount: tip,
          estimatedFare,
          distanceKm: 0,
          etaMinutes: 0,
          taxiType: taxiType || 'red',
        });
        const local = apiOrderToLocal(apiOrder);
        if (extras) {
          local.fareExtras = {
            luggageCount: extras.luggageCount,
            isNight: extras.isNight,
            taxiTypeName: extras.taxiTypeName,
            fareBreakdown: extras.fareBreakdown,
          };
        }
        setOrder(local);
      } catch (err) {
        logger.error('createOrder failed:', String(err));
        throw err;
      }
    },
    []
  );

  const acceptOrder = useCallback(
    async (driverId: string) => {
      if (!hallOrders.length) return;
      // Find the first searching order
      const target = hallOrders.find((o) => o.status === 'searching');
      if (!target) return;
      try {
        const apiOrder = await apiAcceptOrder(target.id);
        const local = apiOrderToLocal(apiOrder);
        setOrder(local);
        // Remove from hall
        setHallOrders((prev) => prev.filter((o) => o.id !== target.id));
      } catch (err) {
        logger.error('acceptOrder failed:', String(err));
        throw err;
      }
    },
    [hallOrders]
  );

  const rejectOrder = useCallback(async () => {
    // For now just remove from hall (prototype behaviour)
    if (!hallOrders.length) return;
    const target = hallOrders[0];
    setHallOrders((prev) => prev.filter((o) => o.id !== target.id));
  }, [hallOrders]);

  const updateDriverPosition = useCallback((lat: number, lng: number, etaMinutes: number) => {
    // Update locally immediately for responsiveness
    setOrder((prev) => {
      if (!prev || !prev.driver) return prev;
      return {
        ...prev,
        driver: { ...prev.driver, currentLat: lat, currentLng: lng },
        etaMinutes,
      };
    });
    // Fire-and-forget to server
    import('@/lib/api').then(({ updateDriverLocation }) => {
      updateDriverLocation(lat, lng, order?.id).catch(() => {});
    });
  }, [order?.id]);

  const markPickedUp = useCallback(async () => {
    try {
      const apiOrder = await driverArrivePickup();
      setOrder(apiOrderToLocal(apiOrder));
    } catch (err) {
      logger.error('markPickedUp failed:', String(err));
      throw err;
    }
  }, []);

  const markCompleted = useCallback(async (actualFare: number) => {
    try {
      const apiOrder = await driverComplete(actualFare);
      setOrder(apiOrderToLocal(apiOrder));
    } catch (err) {
      logger.error('markCompleted failed:', String(err));
      throw err;
    }
  }, []);

  const markPaid = useCallback(async (method: string) => {
    if (!order) return;
    try {
      const apiOrder = await payOrder(order.id, method);
      const local = apiOrderToLocal(apiOrder);
      if (order.fareExtras) {
        local.fareExtras = { ...order.fareExtras, paymentMethod: method };
      }
      setOrder(local);
      // refresh history
      refreshHistory();
    } catch (err) {
      logger.error('markPaid failed:', String(err));
      throw err;
    }
  }, [order, refreshHistory]);

  const submitDriverRating = useCallback(async (rating: number) => {
    if (!order) return;
    try {
      await apiRateDriver(order.id, rating);
      setOrder((prev) => prev ? { ...prev, driverRating: rating } : prev);
      refreshHistory();
    } catch (err) {
      logger.error('submitDriverRating failed:', String(err));
      throw err;
    }
  }, [order, refreshHistory]);

  const submitPassengerRating = useCallback(async (rating: number) => {
    if (!order) return;
    try {
      await apiRatePassenger(order.id, rating);
      setOrder((prev) => prev ? { ...prev, passengerRating: rating } : prev);
      refreshHistory();
    } catch (err) {
      logger.error('submitPassengerRating failed:', String(err));
      throw err;
    }
  }, [order, refreshHistory]);

  const cancelOrder = useCallback(async () => {
    try {
      await apiCancelOrder();
      setOrder(null);
    } catch (err) {
      logger.error('cancelOrder failed:', String(err));
      throw err;
    }
  }, []);

  const sendOrderMessage = useCallback(async (text: string, from: 'passenger' | 'driver') => {
    if (!order) return;
    try {
      if (from === 'passenger') {
        await sendPassengerMessage(order.id, text);
      } else {
        await sendDriverMessage(order.id, text);
      }
      // Optimistic update - SSE will also confirm
      const newMsg: IChatMessage = {
        id: 'local_' + Math.random().toString(36).slice(2, 8),
        text,
        from,
        timestamp: Date.now(),
      };
      setOrder((prev) => {
        if (!prev) return prev;
        return { ...prev, messages: [...(prev.messages ?? []), newMsg] };
      });
    } catch (err) {
      logger.error('sendOrderMessage failed:', String(err));
      throw err;
    }
  }, [order]);

  const setDriverOnline = useCallback(async (online: boolean, lat?: number, lng?: number) => {
    try {
      await apiSetOnline(online, lat, lng);
      setDriverOnlineState(online);
    } catch (err) {
      logger.error('setDriverOnline failed:', String(err));
      throw err;
    }
  }, []);

  const setCurrentRole = useCallback((role: 'passenger' | 'driver' | 'admin') => {
    setCurrentRoleState(role);
    writeRole(role);
  }, []);

  const setDriverVerified = useCallback((verified: boolean) => {
    scopedStorage.setItem(DRIVER_VERIFIED_KEY, String(verified));
    setDriverVerifiedState(verified);
    window.dispatchEvent(new Event('hktaxi-driver-updated'));
  }, []);

  const submitDriverApplication = useCallback((data: { driverName: string; licenseNo: string; plate: string; carType: CarType }) => {
    const app: IDriverApplication = {
      id: genAppId(),
      driverName: data.driverName,
      licenseNo: data.licenseNo,
      plate: data.plate,
      carType: data.carType,
      status: 'pending',
      createdAt: Date.now(),
    };
    writeDriverApplication(app);
    const apps = readDriverApplications();
    const next = [app, ...apps];
    writeDriverApplications(next);
  }, []);

  const approveDriver = useCallback((applicationId: string) => {
    const apps = readDriverApplications();
    const idx = apps.findIndex((a) => a.id === applicationId);
    if (idx === -1) return;
    const updated: IDriverApplication = { ...apps[idx], status: 'approved', reviewedAt: Date.now() };
    apps[idx] = updated;
    writeDriverApplications(apps);
    const current = readDriverApplication();
    if (current && current.id === applicationId) {
      writeDriverApplication(updated);
      scopedStorage.setItem(DRIVER_VERIFIED_KEY, 'true');
      window.dispatchEvent(new Event('hktaxi-driver-updated'));
    }
  }, []);

  const rejectDriver = useCallback((applicationId: string, reason: string) => {
    const apps = readDriverApplications();
    const idx = apps.findIndex((a) => a.id === applicationId);
    if (idx === -1) return;
    const updated: IDriverApplication = { ...apps[idx], status: 'rejected', rejectReason: reason, reviewedAt: Date.now() };
    apps[idx] = updated;
    writeDriverApplications(apps);
    const current = readDriverApplication();
    if (current && current.id === applicationId) {
      writeDriverApplication(updated);
    }
  }, []);

  const refreshDriverApplications = useCallback(() => {
    setDriverApplicationsState(readDriverApplications());
  }, []);

  const resetToIdle = useCallback(() => {
    setOrder(null);
  }, []);

  const resetDemoData = useCallback(() => {
    clearAuth();
    scopedStorage.removeItem(DRIVER_VERIFIED_KEY);
    scopedStorage.removeItem(DRIVER_APPLICATION_KEY);
    scopedStorage.removeItem(DRIVER_APPLICATIONS_KEY);
    setOrder(null);
    setDriverOnlineState(false);
    setDriverVerifiedState(false);
    setDriverApplicationState(null);
    setDriverApplicationsState([]);
    setHistoryOrders([]);
    setUser(null);
    setIsLoggedIn(false);
    window.dispatchEvent(new Event('hktaxi-order-updated'));
  }, []);

  const login = useCallback((role: 'passenger' | 'driver' | 'admin', userData: any, token: string) => {
    // Store via scopedStorage is done in setAuth from api.ts - but we also set state
    import('@/lib/api').then(({ setAuth }) => {
      setAuth(token, userData, role);
    });
    setUser(userData);
    setIsLoggedIn(true);
    setCurrentRoleState(role);
    writeRole(role);
    // For driver, set verified based on status
    if (role === 'driver') {
      const verified = userData.status === 'approved';
      scopedStorage.setItem(DRIVER_VERIFIED_KEY, String(verified));
      setDriverVerifiedState(verified);
      setDriverOnlineState(!!userData.online);
    }
  }, []);

  const logout = useCallback(() => {
    clearAuth();
    setUser(null);
    setIsLoggedIn(false);
    setOrder(null);
    setHallOrders([]);
    setHistoryOrders([]);
    setDriverOnlineState(false);
    if (sseRef.current) { sseRef.current.close(); sseRef.current = null; }
    if (hallSseRef.current) { hallSseRef.current.close(); hallSseRef.current = null; }
  }, []);

  return (
    <OrderContext.Provider
      value={{
        order,
        driverOnline,
        currentRole,
        driverVerified,
        driverApplication,
        driverApplications,
        historyOrders,
        hallOrders,
        user,
        isLoggedIn,
        createOrder,
        acceptOrder,
        rejectOrder,
        updateDriverPosition,
        markPickedUp,
        markCompleted,
        markPaid,
        submitDriverRating,
        submitPassengerRating,
        cancelOrder,
        sendOrderMessage,
        setDriverOnline,
        setCurrentRole,
        setDriverVerified,
        submitDriverApplication,
        approveDriver,
        rejectDriver,
        refreshDriverApplications,
        resetToIdle,
        resetDemoData,
        login,
        logout,
        refreshCurrentOrder,
        refreshHallOrders,
        refreshHistory,
      }}
    >
      {children}
    </OrderContext.Provider>
  );
}

export function useOrder() {
  const ctx = useContext(OrderContext);
  if (!ctx) throw new Error('useOrder must be used within OrderProvider');
  return ctx;
}
