// EXPORTS: calcFare, FareResult, TaxiType, FARE_DISCLAIMER, calcDistanceKm, formatDate, formatTime, haversineKm, interpolateLatLng, estimateFare, latLngToSvg
import { MOCK_LANDMARKS, type TaxiZone } from '@/data/landmarks';

export const FARE_DISCLAIMER = '示範費率，以政府跳錶為準';

export type TaxiType = 'urban' | 'nt' | 'lantau' | 'comfort6';

/** 計算兩個經緯度點之間嘅直線距離（公里） */
export function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371; // 地球半徑 km
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1Rad = (a.lat * Math.PI) / 180;
  const lat2Rad = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** 喺兩個經緯度對象之間插值 */
export function interpolateLatLng(
  start: { lat: number; lng: number },
  end: { lat: number; lng: number },
  t: number,
): { lat: number; lng: number } {
  return {
    lat: start.lat + (end.lat - start.lat) * t,
    lng: start.lng + (end.lng - start.lng) * t,
  };
}

/** 格式化日期為 YYYY/MM/DD */
export function formatDate(ts: number): string {
  const d = new Date(ts);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}/${m}/${day}`;
}

/** 格式化時間為 HH:mm */
export function formatTime(ts: number): string {
  const d = new Date(ts);
  const h = String(d.getHours()).padStart(2, '0');
  const m = String(d.getMinutes()).padStart(2, '0');
  return `${h}:${m}`;
}

/** 簡易車費估算（舊 API，用於向後兼容；建議改用 calcFare） */
export function estimateFare(
  distanceKm: number,
  carType: '4-seater' | '6-seater' = '4-seater',
): number {
  const baseFare = carType === '6-seater' ? 32 : 29;
  const perKm = carType === '6-seater' ? 13 : 9;
  return Math.round(baseFare + Math.max(0, distanceKm - 2) * perKm);
}

export interface FareBreakdown {
  flagfall: number;
  mileageFare: number;
  waitingFare: number;
  nightSurcharge: number;
  luggageSurcharge: number;
  tunnelSurcharge: number;
  comfort6Surcharge: number;
  tip: number;
}

export interface FareResult {
  total: number;
  breakdown: FareBreakdown;
  taxiType: TaxiType;
  taxiTypeName: string;
  taxiTypeColor: string;
  isNight: boolean;
  distanceKm: number;
  waitingMinutes: number;
}

// 香港三區的士跳錶費率（示範近似值，參考運輸署收費錶）
const RATES = {
  urban: {
    // 市區的士（紅的）
    name: '市區的士（紅的）',
    color: 'red',
    flagfall: 29, // 起表（首 2 公里）
    per200m: 1.9, // 其後每 200 米
    waitingPerMin: 1.9, // 等候每分鐘（約等於每 200 米收費）
    nightSurchargePct: 0, // 市區的士夜間附加費已包含在跳錶內（示範用 0%，實際由里程費調整）
    firstBaggage: 6, // 第一件行李
    perExtraBaggage: 6, // 其後每件
    crossHarbourTunnel: 25, // 過海隧道附加費（示範近似）
    eastTunnel: 30, // 東隧
    westTunnel: 65, // 西隧
  },
  'new-territories': {
    // 新界的士（綠的）
    name: '新界的士（綠的）',
    color: 'green',
    flagfall: 23.5,
    per200m: 1.7,
    waitingPerMin: 1.7,
    nightSurchargePct: 0,
    firstBaggage: 6,
    perExtraBaggage: 6,
    crossHarbourTunnel: 0, // 新界的士唔過海
    eastTunnel: 0,
    westTunnel: 0,
  },
  lantau: {
    // 大嶼山的士（藍的）
    name: '大嶼山的士（藍的）',
    color: 'blue',
    flagfall: 22,
    per200m: 1.7,
    waitingPerMin: 1.7,
    nightSurchargePct: 0,
    firstBaggage: 6,
    perExtraBaggage: 6,
    crossHarbourTunnel: 0,
    eastTunnel: 0,
    westTunnel: 0,
  },
  comfort6: {
    // 6 人車 Comfort 跨區
    name: '6 人車（跨區大車）',
    color: 'comfort',
    flagfall: 35, // 6 人車起錶價
    per200m: 2.5,
    waitingPerMin: 2.5,
    nightSurchargePct: 0,
    firstBaggage: 6,
    perExtraBaggage: 6,
    crossHarbourTunnel: 25,
    eastTunnel: 30,
    westTunnel: 65,
  },
};

/** 用地標名稱找 zone */
function findZone(name: string): TaxiZone {
  const lm = MOCK_LANDMARKS.find((l) => l.name === name);
  return lm?.zone ?? 'urban';
}

/** 判斷係咪夜間時段（23:00 - 06:00） */
function isNightTime(d: Date): boolean {
  const h = d.getHours();
  return h >= 23 || h < 6;
}

/** 將經緯度轉換為 SVG canvas 坐標 */
export function latLngToSvg(
  lat: number,
  lng: number,
  bounds: { minLat: number; maxLat: number; minLng: number; maxLng: number },
  width: number,
  height: number,
): { x: number; y: number } {
  const x = ((lng - bounds.minLng) / (bounds.maxLng - bounds.minLng)) * width;
  const y = ((bounds.maxLat - lat) / (bounds.maxLat - bounds.minLat)) * height;
  return { x, y };
}

/** 用名稱搵地標計算直線距離，再乘以路線係數（1.3 為香港道路網估算） */
export function calcDistanceKm(pickup: string, destination: string): number {
  const p = MOCK_LANDMARKS.find((l) => l.name === pickup);
  const d = MOCK_LANDMARKS.find((l) => l.name === destination);
  if (!p || !d) return 3.0;
  const straight = haversineKm(p, d);
  // 香港道路網實際行車距離約為直線 1.25-1.4 倍
  return Math.max(0.5, straight * 1.3);
}

/**
 * 計算的士車費
 * @param pickup 上車地點名稱
 * @param destination 目的地名稱
 * @param carType '4-seater' | '6-seater'
 * @param options.tip 貼士金額
 * @param options.luggageCount 行李件數
 * @param options.waitingMinutes 等候時間（分鐘）
 * @param options.time 計費時間（用於判斷夜間附加費）
 */
export function calcFare(
  pickup: string,
  destination: string,
  carType: '4-seater' | '6-seater',
  options?: {
    tip?: number;
    luggageCount?: number;
    waitingMinutes?: number;
    time?: Date;
  },
): FareResult {
  const tip = options?.tip ?? 0;
  const luggage = options?.luggageCount ?? 0;
  const waitingMin = options?.waitingMinutes ?? 0;
  const now = options?.time ?? new Date();
  const isNight = isNightTime(now);

  // 判斷的士類型
  const pickupZone = findZone(pickup);
  const destZone = findZone(destination);

  let taxiType: TaxiType;
  if (carType === '6-seater') {
    taxiType = 'comfort6';
  } else {
    // 4 人車：起終點都係新界區內 → 綠的；都係大嶼山區內 → 藍的；其他 → 紅的
    const bothNT = pickupZone === 'new-territories' && destZone === 'new-territories';
    const bothLantau = pickupZone === 'lantau' && destZone === 'lantau';
    if (bothLantau) {
      taxiType = 'lantau';
    } else if (bothNT) {
      taxiType = 'nt';
    } else {
      taxiType = 'urban';
    }
  }

  const rate = RATES[taxiType];
  const distanceKm = calcDistanceKm(pickup, destination);

  // 里程費：首 2 公里起表，其後每 200 米
  const remainingKm = Math.max(0, distanceKm - 2);
  const num200m = Math.ceil((remainingKm * 1000) / 200);
  const mileageFare = num200m * rate.per200m;

  // 等候費
  const waitingFare = Math.ceil(waitingMin) * rate.waitingPerMin;

  // 行李附加費
  let luggageSurcharge = 0;
  if (luggage > 0) {
    luggageSurcharge = rate.firstBaggage + Math.max(0, luggage - 1) * rate.perExtraBaggage;
  }

  // 隧道附加費：港島 ↔ 九龍 過海
  let tunnelSurcharge = 0;
  const pickupIsIsland = pickupZone === 'urban';
  const destIsIsland = destZone === 'urban';
  const pickupIsKowloon = pickupZone === 'urban'; // 示範：urban 同時包含港島同九龍
  const destIsKowloon = destZone === 'urban';
  // 用經度粗略判斷：港島 lng < 114.175，九龍 lng > 114.175
  const p = MOCK_LANDMARKS.find((l) => l.name === pickup);
  const d = MOCK_LANDMARKS.find((l) => l.name === destination);
  if (p && d) {
    const pIsHKI = p.lat < 22.3 && p.zone === 'urban'; // 港島
    const pIsKLN = p.lat >= 22.3 && p.zone === 'urban'; // 九龍
    const dIsHKI = d.lat < 22.3 && d.zone === 'urban';
    const dIsKLN = d.lat >= 22.3 && d.zone === 'urban';
    if ((pIsHKI && dIsKLN) || (pIsKLN && dIsHKI)) {
      // 過海：示範用紅隧收費
      tunnelSurcharge = rate.crossHarbourTunnel;
    }
  }
  // 避免 ts 未用警告
  void pickupIsIsland; void destIsIsland; void pickupIsKowloon; void destIsKowloon;

  // 夜間附加費（示範：額外 +10% 里程費；真實夜間已反映在跳錶費率）
  const nightSurcharge = isNight ? (mileageFare + rate.flagfall) * 0.1 : 0;

  // 6 人車附加費：獨立計算（comfort6 費率本身已較高，唔再加額外 %）
  const comfort6Surcharge = 0;

  const subtotal =
    rate.flagfall + mileageFare + waitingFare + nightSurcharge +
    luggageSurcharge + tunnelSurcharge + comfort6Surcharge;

  const total = Math.round(subtotal + tip);

  return {
    total,
    breakdown: {
      flagfall: rate.flagfall,
      mileageFare: Number(mileageFare.toFixed(1)),
      waitingFare: Number(waitingFare.toFixed(1)),
      nightSurcharge: Number(nightSurcharge.toFixed(1)),
      luggageSurcharge: Number(luggageSurcharge.toFixed(1)),
      tunnelSurcharge,
      comfort6Surcharge,
      tip,
    },
    taxiType,
    taxiTypeName: rate.name,
    taxiTypeColor: rate.color,
    isNight,
    distanceKm,
    waitingMinutes: waitingMin,
  };
}
