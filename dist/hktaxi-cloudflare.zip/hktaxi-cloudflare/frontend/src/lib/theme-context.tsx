import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';
import { scopedStorage, logger } from '@lark-apaas/client-toolkit-lite';

export type TaxiTheme = 'red' | 'green'; // 紅的 / 綠的

interface ThemeContextValue {
  theme: TaxiTheme;
  setTheme: (t: TaxiTheme) => void;
  toggleTheme: () => void;
  primaryColor: string; // 用於 inline style 或動態圖
}

const ThemeContext = createContext<ThemeContextValue | null>(null);

const THEME_KEY = 'hktaxi_taxiTheme';

function readTheme(): TaxiTheme {
  const raw = scopedStorage.getItem(THEME_KEY);
  if (raw === 'green') return 'green';
  return 'red';
}

function writeTheme(t: TaxiTheme) {
  scopedStorage.setItem(THEME_KEY, t);
}

function applyThemeVars(theme: TaxiTheme) {
  const root = document.documentElement;
  // 淺色主題基礎
  root.style.setProperty('--background', 'hsl(210 40% 98%)');
  root.style.setProperty('--foreground', 'hsl(222 20% 12%)');
  root.style.setProperty('--card', 'hsl(0 0% 100%)');
  root.style.setProperty('--card-foreground', 'hsl(222 20% 12%)');
  root.style.setProperty('--muted', 'hsl(220 15% 96%)');
  root.style.setProperty('--muted-foreground', 'hsl(220 10% 45%)');
  root.style.setProperty('--border', 'hsl(220 13% 91%)');
  root.style.setProperty('--input', 'hsl(220 13% 91%)');
  root.style.setProperty('--accent', 'hsl(220 15% 96%)');
  root.style.setProperty('--accent-foreground', 'hsl(222 20% 18%)');
  root.style.setProperty('--popover', 'hsl(0 0% 100%)');
  root.style.setProperty('--popover-foreground', 'hsl(222 20% 12%)');
  root.style.setProperty('--sidebar', 'hsl(210 40% 98%)');
  root.style.setProperty('--sidebar-foreground', 'hsl(222 20% 12%)');
  root.style.setProperty('--sidebar-border', 'hsl(220 13% 91%)');
  root.style.setProperty('--sidebar-accent', 'hsl(220 15% 96%)');
  root.style.setProperty('--sidebar-accent-foreground', 'hsl(222 20% 18%)');

  if (theme === 'green') {
    // 新界綠的 - 翠綠主題
    root.style.setProperty('--primary', 'hsl(145 65% 38%)');
    root.style.setProperty('--primary-foreground', 'hsl(0 0% 100%)');
    root.style.setProperty('--ring', 'hsl(145 65% 38%)');
    root.style.setProperty('--chart-1', 'hsl(145 65% 38%)');
    root.style.setProperty('--sidebar-primary', 'hsl(145 65% 38%)');
    root.style.setProperty('--sidebar-primary-foreground', 'hsl(0 0% 100%)');
  } else {
    // 市區紅的 - 亮紅主題（預設）
    root.style.setProperty('--primary', 'hsl(355 85% 52%)');
    root.style.setProperty('--primary-foreground', 'hsl(0 0% 100%)');
    root.style.setProperty('--ring', 'hsl(355 85% 52%)');
    root.style.setProperty('--chart-1', 'hsl(355 85% 52%)');
    root.style.setProperty('--sidebar-primary', 'hsl(355 85% 52%)');
    root.style.setProperty('--sidebar-primary-foreground', 'hsl(0 0% 100%)');
  }
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<TaxiTheme>(() => readTheme());

  useEffect(() => {
    try {
      applyThemeVars(theme);
      writeTheme(theme);
    } catch (e) {
      logger.error('applyTheme failed:', String(e));
    }
  }, [theme]);

  const setTheme = useCallback((t: TaxiTheme) => {
    setThemeState(t);
  }, []);

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => (prev === 'red' ? 'green' : 'red'));
  }, []);

  const primaryColor = theme === 'green' ? 'hsl(145, 65%, 38%)' : 'hsl(355, 85%, 52%)';

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, primaryColor }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
