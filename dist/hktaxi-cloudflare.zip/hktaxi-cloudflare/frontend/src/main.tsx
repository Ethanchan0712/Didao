import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { ErrorBoundary } from 'react-error-boundary';
import App from './app';
import './index.css';

// Cloudflare 獨立部署版入口
// 移除咗飛書 AppContainer / ErrorRender 依賴，用原生 ErrorBoundary 代替

function ErrorFallback({ error, resetErrorBoundary }: { error: unknown; resetErrorBoundary: () => void }) {
  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center p-6">
      <div className="max-w-md w-full bg-card border border-border rounded-xl p-6 shadow-lg">
        <h2 className="text-xl font-bold mb-2">出咗啲問題</h2>
        <p className="text-sm text-muted-foreground mb-4">
          網頁遇到預期之外嘅錯誤，你可以試下重新載入。
        </p>
        <pre className="text-xs bg-muted p-3 rounded-md overflow-auto max-h-40 mb-4">
          {error instanceof Error ? error.message : String(error)}
        </pre>
        <button
          onClick={resetErrorBoundary}
          className="w-full bg-primary text-primary-foreground px-4 py-2 rounded-lg font-medium hover:opacity-90 transition-opacity"
        >
          重試
        </button>
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <BrowserRouter>
      <ErrorBoundary FallbackComponent={ErrorFallback}>
        <App />
      </ErrorBoundary>
    </BrowserRouter>
  </StrictMode>,
);
