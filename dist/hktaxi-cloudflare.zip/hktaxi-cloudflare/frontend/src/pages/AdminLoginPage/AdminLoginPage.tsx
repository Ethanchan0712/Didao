import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Lock, User, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { Image } from '@/components/ui/image';
import { useI18n } from '@/lib/i18n';
import { adminLogin } from '@/lib/api';
import { setAdminAuth } from '@/lib/admin-auth';

const LOGO_URL = 'https://aka.doubaocdn.com/s/1L23UMNBh7';

export default function AdminLoginPage() {
  const navigate = useNavigate();
  const { t } = useI18n();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('請輸入帳號同密碼');
      return;
    }

    setLoading(true);
    try {
      const data = await adminLogin({ username, password });
      setAdminAuth(data.token, data.admin);
      toast.success('登入成功');
      navigate('/admin');
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || '帳號或密碼錯誤';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      {/* Header */}
      <div className="px-4 pt-6 pb-2">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate('/')}
            className="size-10 rounded-full bg-card flex items-center justify-center hover:bg-accent transition-colors"
          >
            <ArrowLeft className="size-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold">{t.admin.login}</h1>
             <p className="text-sm text-slate-400">{t.admin.title}</p>
          </div>
        </div>
      </div>

      {/* Logo + brand */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center justify-center py-12"
      >
        <div className="relative">
          <Image
            src={LOGO_URL}
            alt="的道"
            className="size-20 rounded-full object-cover ring-4 ring-primary/30 shadow-xl shadow-primary/20"
          />
          <div className="absolute -bottom-1 -right-1 size-7 rounded-full bg-emerald-500 flex items-center justify-center ring-4 ring-slate-900">
            <ShieldCheck className="size-4 text-primary-foreground" />
          </div>
        </div>
        <h2 className="text-lg font-bold mb-1">{t.admin.title}</h2>
        <p className="text-sm text-slate-400 mt-1">香港的士叫車平台</p>
      </motion.div>

      {/* Login form */}
      <div className="px-6 flex-1">
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          onSubmit={handleSubmit}
          className="max-w-sm mx-auto space-y-4"
        >
          <Card className="bg-card bg-card border-border backdrop-blur">
            <CardContent className="p-5 space-y-4">
              {/* Username */}
              <div className="space-y-1.5">
                <Label htmlFor="username" className="text-xs text-slate-400">
                  帳號
                </Label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
                  <Input
                    id="username"
                    type="text"
                    value={username}
                    onChange={(e) => {
                      setUsername(e.target.value);
                      setError('');
                    }}
                    placeholder="請輸入管理員帳號"
                    className="bg-muted border-border pl-9 text-foreground placeholder:text-muted-foreground focus:border-primary h-11"
                    autoComplete="username"
                  />
                </div>
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-xs text-slate-400">
                  密碼
                </Label>
                <div className="relative">
                  <Lock className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setError('');
                    }}
                    placeholder="請輸入密碼"
                    className="bg-muted border-border pl-9 pr-10 text-foreground placeholder:text-muted-foreground focus:border-primary h-11"
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 size-8 rounded-md flex items-center justify-center text-slate-500 hover:text-muted-foreground transition-colors"
                    aria-label={showPassword ? '隱藏密碼' : '顯示密碼'}
                  >
                    {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                  </button>
                </div>
              </div>

              {/* Error message */}
              {error && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-sm text-red-400 flex items-center gap-2"
                >
                  <span className="size-1.5 rounded-full bg-red-500 shrink-0" />
                  {error}
                </motion.div>
              )}

              {/* Submit */}
              <Button
                type="submit"
                size="lg"
                className="w-full h-12 rounded-xl font-semibold shadow-lg shadow-primary/25"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="size-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2" />
                    {t.admin.signIn}中...
                  </>
                ) : (
                  '登入'
                )}
              </Button>
            </CardContent>
          </Card>

          <p className="text-xs text-slate-500 text-center px-4">
            只限授權管理員使用 · 請妥善保管登入資料
          </p>
        </motion.form>
      </div>

      <div className="pb-8 pt-4 text-center text-xs text-slate-600">
        © 2026 的道 · 香港示範版
      </div>
    </div>
  );
}
