import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Car,
  User,
  Check,
  X,
  Clock,
  ShieldCheck,
  ShieldX,
  Users,
  Search,
  AlertCircle,
  LogOut,
  Wallet,
  Receipt,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import * as api from '@/lib/api';
import { getAdminToken, clearAdminToken } from '@/lib/admin-auth';
import { Image } from '@/components/ui/image';
import { useI18n } from '@/lib/i18n';

const LOGO_URL = 'https://aka.doubaocdn.com/s/1L23UMNBh7';

interface IDriverApp {
  id: string;
  username: string;
  name: string;
  phone: string;
  plate: string;
  carModel: string;
  driverLicense: string;
  status: 'pending' | 'approved' | 'rejected';
  rating: number;
  ratingCount: number;
  createdAt: number;
  reviewedAt?: number;
  rejectReason?: string;
}

interface IAdminOrder {
  id: string;
  pickupName: string;
  destinationName: string;
  passengerName: string;
  driverName: string;
  status: string;
  estimatedFare: number;
  actualFare?: number;
  createdAt: number;
  carType: string;
}

export default function AdminPage() {
  const navigate = useNavigate();
  const { t } = useI18n();
  const [keyword, setKeyword] = useState('');
  const [activeTab, setActiveTab] = useState<string>('pending');
  const [rejectDialog, setRejectDialog] = useState<IDriverApp | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [apps, setApps] = useState<IDriverApp[]>([]);
  const [orders, setOrders] = useState<IAdminOrder[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [ordersTab, setOrdersTab] = useState('all');

  // 登入守衛
  useEffect(() => {
    if (!getAdminToken()) {
      navigate('/admin/login', { replace: true });
    }
  }, [navigate]);

  const loadDrivers = useCallback(async (status: string) => {
    try {
      const data = await api.getAdminDrivers(status);
      setApps(data.drivers.map((d: any) => ({
        id: d.id,
        username: d.username,
        name: d.name,
        phone: d.phone,
        plate: d.plate,
        carModel: d.carModel,
        driverLicense: d.driverLicense,
        status: d.status,
        rating: d.rating,
        ratingCount: d.ratingCount,
        createdAt: new Date(d.createdAt).getTime(),
        reviewedAt: d.reviewedAt ? new Date(d.reviewedAt).getTime() : undefined,
        rejectReason: d.rejectReason,
      })));
    } catch {
      setApps([]);
    }
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const s = await api.getAdminStats();
      setStats(s);
    } catch {
      setStats(null);
    }
  }, []);

  const loadOrders = useCallback(async (status: string) => {
    try {
      const data = await api.getAdminOrders(status === 'all' ? undefined : status);
      setOrders(data.orders.map((o: any) => ({
        id: o.id,
        pickupName: o.pickupName,
        destinationName: o.destinationName,
        passengerName: o.passengerName,
        driverName: o.driverName,
        status: o.status,
        estimatedFare: o.estimatedFare,
        actualFare: o.actualFare,
        createdAt: new Date(o.createdAt).getTime(),
        carType: o.carType,
      })));
    } catch {
      setOrders([]);
    }
  }, []);

  useEffect(() => {
    let cancelled = false;
    async function init() {
      setLoading(true);
      await Promise.all([
        loadDrivers(activeTab),
        loadStats(),
        loadOrders(ordersTab),
      ]);
      if (!cancelled) setLoading(false);
    }
    init();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // SSE 實時更新
  useEffect(() => {
    if (!getAdminToken()) return;
    let es: EventSource | null = null;
    try {
      es = api.createAdminStream();
      es.addEventListener('driver-application-updated', () => {
        loadDrivers(activeTab);
        loadStats();
      });
      es.addEventListener('order-updated', () => {
        loadOrders(ordersTab);
        loadStats();
      });
    } catch {
      // ignore
    }
    return () => {
      if (es) es.close();
    };
  }, [activeTab, ordersTab, loadDrivers, loadOrders, loadStats]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    loadDrivers(tab);
  };

  const handleOrdersTabChange = (tab: string) => {
    setOrdersTab(tab);
    loadOrders(tab);
  };

  const handleLogout = () => {
    clearAdminToken();
    toast.success('已登出');
    navigate('/admin/login', { replace: true });
  };

  const filtered = apps.filter((app) => {
    if (!keyword) return true;
    const kw = keyword.toLowerCase();
    return (
      app.name.includes(keyword) ||
      app.plate.toLowerCase().includes(kw) ||
      app.driverLicense.toLowerCase().includes(kw)
    );
  });

  const filteredOrders = orders.filter((o) => {
    if (!keyword) return true;
    return (
      o.pickupName.includes(keyword) ||
      o.destinationName.includes(keyword) ||
      o.passengerName.includes(keyword) ||
      o.driverName.includes(keyword)
    );
  });

  const pendingCount = stats?.pendingDrivers ?? 0;
  const approvedCount = stats?.approvedDrivers ?? 0;
  const totalOrders = stats?.totalOrders ?? 0;
  const totalRevenue = stats?.totalRevenue ?? 0;

  const handleApprove = async (app: IDriverApp) => {
    try {
      await api.approveDriver(app.id);
      toast.success(`已批准 ${app.name} 嘅申請`);
      loadDrivers(activeTab);
      loadStats();
    } catch (e: any) {
      toast.error(e?.response?.data?.error || '操作失敗');
    }
  };

  const handleReject = async () => {
    if (!rejectDialog) return;
    if (!rejectReason.trim()) {
      toast.error('請填寫拒絕原因');
      return;
    }
    try {
      await api.rejectDriver(rejectDialog.id, rejectReason.trim());
      toast.success(`已拒絕 ${rejectDialog.name} 嘅申請`);
      setRejectDialog(null);
      setRejectReason('');
      loadDrivers(activeTab);
      loadStats();
    } catch (e: any) {
      toast.error(e?.response?.data?.error || '操作失敗');
    }
  };

  const openRejectDialog = (app: IDriverApp) => {
    setRejectDialog(app);
    setRejectReason('');
  };

  const statusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return (
          <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/30">
            <Clock className="size-3 mr-1" />
            待審批
          </Badge>
        );
      case 'approved':
        return (
          <Badge variant="outline" className="bg-emerald-500/10 text-emerald-500 border-emerald-500/30">
            <ShieldCheck className="size-3 mr-1" />
            已開通
          </Badge>
        );
      case 'rejected':
        return (
          <Badge variant="outline" className="bg-red-500/10 text-red-500 border-red-500/30">
            <ShieldX className="size-3 mr-1" />
            已拒絕
          </Badge>
        );
      default:
        return (
          <Badge variant="outline">{status}</Badge>
        );
    }
  };

  const orderStatusBadge = (status: string) => {
    const map: Record<string, { label: string; cls: string }> = {
      searching: { label: '尋找司機', cls: 'bg-amber-500/10 text-amber-400 border-amber-500/30' },
      accepted: { label: '已接單', cls: 'bg-blue-500/10 text-blue-400 border-blue-500/30' },
      picked_up: { label: '行車中', cls: 'bg-purple-500/10 text-purple-400 border-purple-500/30' },
      completed: { label: '到達', cls: 'bg-orange-500/10 text-orange-400 border-orange-500/30' },
      paid: { label: '已付款', cls: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' },
      finished: { label: '已完成', cls: 'bg-slate-500/10 text-slate-400 border-slate-500/30' },
      cancelled: { label: '已取消', cls: 'bg-red-500/10 text-red-400 border-red-500/30' },
    };
    const s = map[status] ?? { label: status, cls: '' };
    return (
      <Badge variant="outline" className={s.cls}>{s.label}</Badge>
    );
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return d.toLocaleString('zh-HK', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-8">
      {/* Header */}
      <div className="bg-background/95 backdrop-blur-lg border-b border-border sticky top-0 z-40">
        <div className="px-4 pt-5 pb-4">
          <div className="flex items-center gap-3 mb-4">
            <Image
              src={LOGO_URL}
              alt="的道"
              className="size-10 rounded-full object-cover ring-2 ring-primary/30"
            />
            <div className="flex-1 min-w-0">
              <h1 className="text-lg font-bold">的道 · 管理後台</h1>
              <p className="text-xs text-muted-foreground">司機審批 · 訂單管理 · 數據統計</p>
            </div>
            <button
              onClick={handleLogout}
              className="size-10 rounded-full bg-card flex items-center justify-center hover:bg-accent transition-colors shrink-0"
              title="登出"
            >
              <LogOut className="size-4 text-muted-foreground" />
            </button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-2">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-center">
              <div className="text-xl font-black text-amber-400 tabular-nums">{pendingCount}</div>
              <div className="text-[10px] text-amber-300/70">待審批</div>
            </div>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-center">
              <div className="text-xl font-black text-emerald-400 tabular-nums">{approvedCount}</div>
              <div className="text-[10px] text-emerald-300/70">已開通</div>
            </div>
            <div className="p-2.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-center">
              <div className="text-xl font-black text-blue-400 tabular-nums">{totalOrders}</div>
              <div className="text-[10px] text-blue-300/70">總訂單</div>
            </div>
            <div className="p-2.5 rounded-xl bg-purple-500/10 border border-purple-500/20 text-center">
              <div className="text-sm font-black text-purple-400 tabular-nums mt-1">HK${totalRevenue}</div>
              <div className="text-[10px] text-purple-300/70">總營業額</div>
            </div>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 mt-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="搜尋司機名/車牌/乘客/地點..."
            className="bg-card border-border pl-9 text-foreground placeholder:text-muted-foreground focus:border-primary h-11"
          />
        </div>
      </div>

      {/* Main tabs: drivers / orders */}
      <div className="px-4 mt-4">
        <Tabs value={activeTab === 'orders' ? 'orders' : 'drivers'} onValueChange={(v) => v === 'orders' ? setActiveTab('orders') : handleTabChange('pending')}>
          <TabsList className="w-full bg-card p-1">
            <TabsTrigger value="drivers" className="flex-1">司機管理</TabsTrigger>
            <TabsTrigger value="orders" className="flex-1">訂單列表</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Driver management */}
      {activeTab !== 'orders' && (
        <>
          {/* Driver sub-tabs */}
          <div className="px-4 mt-3">
            <Tabs value={activeTab} onValueChange={handleTabChange}>
              <TabsList className="w-full bg-card p-1">
                <TabsTrigger value="pending" className="flex-1 data-[state=active]:bg-accent">
                  待審批
                  {pendingCount > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.5 rounded-full bg-amber-500 text-white text-[10px] font-bold">
                      {pendingCount}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="approved" className="flex-1 data-[state=active]:bg-accent">已開通</TabsTrigger>
                <TabsTrigger value="rejected" className="flex-1 data-[state=active]:bg-accent">已拒絕</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          {/* Application list */}
          <div className="px-4 mt-4 space-y-3">
            <AnimatePresence mode="popLayout">
              {loading ? (
                <div className="text-center py-12 text-sm text-muted-foreground">載入中...</div>
              ) : filtered.length === 0 ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="flex flex-col items-center justify-center py-16 text-center"
                >
                  <div className="size-16 rounded-full bg-muted flex items-center justify-center mb-4">
                    <Users className="size-8 text-slate-600" />
                  </div>
                  <div className="text-sm text-slate-400">
                    {activeTab === 'pending'
                      ? '暫無待審批嘅申請'
                      : activeTab === 'approved'
                        ? '仲未有已開通嘅司機'
                        : activeTab === 'rejected'
                          ? '暫無被拒絕嘅申請'
                          : '仲冇任何申請記錄'}
                  </div>
                </motion.div>
              ) : (
                filtered.map((app, i) => (
                  <motion.div
                    key={app.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05, duration: 0.3 }}
                    layout
                  >
                    <Card className="bg-card border-border">
                      <CardContent className="p-4 space-y-3">
                        <div className="flex items-start gap-3">
                          <div className="size-11 rounded-full bg-accent/50 flex items-center justify-center shrink-0">
                            <User className="size-5 text-slate-400" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between gap-2 mb-0.5">
                              <span className="font-semibold text-foreground truncate">{app.name}</span>
                              {statusBadge(app.status)}
                            </div>
                            <div className="text-xs text-muted-foreground font-mono">
                              {app.driverLicense} · {app.plate}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Car className="size-3.5" />
                          <span>{app.carModel}</span>
                        </div>

                        <div className="flex items-center justify-between text-xs pt-2 border-t border-border">
                          <div className="text-muted-foreground">
                            申請：{formatDate(app.createdAt)}
                          </div>
                          {app.reviewedAt && (
                            <div className="text-muted-foreground">
                              審批：{formatDate(app.reviewedAt)}
                            </div>
                          )}
                        </div>

                        {app.status === 'rejected' && app.rejectReason && (
                          <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-xs">
                            <div className="flex items-center gap-2 text-red-400 font-medium mb-1">
                              <AlertCircle className="size-3.5" />
                              拒絕原因
                            </div>
                            <div className="text-red-300/80">{app.rejectReason}</div>
                          </div>
                        )}

                        {app.status === 'pending' && (
                          <div className="flex gap-2 pt-2">
                            <Button
                              size="sm"
                              className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white"
                              onClick={() => handleApprove(app)}
                            >
                              <Check className="size-4 mr-1" />
                              批准
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="flex-1"
                              onClick={() => openRejectDialog(app)}
                            >
                              <X className="size-4 mr-1" />
                              拒絕
                            </Button>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </motion.div>
                ))
              )}
            </AnimatePresence>
          </div>
        </>
      )}

      {/* Orders management */}
      {activeTab === 'orders' && (
        <>
          <div className="px-4 mt-3">
            <Tabs value={ordersTab} onValueChange={handleOrdersTabChange}>
              <TabsList className="w-full bg-card p-1">
                <TabsTrigger value="all" className="flex-1 data-[state=active]:bg-accent">全部</TabsTrigger>
                <TabsTrigger value="paid" className="flex-1 data-[state=active]:bg-accent">已完成</TabsTrigger>
                <TabsTrigger value="picked_up" className="flex-1 data-[state=active]:bg-accent">行車中</TabsTrigger>
                <TabsTrigger value="searching" className="flex-1 data-[state=active]:bg-accent">尋找中</TabsTrigger>
              </TabsList>
            </Tabs>
          </div>

          <div className="px-4 mt-4 space-y-2">
            {loading ? (
              <div className="text-center py-12 text-sm text-muted-foreground">載入中...</div>
            ) : filteredOrders.length === 0 ? (
              <div className="text-center py-16">
                <div className="size-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                  <Receipt className="size-8 text-slate-600" />
                </div>
                <div className="text-sm text-slate-400">暫無訂單記錄</div>
              </div>
            ) : (
              filteredOrders.map((o, i) => (
                <motion.div
                  key={o.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                >
                  <Card className="bg-card border-border">
                    <CardContent className="p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs text-muted-foreground font-mono">{o.id.slice(0, 8)}</span>
                        {orderStatusBadge(o.status)}
                      </div>
                      <div className="flex items-start gap-2 mb-2">
                        <div className="flex flex-col items-center pt-0.5">
                          <div className="size-2 rounded-full bg-emerald-400" />
                          <div className="w-px h-5 bg-slate-600 my-0.5" />
                          <div className="size-2 rounded-full bg-red-400" />
                        </div>
                        <div className="flex-1 min-w-0 space-y-0.5">
                          <div className="text-sm font-medium text-foreground truncate">{o.pickupName}</div>
                          <div className="text-sm font-medium text-foreground truncate">{o.destinationName}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-bold text-foreground">
                            HK${(o.actualFare ?? o.estimatedFare).toFixed(0)}
                          </div>
                          <div className="text-[10px] text-muted-foreground">
                            {o.carType === '6-seater' ? '6人車' : '4人車'}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between text-[11px] text-muted-foreground pt-2 border-t border-border">
                        <span>乘客：{o.passengerName || '-'}</span>
                        <span>司機：{o.driverName || '-'}</span>
                      </div>
                      <div className="text-[11px] text-muted-foreground mt-1">
                        {formatDate(o.createdAt)}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            )}
          </div>
        </>
      )}

      {/* Reject dialog */}
      <Dialog open={!!rejectDialog} onOpenChange={(open) => !open && setRejectDialog(null)}>
        <DialogContent className="bg-card border-border text-foreground">
          <DialogHeader>
            <DialogTitle>拒絕申請</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="text-sm text-muted-foreground">
              確定拒絕 <span className="text-foreground font-medium">{rejectDialog?.name}</span> 嘅司機申請？
            </div>
            <div>
              <label className="text-sm font-medium mb-1.5 block">拒絕原因</label>
              <Textarea
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="請填寫拒絕原因..."
                className="bg-background border-border min-h-[80px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRejectDialog(null)}>取消</Button>
            <Button variant="destructive" onClick={handleReject}>確認拒絕</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
