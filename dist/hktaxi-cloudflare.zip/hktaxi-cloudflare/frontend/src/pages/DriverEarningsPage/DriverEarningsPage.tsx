import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Wallet,
  TrendingUp,
  MapPin,
  Navigation,
  Receipt,
  Calendar,
  MessageCircle,
  X,
} from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/lib/i18n';
import * as api from '@/lib/api';

interface IEarning {
  orderId: string;
  amount: number;
  pickup: string;
  destination: string;
  createdAt: number;
  passengerRating?: number;
  passengerName?: string;
}

export default function DriverEarningsPage() {
  const [tab, setTab] = useState('today');
  const [allOrders, setAllOrders] = useState<IEarning[]>([]);
  const [loading, setLoading] = useState(true);
  const { t } = useI18n();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const orders = await api.getDriverEarnings();
        if (cancelled) return;
        const mapped: IEarning[] = orders.map((o: any) => ({
          orderId: o.id,
          amount: o.actualFare ?? o.estimatedFare,
          pickup: o.pickupName,
          destination: o.destinationName,
          createdAt: new Date(o.createdAt).getTime(),
          passengerRating: o.passengerRating ?? undefined,
          passengerName: o.passengerName,
        }));
        setAllOrders(mapped);
      } catch {
        setAllOrders([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const todayStart = today.getTime();
  const weekStart = todayStart - 86400000 * 6;
  const monthStart = todayStart - 86400000 * 29;

  const filtered = allOrders.filter((e) => {
    if (tab === 'today') return e.createdAt >= todayStart;
    if (tab === 'week') return e.createdAt >= weekStart;
    return e.createdAt >= monthStart;
  });

  const totalEarning = filtered.reduce((sum, e) => sum + e.amount, 0);
  const totalOrders = filtered.length;

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return `${d.getMonth() + 1}月${d.getDate()}日`;
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background pb-24 text-foreground">
      {/* Header */}
      <div className="px-4 pt-6 pb-4">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 mb-4"
        >
          <div className="size-10 rounded-full bg-emerald-500/20 flex items-center justify-center">
            <Wallet className="size-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold">{t.driverEarnings.title}</h1>
            <p className="text-xs text-muted-foreground">收入記錄</p>
          </div>
        </motion.div>

        {/* Summary card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <Card className="bg-gradient-to-br from-emerald-500 to-emerald-600 border-0 shadow-lg shadow-emerald-500/30 text-white">
            <CardContent className="p-5">
              <div className="text-xs opacity-80 mb-1 flex items-center gap-1">
                <Calendar className="size-3.5" />
                {tab === 'today' ? '今日收入' : tab === 'week' ? '本週收入' : '本月收入'}
              </div>
              <div className="text-4xl font-black tabular-nums mb-3">
                HK${totalEarning.toFixed(0)}
                <span className="text-base font-normal opacity-70 ml-1">.00</span>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1.5 opacity-90">
                  <Receipt className="size-4" />
                  {totalOrders} 單
                </div>
                <div className="flex items-center gap-1.5 opacity-90">
                  <TrendingUp className="size-4" />
                  每單平均 HK${totalOrders > 0 ? Math.round(totalEarning / totalOrders) : 0}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Tabs */}
      <div className="px-4 mb-3">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="w-full bg-slate-800/50">
            <TabsTrigger value="today" className="flex-1">今日</TabsTrigger>
            <TabsTrigger value="week" className="flex-1">本週</TabsTrigger>
            <TabsTrigger value="month" className="flex-1">本月</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* List */}
      <div className="px-4 space-y-3">
        {loading ? (
          <div className="text-center py-12 text-sm text-muted-foreground">載入中...</div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16">
            <div className="size-16 mx-auto mb-4 rounded-full bg-slate-800 flex items-center justify-center">
              <Wallet className="size-8 text-slate-600" />
            </div>
            <div className="text-foreground font-medium mb-1">暫無收入記錄</div>
            <div className="text-sm text-muted-foreground">
              {tab === 'today' ? '今日仲未接單㗎' : tab === 'week' ? '本週暫無記錄' : '本月暫無記錄'}
            </div>
          </div>
        ) : (
          filtered.map((item, i) => (
            <motion.div
              key={item.orderId}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.03 }}
            >
              <Card className="bg-card bg-card border-border shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-xs text-muted-foreground">
                      {formatDate(item.createdAt)} {formatTime(item.createdAt)}
                    </div>
                    <Badge variant="outline" className="text-xs border-border text-emerald-400">
                      已完成
                    </Badge>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex flex-col items-center pt-1">
                      <div className="size-2.5 rounded-full bg-emerald-400" />
                      <div className="w-px h-6 bg-slate-600 my-0.5" />
                      <div className="size-2.5 rounded-full bg-red-400" />
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="text-sm font-medium text-foreground truncate">
                        {item.pickup}
                      </div>
                      <div className="text-sm font-medium text-foreground truncate">
                        {item.destination}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-emerald-400">
                        +HK${item.amount.toFixed(0)}
                      </div>
                      {item.passengerName && (
                        <div className="text-xs text-muted-foreground">
                          {item.passengerName}
                        </div>
                      )}
                    </div>
                  </div>
                  {item.passengerRating !== undefined && (
                    <div className="mt-3 pt-2 border-t border-border flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">乘客評分</span>
                      <div className="flex items-center gap-0.5 text-amber-400">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <div
                            key={s}
                            className={`size-3 rounded-sm ${
                              s <= item.passengerRating!
                                ? 'bg-amber-400'
                                : 'bg-slate-600'
                            }`}
                          />
                        ))}
                        <span className="ml-1">{item.passengerRating}</span>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
}
