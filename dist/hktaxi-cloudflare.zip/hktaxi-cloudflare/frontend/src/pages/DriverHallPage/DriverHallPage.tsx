import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Car,
  MapPin,
  Navigation,
  DollarSign,
  Bell,
  Clock,
  Check,
  X,
  Zap,
  Phone,
  Mail,
  User,
  Power,
  MessageCircle,
  ChevronRight,
  ShieldAlert,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetDescription } from '@/components/ui/sheet';
import AMapView from '@/components/AMapView';
import { useOrder } from '@/lib/order-context';
import { UniversalLink } from '@lark-apaas/client-toolkit-lite';
import { useI18n } from '@/lib/i18n';
import { useTheme } from '@/lib/theme-context';
import * as api from '@/lib/api';
import { toast } from 'sonner';

export default function DriverHallPage() {
  const { order, driverOnline, setDriverOnline, acceptOrder, rejectOrder, driverVerified, driverApplication } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const { theme } = useTheme();
  const [incomingAnim, setIncomingAnim] = useState(false);
  const [showVerifySheet, setShowVerifySheet] = useState(false);
  const [hallOrders, setHallOrders] = useState<any[]>([]);
  const [loadingHall, setLoadingHall] = useState(true);

  // 初始載入大廳訂單
  useEffect(() => {
    if (!driverVerified || !driverOnline) return;
    let cancelled = false;
    async function load() {
      try {
        const orders = await api.getDriverHallOrders();
        if (!cancelled) {
          setHallOrders(orders);
        }
      } catch {
        // ignore
      } finally {
        if (!cancelled) setLoadingHall(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [driverOnline, driverVerified]);

  const handleToggleOnline = async (checked: boolean) => {
    if (checked && !driverVerified) {
      setShowVerifySheet(true);
      return;
    }
    try {
      await setDriverOnline(checked);
      toast.success(checked ? '已上線' : '已落線');
    } catch {
      toast.error('操作失敗，請重試');
    }
  };

  // 自動跳轉：司機已有進行中訂單
  useEffect(() => {
    if (order && (order.status === 'accepted' || order.status === 'picked_up')) {
      navigate('/driver/riding');
    }
    if (order && order.status === 'paid') {
      navigate('/driver/rating');
    }
  }, [order?.status, navigate]);

  // 新訂單提示動畫
  useEffect(() => {
    if (hallOrders.length > 0 && driverOnline) {
      setIncomingAnim(true);
      const t = setTimeout(() => setIncomingAnim(false), 800);
      return () => clearTimeout(t);
    }
  }, [hallOrders.length, driverOnline]);

  const handleAccept = async (orderId: string) => {
    try {
      const orderData = await api.acceptOrder(orderId);
      // 刷新 context 中的 order
      window.dispatchEvent(new Event('hktaxi-order-updated'));
      navigate('/driver/riding');
    } catch {
      toast.error('接單失敗，請重試');
    }
  };

  const handleReject = async (orderId: string) => {
    try {
      await api.rejectOrder(orderId);
      setHallOrders((prev) => prev.filter((o) => o.id !== orderId));
      toast.success('已拒絕訂單');
    } catch {
      toast.error('拒絕失敗');
    }
  };

  // 顯示的新訂單：取第一個（多訂單時先展示第一個）
  const displayOrder = hallOrders[0];
  const hasNewOrder = displayOrder && driverOnline && driverVerified;

  // 申請狀態：待審批先顯示鎖定狀態
  const isPending = driverApplication?.status === 'pending';
  const isRejected = driverApplication?.status === 'rejected';

  if (isPending) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 pb-24 text-foreground flex flex-col">
        {/* Header */}
        <div className="px-4 pt-6 pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                <Clock className="size-5 text-amber-400" />
              </div>
              <div>
                <h1 className="text-lg font-bold">接單大廳</h1>
                <div className="text-xs text-amber-400">申請審批中</div>
              </div>
            </div>
          </div>
        </div>

        {/* Pending card */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm"
          >
            <div className="size-24 rounded-full bg-amber-500/20 flex items-center justify-center mx-auto mb-6">
              <Clock className="size-12 text-amber-400 animate-pulse" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">申請審批中</h2>
            <p className="text-sm text-muted-foreground mb-6">
              你嘅司機驗證申請已提交，管理員正在審核。<br />
              通過後你就可以上線接單喇。
            </p>

            <div className="p-4 rounded-2xl bg-card border bg-card border-border text-left space-y-3">
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                  <User className="size-5 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">{driverApplication.driverName}</div>
                  <div className="text-xs text-muted-foreground font-mono">{driverApplication.licenseNo}</div>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-300 shrink-0">
                  待審批
                </span>
              </div>
              <div className="pt-3 border-t bg-card border-border grid grid-cols-2 gap-3 text-xs">
                <div>
                  <div className="text-slate-500 mb-1">車牌</div>
                  <div className="font-mono text-muted-foreground">{driverApplication.plate}</div>
                </div>
                <div>
                  <div className="text-slate-500 mb-1">車型</div>
                  <div className="text-muted-foreground">{driverApplication.carType === '6-seater' ? '6 人車' : '4 人車'}</div>
                </div>
              </div>
              <div className="pt-3 border-t bg-card border-border flex items-center gap-2 text-xs text-slate-500">
                <Check className="size-3.5 text-emerald-400" />
                <span>申請時間：{new Date(driverApplication.createdAt).toLocaleString('zh-HK', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/driver/profile')}
              className="mt-6 w-full py-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              查看申請詳情
            </button>
          </motion.div>
        </div>

        {/* Bottom nav spacer */}
        <div className="h-20" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 pb-24 text-foreground">
      {/* Header with status */}
      <div className="px-4 pt-6 pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center">
              <Car className="size-5 text-primary" />
            </div>
            <div>
              <h1 className="text-lg font-bold">接單大廳</h1>
              <div className="text-xs text-muted-foreground">{driverApplication?.driverName ?? '陳師傅'} · {driverApplication?.plate ?? 'AB1234'}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="size-9 rounded-full bg-muted flex items-center justify-center">
              <Bell className="size-4 text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>

      {/* Online toggle */}
      <div className="px-4 mb-4">
        <Card className="bg-card bg-card border-border backdrop-blur">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`size-3 rounded-full ${
                  driverOnline ? 'bg-emerald-400 animate-pulse' : 'bg-slate-500'
                }`}
              />
              <div>
                <div className="font-semibold">
                   {driverOnline ? t.driverHall.onlineStatus : t.driverHall.offlineStatus}
                </div>
                <div className="text-xs text-muted-foreground">
                   {driverOnline ? t.driverHall.noOrdersDesc : t.driverHall.offline}
                </div>
              </div>
            </div>
            <Switch checked={driverOnline && driverVerified} onCheckedChange={handleToggleOnline} disabled={!driverVerified && !driverOnline} />
          </CardContent>
        </Card>
      </div>

      {/* Map area */}
      <div className="px-4 mb-4">
        <div className="relative">
          <AMapView
            pickupName={hasNewOrder ? displayOrder?.pickupName : undefined}
            destinationName={hasNewOrder ? displayOrder?.destinationName : undefined}
            passengerLat={hasNewOrder ? displayOrder?.pickupLat : undefined}
            passengerLng={hasNewOrder ? displayOrder?.pickupLng : undefined}
            showRoute={!!hasNewOrder}
            height="h-48"
            centerLat={22.3080}
            centerLng={114.1729}
            zoom={12}
          />
          {!driverOnline && (
            <div className="absolute inset-0 bg-muted backdrop-blur-sm rounded-2xl flex items-center justify-center">
              <div className="text-center">
                 <div className="text-muted-foreground font-medium">{t.driverHall.offlineStatus}</div>
                 <div className="text-sm text-muted-foreground mt-1">{t.driverHall.noOrdersDesc}</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* New order card */}
      <div className="px-4">
        <AnimatePresence mode="wait">
          {hasNewOrder && displayOrder ? (
            <motion.div
              key="order"
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -30, scale: 0.95 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
              className={incomingAnim ? 'animate-pulse' : ''}
            >
              <Card className="bg-gradient-to-br from-primary to-primary/80 border-0 shadow-xl shadow-primary/25 text-primary-foreground overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
                <CardContent className="relative p-5">
                  <div className="flex items-center justify-between mb-3">
                    <Badge className="bg-white/20 text-foreground border-0">
                      <Zap className="size-3 mr-1" />
                       {t.driverHall.newOrder}
                    </Badge>
                    <div className="text-right">
                       <div className="text-xs opacity-80">{t.driverHall.estimatedFare}</div>
                      <div className="text-2xl font-black">
                        HK${displayOrder.estimatedFare?.toFixed(0) ?? '--'}
                      </div>
                      {displayOrder.tip > 0 && (
                        <div className="text-xs text-amber-300 font-semibold mt-0.5">
                          💰 含 HK${displayOrder.tip} 貼士
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex flex-col items-center">
                      <MapPin className="size-4 opacity-90" />
                      <div className="w-px h-6 bg-white/30 my-0.5" />
                      <Navigation className="size-4 opacity-90" />
                    </div>
                    <div className="flex-1 space-y-1.5">
                      <div className="font-semibold">{displayOrder.pickupName}</div>
                      <div className="font-semibold">{displayOrder.destinationName}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 mb-5 text-sm">
                    <div className="flex items-center gap-1.5 opacity-80">
                      <Clock className="size-3.5" />
                      約 {(displayOrder.distanceKm ?? 3).toFixed(1)} 分鐘
                    </div>
                    <div className="flex items-center gap-1.5 opacity-80">
                      <DollarSign className="size-3.5" />
                      {displayOrder.carType === '6-seater' ? '6 人車' : '4 人車'}
                    </div>
                    {displayOrder.tip > 0 && (
                      <div className="flex items-center gap-1.5 text-amber-300 font-medium">
                        貼士 HK${displayOrder.tip}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-3">
                    <Button
                      variant="outline"
                      size="lg"
                      className="flex-1 h-12 rounded-xl bg-muted border-border text-foreground hover:bg-accent"
                      onClick={() => handleReject(displayOrder.id)}
                    >
                      <X className="size-4 mr-1.5" />
                       {t.driverHall.reject}
                    </Button>
                    <Button
                      size="lg"
                      className="flex-1 h-12 rounded-xl bg-white text-primary hover:bg-white/90 font-bold"
                      onClick={() => handleAccept(displayOrder.id)}
                    >
                      <Check className="size-4 mr-1.5" />
                       {t.driverHall.accept}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* 更多訂單提示 */}
              {hallOrders.length > 1 && (
                <div className="mt-3 text-center text-xs text-muted-foreground">
                  仲有 {hallOrders.length - 1} 個其他訂單喺後面
                </div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="empty"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-10"
            >
              <div className="size-16 mx-auto mb-4 rounded-full bg-slate-700 flex items-center justify-center">
                <Car className="size-8 text-muted-foreground" />
              </div>
              <div className="text-foreground font-semibold mb-1">
                 {driverOnline ? t.driverHall.noOrders : t.driverHall.offlineStatus}
              </div>
              <div className="text-sm text-muted-foreground mb-4">
                 {driverOnline ? t.driverHall.noOrdersDesc : t.driverHall.onlineStatus}
              </div>
              {!driverOnline && driverVerified && (
                <Button
                  size="lg"
                  className="h-10 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-foreground font-semibold"
                  onClick={() => setDriverOnline(true)}
                >
                  <Power className="size-4 mr-1.5" />
                   {t.driverHall.online}
                </Button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Floating contact button */}
      <Sheet>
        <SheetTrigger asChild>
          <button
            className="fixed bottom-6 right-4 z-40 size-14 rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
            aria-label="聯絡資訊"
          >
            <Phone className="size-5" />
          </button>
        </SheetTrigger>
        <SheetContent side="bottom" className="rounded-t-3xl p-0 pb-6 bg-card text-foreground border-border">
          <SheetHeader className="p-5 pb-3">
            <SheetTitle className="text-lg font-bold text-foreground">聯絡資訊</SheetTitle>
            <SheetDescription className="text-muted-foreground">司機專用聯絡渠道</SheetDescription>
          </SheetHeader>
          <div className="px-5 space-y-3">
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-card border bg-card border-border">
              <div className="size-12 rounded-full bg-primary/20 flex items-center justify-center shrink-0">
                <User className="size-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-foreground">Ethan Chan</div>
                <div className="text-xs text-muted-foreground">車隊調度主任</div>
              </div>
            </div>

            <UniversalLink
              to="tel:55888712"
              className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 hover:bg-emerald-500/20 transition-colors"
            >
              <div className="size-10 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                <Phone className="size-4 text-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-emerald-300 font-medium">致電聯絡</div>
                <div className="text-sm font-semibold text-foreground">5588 8712</div>
              </div>
              <ChevronRight className="size-4 text-emerald-400 shrink-0" />
            </UniversalLink>

            <UniversalLink
              to="mailto:tkdw0712@gmail.com"
              className="flex items-center gap-3 p-4 rounded-2xl bg-blue-500/10 border border-blue-500/30 hover:bg-blue-500/20 transition-colors"
            >
              <div className="size-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Mail className="size-4 text-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-blue-300 font-medium">電郵聯絡</div>
                <div className="text-sm font-semibold text-foreground truncate">tkdw0712@gmail.com</div>
              </div>
              <ChevronRight className="size-4 text-blue-400 shrink-0" />
            </UniversalLink>

            <UniversalLink
              to="sms:55888712"
              className="flex items-center gap-3 p-4 rounded-2xl bg-purple-500/10 border border-purple-500/30 hover:bg-purple-500/20 transition-colors"
            >
              <div className="size-10 rounded-full bg-purple-500 flex items-center justify-center shrink-0">
                <MessageCircle className="size-4 text-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-purple-300 font-medium">發送短訊</div>
                <div className="text-sm font-semibold text-foreground">5588 8712</div>
              </div>
              <ChevronRight className="size-4 text-purple-400 shrink-0" />
            </UniversalLink>
          </div>
        </SheetContent>
      </Sheet>

      {/* Verify required sheet */}
      <Sheet open={showVerifySheet} onOpenChange={setShowVerifySheet}>
        <SheetContent className="bg-card border-t border-border text-foreground rounded-t-3xl">
          <SheetHeader>
            <SheetTitle className="text-foreground text-center">司機驗證</SheetTitle>
            <SheetDescription className="text-muted-foreground text-center">
              完成驗證先可以上線接單
            </SheetDescription>
          </SheetHeader>
          <div className="flex flex-col items-center mt-6 mb-6">
            <div className="size-20 rounded-full bg-amber-500/20 flex items-center justify-center mb-4">
              <ShieldAlert className="size-10 text-amber-400" />
            </div>
            <h3 className="text-lg font-bold text-foreground mb-2">賬號未驗證</h3>
            <p className="text-sm text-muted-foreground text-center max-w-xs">
              為咗確保服務質素同乘客安全，所有司機必須完成身份驗證先可以上線接單。
            </p>
          </div>
          <div className="space-y-3">
            <div className="p-4 rounded-xl bg-card space-y-2 text-sm">
              <div className="flex items-center gap-2 text-muted-foreground">
                <Check className="size-4 text-emerald-400" />
                <span>身份證驗證</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Check className="size-4 text-emerald-400" />
                <span>有效司機證</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Check className="size-4 text-emerald-400" />
                <span>車輛登記證明</span>
              </div>
            </div>
            <Button
              size="lg"
              className="w-full h-12 rounded-xl font-semibold"
              onClick={() => {
                setShowVerifySheet(false);
                navigate('/driver/verify');
              }}
            >
              立即驗證
            </Button>
            <button
              onClick={() => setShowVerifySheet(false)}
              className="w-full py-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              稍後再講
            </button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
