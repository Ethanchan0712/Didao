import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Car, Star, HelpCircle, Settings, ChevronRight, LogOut, ShieldCheck, ShieldX, RotateCcw, User, Clock, ArrowRightLeft } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { Image } from '@/components/ui/image';

export default function DriverProfilePage() {
  const navigate = useNavigate();
  const { driverVerified, driverApplication, resetDemoData, setDriverOnline, setCurrentRole } = useOrder();
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const { t } = useI18n();

  const handleReset = () => {
    resetDemoData();
    setDriverOnline(false);
    toast.success('示範資料已重置');
    setShowResetConfirm(false);
  };

  const handleSwitchToPassenger = () => {
    setDriverOnline(false);
    setCurrentRole('passenger');
    navigate('/passenger');
  };

  const menuItems = [
    { icon: Car, label: '車輛資料', value: 'AB1234' },
    { icon: Star, label: '我的評分', value: '4.8' },
    { icon: HelpCircle, label: '幫助中心', value: '' },
    { icon: Settings, label: '設定', value: '' },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground pb-24">
      {/* Profile header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground px-4 pt-10 pb-16 rounded-b-3xl">
        <div className="flex items-center gap-4">
          <Avatar className="size-16 border-2 border-white/30">
            <AvatarImage
              src="https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/1.jpg"
              alt="陳師傅"
            />
            <AvatarFallback>陳</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-xl font-bold">陳師傅</h1>
            <p className="text-sm opacity-80">金牌司機 · 服務 3 年</p>
          </div>
          <button className="size-9 rounded-full bg-white/20 flex items-center justify-center">
            <Settings className="size-5" />
          </button>
        </div>
      </div>

      {/* Stats card */}
      <div className="px-4 -mt-8">
        <Card className="bg-card bg-card border-border shadow-lg">
          <CardContent className="p-4 grid grid-cols-3 divide-x divide-slate-700/50">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">256</div>
              <div className="text-xs text-muted-foreground mt-0.5">總單數</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">HK$18,560</div>
              <div className="text-xs text-muted-foreground mt-0.5">總收入</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">4.8</div>
              <div className="text-xs text-muted-foreground mt-0.5">評分</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Verification status */}
      <div className="px-4 mt-4">
        {driverVerified ? (
          <Card className="bg-emerald-500/10 border-emerald-500/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="size-14 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                <ShieldCheck className="size-7 text-emerald-400" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-foreground">已驗證司機</div>
                <div className="text-sm text-emerald-400/80">你可以正常上線接單</div>
                <div className="text-xs text-muted-foreground mt-1">
                  驗證編號 VR-F28K9X · 有效期至 2026-12-31
                </div>
              </div>
              <ChevronRight className="size-4 text-slate-500" />
            </CardContent>
          </Card>
        ) : driverApplication?.status === 'pending' ? (
          <Card className="bg-amber-500/10 border-amber-500/30">
            <CardContent className="p-4 flex items-center gap-4">
              <div className="size-14 rounded-xl bg-amber-500/20 flex items-center justify-center">
                <Clock className="size-7 text-amber-400 animate-pulse" />
              </div>
              <div className="flex-1">
                <div className="font-semibold text-foreground">審批中</div>
                <div className="text-sm text-amber-400/80">管理員正在審核你嘅申請</div>
                <div className="text-xs text-muted-foreground mt-1">
                  預計 1-2 個工作天內完成
                </div>
              </div>
              <span className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-300">
                待審批
              </span>
            </CardContent>
          </Card>
        ) : driverApplication?.status === 'rejected' ? (
          <Card className="bg-red-500/10 border-red-500/30">
            <CardContent className="p-4 space-y-3">
              <div className="flex items-center gap-4">
                <div className="size-14 rounded-xl bg-red-500/20 flex items-center justify-center">
                  <ShieldX className="size-7 text-red-400" />
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-foreground">申請被拒絕</div>
                  <div className="text-sm text-red-400/80">請修正資料後重新提交</div>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-red-500/20 text-red-300">
                  已拒絕
                </span>
              </div>
              <div className="p-3 rounded-lg bg-card text-xs text-muted-foreground">
                <div className="text-slate-500 mb-1">拒絕原因</div>
                <div className="text-muted-foreground">{driverApplication.rejectReason || '資料唔齊全，請補交相關證件'}</div>
              </div>
              <Button
                variant="outline"
                className="w-full h-10 rounded-xl border-border text-foreground hover:bg-accent"
                onClick={() => navigate('/driver/verify')}
              >
                重新提交申請
              </Button>
            </CardContent>
          </Card>
        ) : (
          <button
            onClick={() => navigate('/driver/verify')}
            className="w-full"
          >
            <Card className="bg-amber-500/10 border-amber-500/30 hover:bg-amber-500/15 transition-colors">
              <CardContent className="p-4 flex items-center gap-4">
                <div className="size-14 rounded-xl bg-amber-500/20 flex items-center justify-center">
                  <ShieldX className="size-7 text-amber-400" />
                </div>
                <div className="flex-1 text-left">
                  <div className="font-semibold text-foreground">未完成驗證</div>
                  <div className="text-sm text-amber-400/80">完成驗證先可以上線接單</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    需提交身份證、司機證、車牌資料
                  </div>
                </div>
                <ChevronRight className="size-4 text-amber-400" />
              </CardContent>
            </Card>
          </button>
        )}
      </div>

      {/* Vehicle info */}
      <div className="px-4 mt-4">
        <Card className="bg-card bg-card border-border">
          <CardContent className="p-4 flex items-center gap-4">
            <div className="size-14 rounded-xl bg-primary/20 flex items-center justify-center">
              <Car className="size-7 text-primary" />
            </div>
            <div className="flex-1">
              <div className="font-semibold text-foreground">豐田 Crown</div>
              <div className="text-sm text-muted-foreground">車牌 AB1234 · 紅色市區的士</div>
            </div>
            <ChevronRight className="size-4 text-slate-500" />
          </CardContent>
        </Card>
      </div>

      {/* Menu */}
      <div className="px-4 mt-4">
        <Card className="bg-card bg-card border-border overflow-hidden">
          {menuItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className={`w-full flex items-center gap-3 p-4 hover:bg-accent/30 transition-colors text-left ${
                  i !== 0 ? 'border-t bg-card border-border' : ''
                }`}
              >
                <div className="size-9 rounded-full bg-primary/20 flex items-center justify-center">
                  <Icon className="size-4 text-primary" />
                </div>
                <span className="flex-1 text-sm font-medium text-foreground">
                  {item.label}
                </span>
                {item.value && (
                  <span className="text-xs text-muted-foreground">{item.value}</span>
                )}
                <ChevronRight className="size-4 text-slate-500" />
              </button>
            );
          })}
        </Card>
      </div>

      {/* 切換角色 */}
      <div className="px-4 mt-4">
        <button
          onClick={handleSwitchToPassenger}
          className="w-full flex items-center justify-center gap-2 p-4 rounded-xl bg-card border border-border text-foreground hover:bg-muted transition-colors shadow-sm"
        >
          <ArrowRightLeft className="size-4 text-primary" />
          <span className="text-sm font-semibold">{t.driverProfile.switchRole}</span>
        </button>
      </div>

      {/* Reset demo data */}
      <div className="px-4 mt-4">
        <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
          <AlertDialogTrigger asChild>
            <button className="w-full flex items-center justify-center gap-2 p-4 rounded-xl bg-card border bg-card border-border text-muted-foreground hover:bg-muted transition-colors">
              <RotateCcw className="size-4" />
              <span className="text-sm font-medium">重置示範資料</span>
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent className="bg-card border-border text-foreground">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-foreground">重置示範資料？</AlertDialogTitle>
              <AlertDialogDescription className="text-muted-foreground">
                呢個操作會清除所有行程記錄、收入同訂單狀態，將 App 回復到初始示範狀態。
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="bg-muted text-foreground border-border hover:bg-accent">
                取消
              </AlertDialogCancel>
              <AlertDialogAction onClick={handleReset} className="bg-destructive hover:bg-destructive/90">
                確認重置
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* Logout */}
      <div className="px-4 mt-4">
        <button className="w-full flex items-center justify-center gap-2 p-4 rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors">
          <LogOut className="size-4" />
          <span className="text-sm font-medium">退出登錄</span>
        </button>
      </div>

      {/* App info */}
      <div className="px-4 mt-8 mb-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Image
            src="https://aka.doubaocdn.com/s/1L23UMNBh7"
            alt="的道"
            className="size-6 rounded-full object-cover"
          />
          <span className="text-sm font-semibold text-foreground">的道 · 司機端</span>
        </div>
        <div className="text-xs text-slate-500">版本 1.0.0 · 示範版</div>
      </div>
    </div>
  );
}
