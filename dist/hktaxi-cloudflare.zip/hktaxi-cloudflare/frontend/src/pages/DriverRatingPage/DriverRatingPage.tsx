import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Navigation, Star, ThumbsUp, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useNavigate } from 'react-router-dom';
import StarRating from '@/components/StarRating';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';

const tags = ['準時有禮', '路線清晰', '準時上車', '有禮貌', '暈車浪', '攜帶行李'];

export default function DriverRatingPage() {
  const { order, submitPassengerRating, resetToIdle } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [rating, setRating] = useState(5);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!order) {
      navigate('/driver');
      return;
    }
  }, [order, navigate]);

  if (!order) return null;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async () => {
    try {
      await submitPassengerRating(rating);
    } catch {
      // ignore
    }
    setSubmitted(true);
    setTimeout(() => {
      resetToIdle();
      navigate('/driver');
    }, 1500);
  };

  const earnings = order.actualFare ?? order.estimatedFare;

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <div className="flex-1 px-4 pt-8 pb-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="size-20 mx-auto rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mb-4 shadow-lg shadow-amber-500/30">
            <Star className="size-10 text-foreground fill-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">{t.driverRating.title}</h1>
           <p className="text-sm text-muted-foreground mt-1">{t.driverRating.subtitle}</p>
        </motion.div>

        {/* Earnings */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
        >
          <Card className="bg-gradient-to-br from-emerald-600 to-teal-700 border-0 text-foreground shadow-lg shadow-emerald-500/20 mb-4">
            <CardContent className="p-5">
              <div className="text-sm opacity-80 mb-1">{t.driverRating.fare}</div>
              <div className="text-4xl font-black tabular-nums">
                HK${earnings.toFixed(0)}<span className="text-lg opacity-80">.00</span>
              </div>
              <div className="flex items-center gap-2 mt-2">
                <span className="text-xs bg-white/20 rounded-full px-2 py-0.5">
                  車費
                </span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Passenger card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="bg-card bg-card border-border mb-4">
            <CardContent className="p-4 flex items-center gap-3">
              <Avatar className="size-14 border-2 border-border">
                <AvatarImage
                  src="https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/3.jpg"
                  alt="乘客"
                />
                <AvatarFallback>陳</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="font-semibold text-foreground">
                  {order.passenger?.name ?? '陳先生'}
                </div>
                <div className="flex items-center gap-1 text-amber-400 text-sm">
                  <Star className="size-3.5 fill-amber-400" />
                  {order.passenger?.rating ?? 4.7}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Route summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="flex items-center gap-3 px-2 mb-6"
        >
          <div className="flex flex-col items-center">
            <MapPin className="size-4 text-emerald-400" />
            <div className="w-px h-6 bg-slate-600 my-0.5" />
            <Navigation className="size-4 text-red-400" />
          </div>
          <div className="flex-1 space-y-1.5 text-sm">
            <div className="font-medium text-foreground">{order.pickup.name}</div>
            <div className="font-medium text-foreground">{order.destination.name}</div>
          </div>
        </motion.div>

        {/* Star rating */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-6"
        >
          <div className="text-sm font-medium text-muted-foreground mb-3">
            你對呢位乘客滿意嗎？
          </div>
          <div className="flex justify-center">
            <StarRating value={rating} onChange={setRating} size={40} />
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            {rating === 5 ? '非常滿意！' : rating >= 4 ? '滿意' : rating >= 3 ? '一般' : '不滿意'}
          </div>
        </motion.div>

        {/* Tags */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <div className="text-sm font-medium text-muted-foreground mb-3">乘客表現</div>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => toggleTag(tag)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                  selectedTags.includes(tag)
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'bg-muted text-muted-foreground hover:bg-accent'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Submit */}
      <div className="px-4 pb-8 pt-2">
        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center justify-center gap-2 h-14 bg-emerald-500 text-foreground rounded-2xl font-semibold text-base shadow-lg shadow-emerald-500/30"
          >
            <Check className="size-5" />
            多謝你的評分！
          </motion.div>
        ) : (
          <Button
            size="lg"
            className="w-full h-14 text-base font-semibold rounded-2xl shadow-lg shadow-primary/25 bg-primary hover:bg-primary/90"
            onClick={handleSubmit}
          >
            <ThumbsUp className="size-5 mr-2" />
            提交評分
          </Button>
        )}
      </div>
    </div>
  );
}
