import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Phone, PhoneOff, MessageCircle, Star, ChevronRight, User, Navigation, MapPin, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import AMapView from '@/components/AMapView';
import ChatSheet from '@/components/ChatSheet';
import { useOrder } from '@/lib/order-context';
import { interpolateLatLng, estimateFare, haversineKm } from '@/lib/taxi-utils';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';

export default function DriverRidingPage() {
  const { order, updateDriverPosition, markPickedUp, markCompleted } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [driverPos, setDriverPos] = useState<{ lat: number; lng: number } | null>(null);
  const [eta, setEta] = useState(3);
  const [distance, setDistance] = useState(1.2);
  const timerRef = useRef<number | null>(null);
  const [showConfirm, setShowConfirm] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showCall, setShowCall] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const callTimerRef = useRef<number | null>(null);

  // 跳轉邏輯
  useEffect(() => {
    if (!order) {
      navigate('/driver');
      return;
    }
    if (order.status === 'searching') {
      navigate('/driver');
      return;
    }
    if (order.status === 'paid') {
      navigate('/driver/rating');
    }
  }, [order, navigate]);

  // 模擬司機位置移動（保留動畫效果，同時 updateDriverPosition 同步到後端）
  useEffect(() => {
    if (!order) return;
    if (order.status === 'completed' || order.status === 'paid') return;

    const isPickedUp = order.status === 'picked_up';
    const start = isPickedUp
      ? { lat: order.pickup.lat, lng: order.pickup.lng }
      : order.driver
      ? { lat: order.driver.currentLat, lng: order.driver.currentLng }
      : { lat: 22.2819, lng: 114.1585 };
    const end = isPickedUp
      ? { lat: order.destination.lat, lng: order.destination.lng }
      : { lat: order.pickup.lat, lng: order.pickup.lng };

    setDriverPos(start);
    const totalMinutes = isPickedUp ? 10 : 3;
    const totalKm = haversineKm(
      { lat: start.lat, lng: start.lng },
      { lat: end.lat, lng: end.lng }
    );
    setEta(totalMinutes);
    setDistance(totalKm);

    const steps = 30;
    const intervalMs = 800;
    let step = 0;

    if (timerRef.current) window.clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      step++;
      const progress = step / steps;
      const pos = interpolateLatLng(start, end, progress);
      setDriverPos(pos);
      const remainingMins = Math.max(0.5, totalMinutes * (1 - progress));
      const remainingKm = Math.max(0.1, totalKm * (1 - progress));
      setEta(Math.ceil(remainingMins));
      setDistance(remainingKm);
      updateDriverPosition(pos.lat, pos.lng, Math.ceil(remainingMins));

      if (step >= steps) {
        if (timerRef.current) window.clearInterval(timerRef.current);
      }
    }, intervalMs);

    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [order?.status, order?.id, updateDriverPosition]);

  if (!order) return null;

  const isPickedUp = order.status === 'picked_up';
  const isCompleted = order.status === 'completed';
  const actualFare = estimateFare(
    haversineKm(
      { lat: order.pickup.lat, lng: order.pickup.lng },
      { lat: order.destination.lat, lng: order.destination.lng }
    )
  );

  const handleArrivePickup = () => {
    setShowConfirm(true);
    setTimeout(() => setShowConfirm(false), 1500);
    markPickedUp();
  };

  const handleComplete = () => {
    markCompleted(actualFare);
  };

  const passengerName = order.passenger?.name ?? '陳先生';

  const handleCall = () => {
    setShowCall(true);
    setCallDuration(0);
    toast.info(`正在致電 ${passengerName}...`);
    callTimerRef.current = window.setInterval(() => {
      setCallDuration((d) => d + 1);
    }, 1000);
  };

  const handleHangUp = () => {
    if (callTimerRef.current) {
      window.clearInterval(callTimerRef.current);
      callTimerRef.current = null;
    }
    setShowCall(false);
    toast.success('通話已結束');
  };

  const formatCallDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-background pb-6 text-foreground">
      {/* Status bar */}
      <div className="px-4 pt-4 pb-2 flex items-center justify-between">
        <Badge
          className={`${
            isCompleted
              ? 'bg-amber-500/20 text-amber-300 border-0'
              : isPickedUp
              ? 'bg-blue-500/20 text-blue-300 border-0'
              : 'bg-emerald-500/20 text-emerald-300 border-0'
          } text-sm font-medium px-3 py-1`}
        >
          <Navigation className="size-3.5 mr-1" />
          {isCompleted
            ? t.driverRiding.waitingPayment
            : isPickedUp
            ? '前往目的地'
            : t.driverRiding.headingToPickup}
        </Badge>
        {!isCompleted && (
          <div className="text-sm text-muted-foreground">
            剩餘 <span className="text-foreground font-semibold">{eta}</span> 分鐘
          </div>
        )}
      </div>

      {/* Map */}
      <div className="px-4 pt-2">
        <AMapView
          pickupName={isPickedUp || isCompleted ? undefined : order.pickup.name}
          destinationName={order.destination.name}
          driverLat={driverPos?.lat ?? order.driver?.currentLat}
          driverLng={driverPos?.lng ?? order.driver?.currentLng}
          passengerLat={order.pickup.lat}
          passengerLng={order.pickup.lng}
          showRoute
          height="h-72"
        />
      </div>

      {/* ETA / distance */}
      <div className="px-4 mt-4 grid grid-cols-2 gap-3">
        <Card className="bg-card bg-card border-border">
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <Clock className="size-3.5" />
              預計時間
            </div>
            <div className="text-2xl font-bold text-foreground">
              {eta}<span className="text-sm font-normal text-muted-foreground ml-1">分鐘</span>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card bg-card border-border">
          <CardContent className="p-4">
            <div className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
              <Navigation className="size-3.5" />
              剩餘距離
            </div>
            <div className="text-2xl font-bold text-foreground">
              {distance.toFixed(1)}<span className="text-sm font-normal text-muted-foreground ml-1">km</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Passenger info */}
      <div className="px-4 mt-4">
        <Card className="bg-card bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="size-12 border-2 border-primary/30">
                <AvatarFallback>{passengerName[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-foreground">
                  {order.passenger?.name ?? '陳先生'}
                </div>
                <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                  <div className="flex items-center gap-1 text-amber-400 text-sm">
                    <Star className="size-3.5 fill-amber-400" />
                    {order.passenger?.rating ?? 4.7}
                  </div>
                  <span className="text-slate-500 text-xs">·</span>
                  <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                    {order.carType === '6-seater' ? '6 人車' : '4 人車'}
                  </Badge>
                  {order.tip > 0 && (
                    <Badge variant="outline" className="text-xs border-amber-500/50 text-amber-300 bg-amber-500/10">
                      💰 貼士 HK${order.tip}
                    </Badge>
                  )}
                </div>
              </div>
               <div className="flex gap-2">
                 <button
                   onClick={handleCall}
                   className="size-10 rounded-full bg-green-500/20 hover:bg-green-500/30 flex items-center justify-center transition-colors"
                   aria-label="致電乘客"
                 >
                   <Phone className="size-4 text-green-400" />
                 </button>
                 <button
                   onClick={() => setShowChat(true)}
                   className="size-10 rounded-full bg-primary/20 hover:bg-primary/30 flex items-center justify-center transition-colors relative"
                   aria-label="訊息"
                 >
                   <MessageCircle className="size-4 text-primary-foreground" />
                   {(order.messages?.length ?? 0) > 0 && (
                     <span className="absolute -top-1 -right-1 size-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                       {order.messages.length}
                     </span>
                   )}
                 </button>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Route */}
      <div className="px-4 mt-4">
        <Card className="bg-card bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-center">
                <MapPin className="size-4 text-emerald-400" />
                <div className="w-px h-6 bg-slate-600 my-0.5" />
                <Navigation className="size-4 text-red-400" />
              </div>
              <div className="flex-1 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{order.pickup.name}</span>
                  <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                    {isPickedUp || isCompleted ? '已到達' : '上車點'}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">{order.destination.name}</span>
                  <Badge variant="outline" className="text-xs border-border text-muted-foreground">
                    目的地
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action button */}
      <div className="px-4 mt-6">
        {isCompleted ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="size-16 mx-auto rounded-full bg-amber-500/20 flex items-center justify-center mb-3 animate-pulse">
              <Clock className="size-8 text-amber-400" />
            </div>
            <div className="text-base font-semibold text-foreground mb-1">
              {t.driverRiding.waitingPayment}
            </div>
            <div className="text-sm text-muted-foreground mb-4">
              車費 HK${actualFare.toFixed(0)}，等待乘客付款...
            </div>
            <div className="text-xs text-muted-foreground">
              乘客完成付款後會自動跳轉
            </div>
          </motion.div>
        ) : isPickedUp ? (
          <Button
            size="lg"
            className="w-full h-14 text-base font-semibold rounded-2xl"
            onClick={handleComplete}
          >
            到達目的地 · 結算車費
            <ChevronRight className="size-4 ml-1" />
          </Button>
        ) : (
          <Button
            size="lg"
            className="w-full h-14 text-base font-semibold rounded-2xl"
            onClick={handleArrivePickup}
          >
            已到達上車點
            <ChevronRight className="size-4 ml-1" />
          </Button>
        )}
      </div>

      {/* Confirmation toast */}
      {showConfirm && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 bg-black/80 text-white px-8 py-6 rounded-2xl text-center backdrop-blur"
        >
          <div className="size-12 mx-auto rounded-full bg-emerald-500/30 flex items-center justify-center mb-2">
            <Navigation className="size-6 text-emerald-400" />
          </div>
          <div className="font-semibold">已到達</div>
          <div className="text-xs text-white/60">乘客已上車</div>
        </motion.div>
      )}

      {/* 聊天彈層 */}
      <ChatSheet
        open={showChat}
        onClose={() => setShowChat(false)}
        role="driver"
        otherName={passengerName}
      />

      {/* 通話中 Dialog */}
      {showCall && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md flex items-center justify-center">
          <div className="text-center text-white">
            <div className="size-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-5 animate-pulse">
              <div className="size-16 rounded-full bg-green-500/30 flex items-center justify-center">
                <Phone className="size-7 text-green-400" />
              </div>
            </div>
            <div className="text-lg font-semibold mb-1">{passengerName}</div>
            <div className="text-sm text-white/60 mb-1">
              {callDuration === 0 ? '正在呼叫...' : '通話中'}
            </div>
            {callDuration > 0 && (
              <div className="text-xs text-white/50 tabular-nums mb-6">
                {formatCallDuration(callDuration)}
              </div>
            )}
            {callDuration === 0 && <div className="h-6 mb-6" />}
            <button
              onClick={handleHangUp}
              className="size-14 rounded-full bg-red-500 flex items-center justify-center mx-auto hover:bg-red-600 transition-colors shadow-lg shadow-red-500/30"
              aria-label="掛線"
            >
              <PhoneOff className="size-6 text-white" />
            </button>
            <div className="text-xs text-white/40 mt-2">掛線</div>
          </div>
        </div>
      )}
    </div>
  );
}
