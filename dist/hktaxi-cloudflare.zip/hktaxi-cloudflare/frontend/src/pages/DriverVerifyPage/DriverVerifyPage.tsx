import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft,
  Car,
  User,
  Check,
  Upload,
  ShieldCheck,
  Loader2,
  Clock,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';

export default function DriverVerifyPage() {
  const navigate = useNavigate();
  const { submitDriverApplication, driverApplication } = useOrder();
  const [step, setStep] = useState<'form' | 'review' | 'pending'>('form');
  const [plate, setPlate] = useState('');
  const [licenseNo, setLicenseNo] = useState('');
  const [carType, setCarType] = useState<'4-seater' | '6-seater'>('4-seater');
  const [driverName, setDriverName] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const isFormValid =
    plate.trim().length >= 4 &&
    licenseNo.trim().length >= 4 &&
    driverName.trim().length >= 2;

  const handleSubmit = async () => {
    if (!isFormValid) return;
    setSubmitting(true);
    setStep('review');
    // 模擬提交：1 秒後顯示待審批
    await new Promise((r) => setTimeout(r, 1000));
    submitDriverApplication({ driverName, licenseNo, plate, carType });
    setStep('pending');
    toast.success('申請已提交，請耐心等待管理員審批');
  };

  return (
    <div className="min-h-screen bg-background text-foreground pb-8">
      {/* Header */}
      <div className="px-4 pt-6 pb-2">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="size-10 rounded-full bg-muted flex items-center justify-center hover:bg-accent transition-colors"
          >
            <ArrowLeft className="size-5" />
          </button>
          <div>
            <h1 className="text-xl font-bold">司機驗證</h1>
            <p className="text-sm text-muted-foreground">完成認證先可以上線接單</p>
          </div>
        </div>
      </div>

      {/* Steps indicator */}
      <div className="px-6 mt-4">
        <div className="flex items-center justify-between max-w-xs mx-auto">
          {[0, 1, 2].map((i) => {
            const labels = ['填資料', '提交中', '待審批'];
            const stepIdx = step === 'form' ? 0 : step === 'review' ? 1 : 2;
            const passed = i < stepIdx;
            const active = i === stepIdx;
            return (
              <div key={i} className="flex items-center flex-1">
                <div className="flex flex-col items-center gap-1">
                  <div className={`size-8 rounded-full flex items-center justify-center text-sm font-bold ${
                    passed ? 'bg-amber-500 text-foreground' : active ? 'bg-primary text-foreground' : 'bg-muted text-muted-foreground'
                  }`}>
                    {passed ? <Check className="size-4" /> : i + 1}
                  </div>
                  <span className="text-xs text-muted-foreground">{labels[i]}</span>
                </div>
                {i < 2 && (
                  <div className={`flex-1 h-0.5 mx-2 ${i < stepIdx ? 'bg-amber-500' : 'bg-slate-700'}`} />
                )}
              </div>
            );
          })}
        </div>
      </div>

      <AnimatePresence mode="wait">
        {step === 'form' && (
          <motion.div
            key="form"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="px-4 mt-6 space-y-4"
          >
            {/* Driver name */}
            <Card className="bg-card bg-card border-border">
              <CardContent className="p-4 space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <User className="size-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground">司機資料</span>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="driverName" className="text-xs text-muted-foreground">姓名</Label>
                  <Input
                    id="driverName"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    placeholder="例如：陳大文"
                    className="bg-muted border-border text-foreground placeholder:text-muted-foreground focus:border-primary"
                  />
                </div>
                <div className="space-y-1">
                  <Label htmlFor="license" className="text-xs text-muted-foreground">司機證編號</Label>
                  <Input
                    id="license"
                    value={licenseNo}
                    onChange={(e) => setLicenseNo(e.target.value)}
                    placeholder="例如：TP12345"
                    className="bg-muted border-border text-foreground placeholder:text-muted-foreground focus:border-primary font-mono"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Vehicle info */}
            <Card className="bg-card bg-card border-border">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Car className="size-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground">車輛資料</span>
                </div>
                <div className="space-y-1">
                  <Label htmlFor="plate" className="text-xs text-muted-foreground">車牌號碼</Label>
                  <Input
                    id="plate"
                    value={plate}
                    onChange={(e) => setPlate(e.target.value.toUpperCase())}
                    placeholder="例如：AB 1234"
                    className="bg-muted border-border text-foreground placeholder:text-muted-foreground focus:border-primary font-mono tracking-wider"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs text-muted-foreground">車型</Label>
                  <RadioGroup value={carType} onValueChange={(v) => setCarType(v as '4-seater' | '6-seater')} className="grid grid-cols-2 gap-2">
                    <div>
                      <Label
                        htmlFor="car-4"
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition-all h-20 text-center ${
                          carType === '4-seater'
                            ? 'border-primary bg-primary/10 text-foreground'
                            : 'border-border text-muted-foreground hover:border-slate-500'
                        }`}
                      >
                        <RadioGroupItem value="4-seater" id="car-4" className="sr-only" />
                        <Car className="size-6 mb-1" />
                        <span className="text-xs font-medium">4 人車</span>
                        <span className="text-[10px] opacity-70">市區的士</span>
                      </Label>
                    </div>
                    <div>
                      <Label
                        htmlFor="car-6"
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border cursor-pointer transition-all h-20 text-center ${
                          carType === '6-seater'
                            ? 'border-primary bg-primary/10 text-foreground'
                            : 'border-border text-muted-foreground hover:border-slate-500'
                        }`}
                      >
                        <RadioGroupItem value="6-seater" id="car-6" className="sr-only" />
                        <Car className="size-6 mb-1" />
                        <span className="text-xs font-medium">6 人車</span>
                        <span className="text-[10px] opacity-70">Comfort 大車</span>
                      </Label>
                    </div>
                  </RadioGroup>
                </div>
              </CardContent>
            </Card>

            {/* Document upload - mock */}
            <Card className="bg-card bg-card border-border">
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-2">
                  <Upload className="size-4 text-primary" />
                  <span className="text-sm font-semibold text-foreground">證件上傳</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button className="flex flex-col items-center justify-center p-4 rounded-xl border-2 border-dashed border-border hover:border-slate-500 hover:bg-accent/30 transition-colors">
                    <Upload className="size-6 text-slate-500 mb-1" />
                    <span className="text-xs text-muted-foreground">身份證</span>
                    <span className="text-[10px] text-emerald-400 mt-1">✓ 已上傳</span>
                  </button>
                  <button className="flex flex-col items-center justify-center p-4 rounded-xl border-2 border-dashed border-border hover:border-slate-500 hover:bg-accent/30 transition-colors">
                    <Upload className="size-6 text-slate-500 mb-1" />
                    <span className="text-xs text-muted-foreground">司機證</span>
                    <span className="text-[10px] text-emerald-400 mt-1">✓ 已上傳</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 text-center">
                  示範版本：證件已自動識別，無需真實上傳
                </p>
              </CardContent>
            </Card>

            {/* Submit */}
            <Button
              size="lg"
              className="w-full h-14 rounded-2xl font-semibold text-base shadow-lg shadow-primary/25"
              onClick={handleSubmit}
              disabled={!isFormValid || submitting}
            >
              提交驗證申請
            </Button>

            <p className="text-[11px] text-slate-500 text-center px-4">
              提交後管理員會喺 1-2 個工作天內完成審核。
            </p>
          </motion.div>
        )}

        {step === 'review' && (
          <motion.div
            key="review"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="px-4 mt-12 flex flex-col items-center text-center"
          >
            <div className="size-20 rounded-full bg-primary/20 flex items-center justify-center mb-4">
              <Loader2 className="size-10 text-primary animate-spin" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">審核進行中</h2>
            <p className="text-sm text-muted-foreground max-w-xs">
              我哋正在驗證你嘅資料，請稍等片刻...
            </p>
            <div className="mt-6 w-full max-w-xs space-y-2">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-card text-left">
                <div className="size-6 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <Check className="size-3.5 text-emerald-400" />
                </div>
                <span className="text-sm text-muted-foreground">身份證驗證</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-card text-left">
                <div className="size-6 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <Check className="size-3.5 text-emerald-400" />
                </div>
                <span className="text-sm text-muted-foreground">司機證核實</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/10 text-left">
                <Loader2 className="size-6 text-primary animate-spin ml-0.5" />
                <span className="text-sm text-foreground">車牌登記確認</span>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'pending' && (
          <motion.div
            key="pending"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            className="px-4 mt-8 flex flex-col items-center text-center"
          >
            <div className="size-24 rounded-full bg-amber-500/20 flex items-center justify-center mb-4 shadow-lg shadow-amber-500/20">
              <Clock className="size-12 text-amber-400" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-2">申請已提交</h2>
            <p className="text-sm text-muted-foreground max-w-xs mb-6">
              你嘅司機驗證申請已遞交，管理員會盡快審批。<br />
              審批結果會顯示喺接單大廳。
            </p>
            <div className="w-full max-w-xs p-4 rounded-2xl bg-card border border-amber-500/30 text-left space-y-2">
              <div className="flex items-center gap-3">
                <div className="size-10 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <User className="size-5 text-amber-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">{driverName || '申請人'}</div>
                  <div className="text-xs text-muted-foreground font-mono">{licenseNo || 'TP12345'}</div>
                </div>
                <span className="text-xs px-2 py-1 rounded-full bg-amber-500/20 text-amber-300 shrink-0">
                  待審批
                </span>
              </div>
              <div className="pt-2 border-t bg-card border-border text-xs text-muted-foreground">
                車牌：<span className="font-mono text-muted-foreground">{plate || 'AB 1234'}</span>
                {' · '}
                車型：<span className="text-muted-foreground">{carType === '6-seater' ? '6 人車' : '4 人車'}</span>
              </div>
            </div>

            <Button
              variant="outline"
              className="mt-6 w-full max-w-xs h-12 rounded-xl border-border text-muted-foreground hover:bg-accent"
              onClick={() => navigate('/driver')}
            >
              返接單大廳
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
