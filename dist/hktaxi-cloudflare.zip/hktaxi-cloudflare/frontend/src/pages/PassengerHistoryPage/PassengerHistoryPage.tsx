import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Navigation, Clock, Star, X, Receipt, MessageCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useI18n } from '@/lib/i18n';
import * as api from '@/lib/api';

interface IChatMessage {
  id: string;
  text: string;
  from: 'passenger' | 'driver';
  timestamp: number;
}

interface IHistoryItem {
  id: string;
  pickup: { name: string };
  destination: { name: string };
  estimatedFare: number;
  actualFare?: number;
  driver?: { name: string; imageUrl: string; rating: number };
  createdAt: number;
  driverRating?: number;
  passengerRating?: number;
  status: string;
  messages?: IChatMessage[];
}

export default function PassengerHistoryPage() {
  const [history, setHistory] = useState<IHistoryItem[]>([]);
  const [selected, setSelected] = useState<IHistoryItem | null>(null);
  const [loading, setLoading] = useState(true);
  const { t } = useI18n();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const orders = await api.getPassengerHistory();
        if (cancelled) return;
        const mapped: IHistoryItem[] = orders.map((o) => ({
          id: o.id,
          pickup: { name: o.pickupName },
          destination: { name: o.destinationName },
          estimatedFare: o.estimatedFare,
          actualFare: o.actualFare ?? undefined,
          driver: o.driverName
            ? {
                name: o.driverName,
                imageUrl: o.driverImageUrl ?? '',
                rating: o.driverRating ?? 5,
              }
            : undefined,
          createdAt: new Date(o.createdAt).getTime(),
          driverRating: o.driverRating ?? undefined,
          passengerRating: o.passengerRating ?? undefined,
          status: o.status,
          messages: [],
        }));
        setHistory(mapped);
      } catch {
        setHistory([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const loadDetail = async (item: IHistoryItem) => {
    try {
      const msgs = await api.getOrderMessages(item.id);
      const chatMsgs: IChatMessage[] = msgs.map((m) => ({
        id: m.id,
        text: m.text,
        from: m.senderRole as 'passenger' | 'driver',
        timestamp: new Date(m.createdAt).getTime(),
      }));
      setSelected({ ...item, messages: chatMsgs });
    } catch {
      setSelected(item);
    }
  };

  const formatDate = (ts: number) => {
    const d = new Date(ts);
    return `${d.getMonth() + 1}月${d.getDate()}日`;
  };

  const formatTime = (ts: number) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-slate-50 pb-24">
      {/* Header */}
      <div className="px-4 pt-6 pb-4 sticky top-0 z-10 bg-white/80 backdrop-blur-md">
        <h1 className="text-2xl font-bold text-foreground">{t.passengerHistory.title}</h1>
        <p className="text-sm text-muted-foreground">共 {history.length} 個行程</p>
      </div>

      {/* List */}
      <div className="px-4 space-y-3">
        {loading ? (
          <div className="text-center py-16">
            <div className="text-sm text-muted-foreground">載入中...</div>
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-16">
            <div className="size-16 mx-auto mb-4 rounded-full bg-slate-100 flex items-center justify-center">
              <Receipt className="size-8 text-slate-400" />
            </div>
            <div className="text-foreground font-medium mb-1">{t.passengerHistory.empty}</div>
            <div className="text-sm text-muted-foreground">叫過車之後會喺度顯示㗎</div>
          </div>
        ) : (
          history.map((item, i) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card
                className="shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => loadDetail(item)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="text-xs text-muted-foreground">
                      {formatDate(item.createdAt)} {formatTime(item.createdAt)}
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {item.status === 'finished' || item.status === 'paid' || item.status === 'completed'
                        ? t.passengerHistory.status.finished
                        : item.status}
                    </Badge>
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="flex flex-col items-center pt-1">
                      <div className="size-2.5 rounded-full bg-emerald-500" />
                      <div className="w-px h-6 bg-slate-200 my-0.5" />
                      <div className="size-2.5 rounded-full bg-red-500" />
                    </div>
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="text-sm font-medium text-foreground truncate">
                        {item.pickup.name}
                      </div>
                      <div className="text-sm font-medium text-foreground truncate">
                        {item.destination.name}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-primary">
                        HK${(item.actualFare ?? item.estimatedFare).toFixed(0)}
                      </div>
                      {item.driverRating ? (
                        <div className="flex items-center justify-end gap-0.5 mt-0.5">
                          <Star className="size-3 fill-amber-400 text-amber-400" />
                          <span className="text-xs text-amber-600">
                            {item.driverRating}
                          </span>
                        </div>
                      ) : (
                        <div className="text-xs text-muted-foreground mt-0.5">未評分</div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))
        )}
      </div>

      {/* Detail modal */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/40 backdrop-blur-sm flex items-end"
            onClick={() => setSelected(null)}
          >
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="w-full bg-white rounded-t-3xl max-h-[80vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-5">
                <div className="flex items-center justify-between mb-5">
                  <h3 className="text-lg font-bold text-foreground">行程詳情</h3>
                  <button
                    onClick={() => setSelected(null)}
                    className="size-8 rounded-full bg-slate-100 flex items-center justify-center"
                  >
                    <X className="size-4 text-slate-500" />
                  </button>
                </div>

                {selected.driver && (
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl mb-4">
                    <Avatar className="size-12">
                      <AvatarImage
                        src={selected.driver.imageUrl}
                        alt={selected.driver.name}
                      />
                      <AvatarFallback>{selected.driver.name[0]}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-semibold text-foreground">
                        {selected.driver.name}
                      </div>
                      <div className="flex items-center gap-1 text-amber-500">
                        <Star className="size-3.5 fill-amber-400" />
                        <span className="text-sm">{selected.driver.rating}</span>
                      </div>
                    </div>
                    {selected.driverRating ? (
                      <div className="text-right">
                        {/* star rating display */}
                        <div className="flex items-center gap-0.5">
                          {[1, 2, 3, 4, 5].map((s) => (
                            <Star
                              key={s}
                              className={`size-4 ${
                                s <= (selected.driverRating ?? 0)
                                  ? 'fill-amber-400 text-amber-400'
                                  : 'text-slate-200'
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                    ) : null}
                  </div>
                )}

                <div className="space-y-3 mb-4">
                  <div className="flex items-center gap-3">
                    <MapPin className="size-4 text-emerald-500 shrink-0" />
                    <div className="flex-1">
                      <div className="text-xs text-emerald-600">上車</div>
                      <div className="text-sm font-medium text-foreground">
                        {selected.pickup.name}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Navigation className="size-4 text-red-500 shrink-0" />
                    <div className="flex-1">
                      <div className="text-xs text-red-600">落車</div>
                      <div className="text-sm font-medium text-foreground">
                        {selected.destination.name}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-xl mb-4">
                  <div>
                    <div className="text-xs text-slate-500 mb-1">預計車費</div>
                    <div className="font-semibold text-muted-foreground line-through">
                      HK${selected.estimatedFare.toFixed(0)}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 mb-1">實際車費</div>
                    <div className="font-bold text-primary text-lg">
                      HK${(selected.actualFare ?? selected.estimatedFare).toFixed(0)}
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl mb-4">
                  <div className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                    <Clock className="size-3" />
                    行程時間
                  </div>
                  <div className="text-sm font-medium text-foreground">
                    {formatDate(selected.createdAt)} {formatTime(selected.createdAt)}
                  </div>
                </div>

                {/* 聊天記錄 */}
                {selected.messages && selected.messages.length > 0 && (
                  <div className="p-3 bg-slate-50 rounded-xl mb-4">
                    <div className="text-xs text-slate-500 mb-2 flex items-center gap-1">
                      <MessageCircle className="size-3" />
                      聊天記錄 ({selected.messages.length})
                    </div>
                    <div className="space-y-2 max-h-40 overflow-y-auto">
                      {selected.messages.map((msg) => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.from === 'passenger' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] px-2.5 py-1.5 rounded-xl text-xs ${
                              msg.from === 'passenger'
                                ? 'bg-primary text-white rounded-br-sm'
                                : 'bg-white border border-slate-200 text-foreground rounded-bl-sm'
                            }`}
                          >
                            {msg.text}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="text-center">
                  <Badge variant="outline" className="font-mono text-xs">
                    訂單編號：{selected.id}
                  </Badge>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
