import { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import {
  MapPin,
  Navigation,
  Search,
  X,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  Phone,
  Mail,
  User,
  MessageCircle,
  Locate,
  Loader2,
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
  SheetDescription,
} from '@/components/ui/sheet';
import AMapView from '@/components/AMapView';
import { MOCK_LANDMARKS } from '@/data/landmarks';
import { MOCK_DRIVERS } from '@/data/drivers';
import { useOrder, type CarType } from '@/lib/order-context';
import { calcFare, FARE_DISCLAIMER, calcDistanceKm, haversineKm } from '@/lib/taxi-utils';
import { UniversalLink } from '@lark-apaas/client-toolkit-lite';
import LocationSearchSheet, { type PoiResult } from '@/components/LocationSearchSheet';
import { useTheme } from '@/lib/theme-context';
import { useI18n } from '@/lib/i18n';

export default function PassengerHomePage() {
  const { theme } = useTheme();
  const { t } = useI18n();

  // 根據主題設定默認上下車點
  const defaultPickup = theme === 'green'
    ? { name: '沙田', address: '新界沙田', lat: 22.3820, lng: 114.1880, district: '新界沙田' as const }
    : { name: '中環', address: '港島中西區', lat: 22.2819, lng: 114.1585, district: '港島中西區' as const };
  const defaultDest = theme === 'green'
    ? { name: '元朗', address: '新界元朗', lat: 22.4450, lng: 114.0220, district: '新界元朗' as const }
    : { name: '銅鑼灣', address: '港島灣仔', lat: 22.2807, lng: 114.1855, district: '港島灣仔' as const };

  const [pickup, setPickup] = useState<PoiResult>(defaultPickup);
  const [destination, setDestination] = useState<PoiResult>(defaultDest);

  // 主題切換時更新默認地點（如果用戶未手動改過）
  useEffect(() => {
    const nPU = theme === 'green'
      ? { name: '沙田', address: '新界沙田', lat: 22.3820, lng: 114.1880, district: '新界沙田' as const }
      : { name: '中環', address: '港島中西區', lat: 22.2819, lng: 114.1585, district: '港島中西區' as const };
    const nD = theme === 'green'
      ? { name: '元朗', address: '新界元朗', lat: 22.4450, lng: 114.0220, district: '新界元朗' as const }
      : { name: '銅鑼灣', address: '港島灣仔', lat: 22.2807, lng: 114.1855, district: '港島灣仔' as const };
    setPickup(nPU);
    setDestination(nD);
  }, [theme]);
  const [showPickupSearch, setShowPickupSearch] = useState(false);
  const [showDestSearch, setShowDestSearch] = useState(false);
  const [locating, setLocating] = useState(false);
  const [carType, setCarType] = useState<CarType>('4-seater');
  const [discount85, setDiscount85] = useState<boolean>(false);
  const [tip, setTip] = useState<number>(0);
  const [customTip, setCustomTip] = useState<string>('');
  const [showCustomTip, setShowCustomTip] = useState(false);
  const [luggageCount, setLuggageCount] = useState<number>(0);
  const [isNight, setIsNight] = useState<boolean>(() => {
    const h = new Date().getHours();
    return h >= 23 || h < 6;
  });
  const navigate = useNavigate();
  const { createOrder, isLoggedIn } = useOrder();
  const [calling, setCalling] = useState(false);

  const fareResult = useMemo(() => {
    if (!pickup || !destination) return null;
    const distanceKm = Math.max(0.5, haversineKm(pickup, destination) * 1.3);
    // 綠的主題：4人車用新界費率；6人車保持不變
    const baseFare = carType === '6-seater' ? 35 : (theme === 'green' ? 23.5 : 29);
    const perKm = carType === '6-seater' ? 12.5 : (theme === 'green' ? 8.5 : 9.5);
    const remainingKm = Math.max(0, distanceKm - 2);
    const mileageFare = Math.ceil((remainingKm * 1000) / 200) * (perKm * 0.2);
    const nightSurcharge = isNight ? (baseFare + mileageFare) * 0.1 : 0;
    const luggageSurcharge = luggageCount > 0 ? 6 + (luggageCount - 1) * 6 : 0;
    // 過海隧道附加費：港島 ↔ 九龍粗略判斷
    const crossHarbour =
      pickup.lat < 22.3 !== destination.lat < 22.3 &&
      pickup.lng > 114.13 &&
      destination.lng > 114.13;
    const tunnelSurcharge = crossHarbour ? 25 : 0;
    const subtotal = baseFare + mileageFare + nightSurcharge + luggageSurcharge + tunnelSurcharge;
    const originalTotal = Math.round(subtotal + tip);
    const total = discount85 ? Math.round(originalTotal * 0.85) : originalTotal;
    const taxiTypeName = discount85
      ? t.passengerHome.discountRandom
      : carType === '6-seater'
        ? '6 人車（跨區大車）'
        : theme === 'green' ? t.nav.taxiGreen : t.nav.taxiRed;
    return {
      total,
      originalTotal,
      discount85,
      distanceKm,
      taxiTypeName,
      breakdown: {
        flagfall: baseFare,
        mileageFare: Number(mileageFare.toFixed(1)),
        waitingFare: 0,
        nightSurcharge: Number(nightSurcharge.toFixed(1)),
        luggageSurcharge,
        tunnelSurcharge,
        comfort6Surcharge: 0,
        tip,
      },
    };
  }, [pickup, destination, carType, tip, luggageCount, isNight, discount85]);

  const fare = fareResult?.total ?? 0;
  const distance = fareResult?.distanceKm ?? 0;
  const fareLow = fare > 0 ? Math.round(fare * 0.9) : 0;
  const fareHigh = fare > 0 ? Math.round(fare * 1.1) : 0;

  const filteredLandmarks = useMemo(() => MOCK_LANDMARKS, []);

  const openPickupSearch = () => setShowPickupSearch(true);
  const openDestSearch = () => setShowDestSearch(true);

  const handlePickupSelect = (poi: PoiResult) => setPickup(poi);
  const handleDestSelect = (poi: PoiResult) => setDestination(poi);

  const handleUseMyLocation = () => {
    if (!navigator.geolocation) {
      toast.error('你嘅瀏覽器唔支援定位功能，請手動輸入上車地點');
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        const { latitude, longitude } = pos.coords;
        // 先用「我嘅位置」做名，然後嘗試用 Geocoder 反查地址
        setPickup({
          name: '我嘅位置',
          address: '正在取得地址...',
          lat: latitude,
          lng: longitude,
        });

        // 嘗試用高德 Geocoder 反查地址（如果有 AMap）
        if (window.AMap && window.AMap.Geocoder) {
          try {
            const geocoder = new window.AMap.Geocoder({ city: '香港', radius: 200 });
            geocoder.getAddress([longitude, latitude], (status: string, result: any) => {
              if (status === 'complete' && result.regeocode?.formattedAddress) {
                const addr = result.regeocode.formattedAddress;
                setPickup((prev) => ({
                  ...prev,
                  name: addr.length > 12 ? addr.slice(0, 12) + '...' : addr,
                  address: addr,
                }));
              }
            });
          } catch {
            // 失敗就算，保持「我嘅位置」
          }
        }

        toast.success('已使用你嘅位置作為上車點');
      },
      (err) => {
        setLocating(false);
        let msg = '無法取得位置，請手動輸入上車地點';
        if (err.code === 1) msg = '你拒絕咗定位授權，請手動輸入上車地點';
        else if (err.code === 2) msg = '定位失敗，請檢查網絡或手動輸入上車地點';
        else if (err.code === 3) msg = '定位超時，請再試一次或手動輸入上車地點';
        toast.error(msg);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };


  const handleCallTaxi = async () => {
    if (!isLoggedIn) {
      navigate('/');
      return;
    }
    if (!pickup || !destination || !fareResult) return;
    // 85 折優惠：隨機派車型
    const finalCarType: CarType = discount85
      ? Math.random() > 0.5
        ? '4-seater'
        : '6-seater'
      : carType;
    setCalling(true);
    try {
      await createOrder(
        {
          name: pickup.name,
          lat: pickup.lat,
          lng: pickup.lng,
        },
        {
          name: destination.name,
          lat: destination.lat,
          lng: destination.lng,
        },
        fare,
        finalCarType,
        tip,
        {
          luggageCount,
          isNight,
          taxiTypeName: fareResult.taxiTypeName,
          fareBreakdown: fareResult.breakdown,
        },
        discount85,
        theme === 'green' ? 'green' : 'red',
      );
      navigate('/passenger/waiting');
    } catch (err) {
      toast.error('叫車失敗，請重試');
    } finally {
      setCalling(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-background to-background pb-24">
      {/* 地圖區 */}
      <div className="relative px-4 pt-4">
        <AMapView
          pickupName={pickup?.name}
          destinationName={destination?.name}
          pickupLat={pickup?.lat}
          pickupLng={pickup?.lng}
          destLat={destination?.lat}
          destLng={destination?.lng}
          nearbyDrivers={MOCK_DRIVERS}
          showRoute={!!(pickup && destination)}
          height="h-72"
        />

        {/* 地圖浮層：附近司機 + 估計車費 */}
        <div className="absolute bottom-4 left-6 right-6 flex gap-2">
          <div className="flex-1 bg-white/90 backdrop-blur rounded-xl px-3 py-2 shadow-sm border border-slate-100">
            <div className="text-[10px] text-muted-foreground">{t.passengerHome.nearbyDrivers}</div>
            <div className="text-lg font-bold text-foreground">
              {MOCK_DRIVERS.length} 部
            </div>
          </div>
          <div className="flex-1 bg-white/90 backdrop-blur rounded-xl px-3 py-2 shadow-sm border border-slate-100">
            <div className="text-[10px] text-muted-foreground">
              {t.passengerHome.estimatedFare}{discount85 ? '（85折）' : ''}
            </div>
            <div className="text-lg font-bold text-primary">
              HK${fareLow || '--'}-{fareHigh || '--'}
              {tip > 0 && (
                <span className="text-[10px] ml-1 text-amber-600">含貼士</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 叫車資料區（全部直接展示，唔收埋） */}
      <div className="px-4 mt-4 space-y-4">
        {/* 上車 + 目的地 */}
        <Card className="shadow-sm border-slate-200/70">
          <CardContent className="p-4 space-y-2">
            <div className="flex items-center gap-2">
              <button
                onClick={openPickupSearch}
                className="flex-1 flex items-center gap-3 p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100/70 transition-colors text-left min-w-0"
              >
                <div className="size-8 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                  <MapPin className="size-4 text-white" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-emerald-700 font-medium">{t.passengerHome.pickup}</div>
                  <div className="text-sm font-semibold text-foreground truncate">
                    {pickup?.name}
                  </div>
                </div>
                <ChevronRight className="size-4 text-emerald-600 shrink-0" />
              </button>
              <button
                onClick={handleUseMyLocation}
                disabled={locating}
                className="size-12 rounded-xl bg-emerald-50 hover:bg-emerald-100/70 transition-colors flex items-center justify-center shrink-0 disabled:opacity-60"
                 title={t.passengerHome.useMyLocation}
              >
                {locating ? (
                  <Loader2 className="size-5 text-emerald-600 animate-spin" />
                ) : (
                  <Locate className="size-5 text-emerald-600" />
                )}
              </button>
            </div>

            <div className="flex items-center gap-3 pl-4">
              <div className="w-px h-3 bg-slate-300 ml-3.5" />
            </div>

            <button
              onClick={openDestSearch}
              className="w-full flex items-center gap-3 p-3 rounded-xl bg-red-50 hover:bg-red-100/70 transition-colors text-left"
            >
              <div className="size-8 rounded-full bg-red-500 flex items-center justify-center shrink-0">
                <Navigation className="size-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs text-red-700 font-medium">{t.passengerHome.destination}</div>
                <div className="text-sm font-semibold text-foreground truncate">
                  {destination?.name}
                </div>
              </div>
              <ChevronRight className="size-4 text-red-600" />
            </button>
          </CardContent>
        </Card>

        {/* 車型選擇 */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-semibold text-foreground">{t.passengerHome.chooseCar}</div>
            {discount85 && (
              <span className="text-[11px] text-muted-foreground">{t.passengerHome.discount85}：隨機派車</span>
            )}
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[
              { value: '4-seater' as CarType, label: t.passengerHome.fourSeater, seats: t.passengerHome.fourSeats },
              { value: '6-seater' as CarType, label: t.passengerHome.sixSeater, seats: t.passengerHome.sixSeats },
            ].map((opt) => (
              <button
                key={opt.value}
                onClick={() => !discount85 && setCarType(opt.value)}
                disabled={discount85}
                className={`relative p-4 rounded-2xl border-2 transition-all text-left ${
                  discount85
                    ? 'border-slate-200/50 bg-slate-50/50 opacity-50 cursor-not-allowed'
                    : carType === opt.value
                      ? 'border-primary bg-primary/5 shadow-md shadow-primary/10'
                      : 'border-slate-200 bg-card hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-lg font-bold ${
                      discount85
                        ? 'text-muted-foreground'
                        : carType === opt.value
                          ? 'text-primary'
                          : 'text-foreground'
                    }`}
                  >
                    {opt.label}
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">{opt.seats}</div>
                <div className="text-[11px] text-muted-foreground mt-1">
                  {discount85 ? '優惠期間隨機派發' : fareResult?.taxiTypeName ?? '按路線匹配'}
                </div>
                {opt.value === '6-seater' && !discount85 && (
                  <div className="text-[11px] text-amber-600 mt-1.5 leading-snug">
                    💡 師傅好多時要跨區接單；如果加貼士，師傅動力更大、接單更快。
                  </div>
                )}
                {!discount85 && carType === opt.value && (
                  <div className="absolute top-2 right-2 size-5 rounded-full bg-primary flex items-center justify-center">
                    <svg
                      className="size-3 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={3}
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                )}
                {discount85 && (
                  <div className="absolute top-2 right-2 size-5 rounded-full bg-slate-300 flex items-center justify-center">
                    <svg
                      className="size-3 text-white"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth={3}
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m0 0v2m0-2h2m-2 0H10" />
                    </svg>
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* 85 折優惠 */}
        <div>
          <button
            onClick={() => setDiscount85(!discount85)}
            className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
              discount85
                ? 'border-primary bg-gradient-to-r from-primary/10 to-rose-50 shadow-md shadow-primary/10'
                : 'border-slate-200 bg-card hover:border-primary/30 hover:bg-primary/5'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`size-10 rounded-full flex items-center justify-center shrink-0 ${
                  discount85 ? 'bg-primary text-white' : 'bg-rose-50 text-rose-600'
                }`}
              >
                <svg
                  className="size-5"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M20 12V8H6a2 2 0 0 1-2-2c0-1.1.9-2 2-2h12v4" />
                  <path d="M4 6v12c0 1.1.9 2 2 2h14v-4" />
                  <path d="M18 12a2 2 0 0 0 0 4h4v-4Z" />
                </svg>
              </div>
              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-sm font-bold ${
                      discount85 ? 'text-primary' : 'text-foreground'
                    }`}
                  >
                    {t.passengerHome.discount85}
                  </span>
                  {discount85 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary text-white font-medium">
                      {t.passengerHome.discount85Enabled}
                    </span>
                  )}
                </div>
                  <div className="text-[11px] text-muted-foreground mt-0.5">
                    {t.passengerHome.discountDesc}
                  </div>
              </div>
            </div>
            <div
              className={`relative w-11 h-6 rounded-full transition-colors shrink-0 ${
                discount85 ? 'bg-primary' : 'bg-slate-300'
              }`}
            >
              <div
                className={`absolute top-0.5 size-5 rounded-full bg-white shadow transition-transform ${
                  discount85 ? 'translate-x-5' : 'translate-x-0.5'
                }`}
              />
            </div>
          </button>
          {discount85 && (
            <div className="mt-2 flex items-start gap-2 px-3 py-2.5 rounded-xl bg-amber-50 border border-amber-200/50">
              <svg
                className="size-4 text-amber-500 shrink-0 mt-0.5"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
              <div className="text-[11px] text-amber-800/80 leading-relaxed">
                <span className="font-semibold">{t.passengerHome.discountWaitFull}</span>
                 <br />
                 {t.passengerHome.discountTip}
              </div>
            </div>
          )}
        </div>

        {/* 貼士服務費 */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5">
              <Sparkles className="size-4 text-amber-500" />
               <span className="text-sm font-semibold text-foreground">{t.passengerHome.tipService}</span>
            </div>
            <span className="text-xs text-muted-foreground">
               {discount85 ? t.passengerHome.tipHintDiscount : t.passengerHome.tipHint}
            </span>
          </div>
          <div className="grid grid-cols-4 gap-2">
            {[0, 20, 50, 100].map((amount) => (
              <button
                key={amount}
                onClick={() => {
                  setTip(amount);
                  setShowCustomTip(false);
                  setCustomTip('');
                }}
                className={`py-3 rounded-xl border-2 transition-all text-center ${
                  tip === amount && !showCustomTip
                    ? 'border-amber-500 bg-amber-50 shadow-md shadow-amber-500/10'
                    : 'border-slate-200 bg-card hover:border-slate-300'
                }`}
              >
                <div
                  className={`text-sm font-bold ${
                    tip === amount && !showCustomTip
                      ? 'text-amber-600'
                      : 'text-foreground'
                  }`}
                >
                   {amount === 0 ? t.passengerHome.noTip : `HK$${amount}`}
                </div>
              </button>
            ))}
          </div>
          {showCustomTip ? (
            <div className="mt-2 flex items-center gap-2">
              <div className="flex-1 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                  HK$
                </span>
                <input
                  type="number"
                  value={customTip}
                  onChange={(e) => {
                    const v = e.target.value;
                    setCustomTip(v);
                    const num = parseInt(v, 10);
                    if (!isNaN(num) && num >= 0 && num <= 500) {
                      setTip(num);
                    } else if (v === '') {
                      setTip(0);
                    }
                  }}
                  placeholder="輸入金額"
                  className="w-full pl-12 pr-4 py-2.5 rounded-xl border-2 border-amber-500/50 bg-amber-50 text-sm font-medium text-foreground focus:outline-none focus:border-amber-500"
                />
              </div>
              <button
                onClick={() => {
                  setShowCustomTip(false);
                  setCustomTip('');
                  setTip(0);
                }}
                className="text-xs text-muted-foreground hover:text-foreground px-2"
              >
                取消
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowCustomTip(true)}
              className="mt-2 text-xs text-primary hover:underline"
            >
               + {t.passengerHome.customAmount}
            </button>
          )}
        </div>

        {/* 附加選項 */}
        <div>
           <div className="text-sm font-semibold text-foreground mb-2">{t.passengerHome.extras}</div>
          <div className="space-y-2">
            <div className="flex items-center justify-between p-3 rounded-xl bg-card border border-slate-200/70">
              <div className="flex items-center gap-3">
                <div className="size-9 rounded-full bg-blue-50 flex items-center justify-center">
                  <svg
                    className="size-4 text-blue-600"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M6 7V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2" />
                    <rect x="3" y="7" width="18" height="13" rx="2" />
                    <circle cx="8" cy="14" r="1" />
                    <circle cx="16" cy="14" r="1" />
                  </svg>
                </div>
                <div>
                  <div className="text-sm font-medium text-foreground">{t.passengerHome.luggage}</div>
                   <div className="text-xs text-muted-foreground">{t.passengerHome.luggagePer}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setLuggageCount(Math.max(0, luggageCount - 1))}
                  className="size-8 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors"
                >
                  <span className="text-lg font-bold text-foreground leading-none">−</span>
                </button>
                <span className="w-6 text-center text-sm font-semibold text-foreground">
                  {luggageCount}
                </span>
                <button
                  onClick={() => setLuggageCount(Math.min(8, luggageCount + 1))}
                  className="size-8 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 transition-colors"
                >
                  <span className="text-lg font-bold text-foreground leading-none">+</span>
                </button>
              </div>
            </div>

            <button
              onClick={() => setIsNight(!isNight)}
              className={`w-full flex items-center justify-between p-3 rounded-xl border transition-colors ${
                isNight ? 'bg-indigo-50 border-indigo-200/60' : 'bg-card border-slate-200/70'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`size-9 rounded-full flex items-center justify-center ${
                    isNight ? 'bg-indigo-500' : 'bg-slate-100'
                  }`}
                >
                  <svg
                    className={`size-4 ${isNight ? 'text-white' : 'text-slate-500'}`}
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth={2}
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
                  </svg>
                </div>
                <div className="text-left">
                  <div className="text-sm font-medium text-foreground">{t.passengerHome.nightSurcharge}</div>
                   <div className="text-xs text-muted-foreground">{t.passengerHome.nightTime}</div>
                </div>
              </div>
              <div
                className={`relative w-11 h-6 rounded-full transition-colors ${
                  isNight ? 'bg-indigo-500' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`absolute top-0.5 size-5 rounded-full bg-white shadow transition-transform ${
                    isNight ? 'translate-x-5' : 'translate-x-0.5'
                  }`}
                />
              </div>
            </button>
          </div>
        </div>

        {/* 車費估算 + 細節 */}
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div>
               <div className="text-xs text-muted-foreground">{t.passengerHome.fareEstimate}</div>
              <div className="flex items-baseline gap-2">
                <span
                  className={`text-2xl font-bold ${
                    discount85 ? 'text-primary' : 'text-foreground'
                  }`}
                >
                  HK${fareLow || '--'}–{fareHigh || '--'}
                </span>
                {discount85 && fareResult && (
                  <span className="text-sm text-muted-foreground line-through">
                    原價 HK${Math.round(fareResult.originalTotal * 0.9)}–{Math.round(fareResult.originalTotal * 1.1)}
                  </span>
                )}
                <span className="text-xs text-muted-foreground">
                  · 約 {distance.toFixed(1)} 公里
                </span>
              </div>
              {discount85 && fareResult && (
                <div className="text-[11px] text-emerald-600 mt-0.5">
                  {t.passengerHome.saveAmount.replace('{amount}', String(fareResult.originalTotal - fareResult.total))}  {fareResult.originalTotal - fareResult.total}
                </div>
              )}
            </div>
            <Badge variant="secondary" className="text-xs">
              {fareResult?.taxiTypeName ?? '計算中'}
            </Badge>
          </div>

          {fareResult && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 space-y-1.5 text-xs">
              <div className="flex items-center justify-between text-muted-foreground">
                 <span>{t.passengerHome.flagfall}</span>
                <span className="text-foreground">
                  HK${fareResult.breakdown.flagfall.toFixed(1)}
                </span>
              </div>
              <div className="flex items-center justify-between text-muted-foreground">
                 <span>{t.passengerHome.mileageFare}</span>
                <span className="text-foreground">
                  HK${fareResult.breakdown.mileageFare.toFixed(1)}
                </span>
              </div>
              {fareResult.breakdown.nightSurcharge > 0 && (
                <div className="flex items-center justify-between text-muted-foreground">
                   <span>{t.passengerHome.nightFee}</span>
                  <span className="text-foreground">
                    HK${fareResult.breakdown.nightSurcharge.toFixed(1)}
                  </span>
                </div>
              )}
              {fareResult.breakdown.luggageSurcharge > 0 && (
                <div className="flex items-center justify-between text-muted-foreground">
                   <span>{t.passengerHome.luggageFee}（{luggageCount} 件）</span>
                  <span className="text-foreground">
                    HK${fareResult.breakdown.luggageSurcharge.toFixed(1)}
                  </span>
                </div>
              )}
              {fareResult.breakdown.tunnelSurcharge > 0 && (
                <div className="flex items-center justify-between text-muted-foreground">
                   <span>{t.passengerHome.tunnelFee}</span>
                  <span className="text-foreground">
                    HK${fareResult.breakdown.tunnelSurcharge.toFixed(0)}
                  </span>
                </div>
              )}
              {tip > 0 && (
                <div className="flex items-center justify-between text-amber-600">
                   <span>{t.passengerHome.tipFee}</span>
                  <span>HK${tip.toFixed(0)}</span>
                </div>
              )}
              <div className="border-t border-slate-200/70 pt-1.5 mt-1 flex items-center justify-between">
                 <span className="text-sm font-semibold text-foreground">{t.passengerHome.total}</span>
                <div className="text-right">
                  {discount85 && fareResult && (
                    <div className="text-[11px] text-muted-foreground line-through">
                      {t.passengerHome.originalPrice} HK${fareResult.originalTotal}
                    </div>
                  )}
                  <span
                    className={`text-sm font-bold ${
                      discount85 ? 'text-primary' : 'text-emerald-600'
                    }`}
                  >
                     {discount85 ? `${t.passengerHome.discountPrice} ` : '約 '}HK${fare}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* 示範費率提示 */}
          <div className="flex items-start gap-2 px-2 py-2 rounded-lg bg-amber-50/50 border border-amber-200/40">
            <svg
              className="size-4 text-amber-500 shrink-0 mt-0.5"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth={2}
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="10" />
              <line x1="12" y1="8" x2="12" y2="12" />
              <line x1="12" y1="16" x2="12.01" y2="16" />
            </svg>
            <div className="text-[11px] text-amber-800/80 leading-relaxed">
              {FARE_DISCLAIMER}。車費會因交通狀況、行車路線而有差異。
            </div>
          </div>

          {/* 政府跳錶正常收費 */}
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-emerald-50 border border-emerald-200/60">
            <div className="shrink-0 size-6 rounded-full bg-emerald-500 flex items-center justify-center">
              <ShieldCheck className="size-3.5 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-xs font-semibold text-emerald-800">
                 {t.passengerHome.govMeter}
              </div>
              <div className="text-[11px] text-emerald-700/80">
                 {t.passengerHome.govMeterDesc}
              </div>
            </div>
          </div>

          <Button
            size="lg"
            className="w-full h-14 text-base font-semibold rounded-2xl shadow-lg shadow-primary/25"
            onClick={handleCallTaxi}
            disabled={calling}
          >
            {calling ? '叫車中...' : isLoggedIn ? t.passengerHome.callTaxi : '請先登入'}
          </Button>
        </div>

        {/* 快捷選擇 */}
        <div>
           <div className="text-sm font-semibold text-foreground mb-3">{t.passengerHome.quickDest}</div>
          <div className="grid grid-cols-3 gap-2">
            {['中環', '尖沙咀', '旺角', '銅鑼灣', '金鐘', '機場'].map((loc) => (
              <button
                key={loc}
                onClick={() => {
                  const lm = MOCK_LANDMARKS.find((l) => l.name === loc);
                  if (lm) setDestination({ name: lm.name, address: lm.district, lat: lm.lat, lng: lm.lng, district: lm.district });
                }}
                className="py-2.5 px-3 rounded-xl bg-card border border-slate-200/70 text-sm font-medium text-foreground hover:border-primary/30 hover:bg-primary/5 transition-colors"
              >
                {loc}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 地點搜尋彈層（上車） */}
      <LocationSearchSheet
        open={showPickupSearch}
        title="選擇上車地點"
        onClose={() => setShowPickupSearch(false)}
        onSelect={handlePickupSelect}
      />

      {/* 地點搜尋彈層（目的地） */}
      <LocationSearchSheet
        open={showDestSearch}
        title="選擇目的地"
        onClose={() => setShowDestSearch(false)}
        onSelect={handleDestSelect}
      />

      {/* 浮動聯絡按鈕 */}
      <Sheet>
        <SheetTrigger asChild>
          <button
            className="fixed bottom-6 right-4 z-40 size-14 rounded-full bg-primary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
            aria-label="聯絡資訊"
          >
            <Phone className="size-5" />
          </button>
        </SheetTrigger>
        <SheetContent side="bottom" className="rounded-t-3xl p-0 pb-6">
          <SheetHeader className="p-5 pb-3">
            <SheetTitle className="text-lg font-bold">{t.passengerHome.contact}</SheetTitle>
             <SheetDescription>{t.passengerHome.contactFor}</SheetDescription>
          </SheetHeader>
          <div className="px-5 space-y-3">
            <div className="flex items-center gap-4 p-4 rounded-2xl bg-card border border-border">
              <div className="size-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <User className="size-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-foreground">Ethan Chan</div>
                <div className="text-xs text-muted-foreground">客戶服務主任</div>
              </div>
            </div>

            <UniversalLink
              to="tel:55888712"
              className="flex items-center gap-3 p-4 rounded-2xl bg-emerald-50 border border-emerald-200/60 hover:bg-emerald-100/70 transition-colors"
            >
              <div className="size-10 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                <Phone className="size-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="text-xs text-emerald-700 font-medium">{t.passengerHome.callHotline}</div>
                <div className="text-sm font-semibold text-emerald-900">5588 8712</div>
              </div>
              <ChevronRight className="size-4 text-emerald-600 shrink-0" />
            </UniversalLink>

            <UniversalLink
              to="mailto:tkdw0712@gmail.com"
              className="flex items-center gap-3 p-4 rounded-2xl bg-blue-50 border border-blue-200/60 hover:bg-blue-100/70 transition-colors"
            >
              <div className="size-10 rounded-full bg-blue-500 flex items-center justify-center shrink-0">
                <Mail className="size-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="text-xs text-blue-700 font-medium">{t.passengerHome.emailHotline}</div>
                <div className="text-sm font-semibold text-blue-900 truncate">
                  tkdw0712@gmail.com
                </div>
              </div>
              <ChevronRight className="size-4 text-blue-600 shrink-0" />
            </UniversalLink>

            <UniversalLink
              to="sms:55888712"
              className="flex items-center gap-3 p-4 rounded-2xl bg-purple-50 border border-purple-200/60 hover:bg-purple-100/70 transition-colors"
            >
              <div className="size-10 rounded-full bg-purple-500 flex items-center justify-center shrink-0">
                <MessageCircle className="size-4 text-white" />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="text-xs text-purple-700 font-medium">{t.passengerHome.smsHotline}</div>
                <div className="text-sm font-semibold text-purple-900">5588 8712</div>
              </div>
              <ChevronRight className="size-4 text-purple-600 shrink-0" />
            </UniversalLink>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
