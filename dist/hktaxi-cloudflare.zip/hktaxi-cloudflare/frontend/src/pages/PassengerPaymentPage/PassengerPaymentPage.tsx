import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Check,
  Receipt,
  MapPin,
  Navigation,
  Clock,
  CreditCard,
  Wallet,
  Banknote,
  Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { useOrder } from '@/lib/order-context';
import { useTheme } from '@/lib/theme-context';
import { useI18n } from '@/lib/i18n';

const paymentMethods = [
  { id: 'octopus', label: '八達通', sublabel: 'Octopus', icon: Wallet, color: 'bg-purple-100 text-purple-600' },
  { id: 'fps', label: '轉數快 FPS', sublabel: '快速支付', icon: Banknote, color: 'bg-cyan-100 text-cyan-600' },
  { id: 'alipayhk', label: 'AlipayHK', sublabel: '支付寶香港', icon: CreditCard, color: 'bg-blue-100 text-blue-600' },
  { id: 'wechat', label: 'WeChat Pay HK', sublabel: '微信支付', icon: CreditCard, color: 'bg-emerald-100 text-emerald-600' },
  { id: 'credit', label: '信用卡／扣賬卡', sublabel: 'Visa / Mastercard', icon: CreditCard, color: 'bg-indigo-100 text-indigo-600' },
  { id: 'applepay', label: 'Apple Pay', sublabel: '', icon: CreditCard, color: 'bg-slate-100 text-slate-700' },
  { id: 'googlepay', label: 'Google Pay', sublabel: '', icon: CreditCard, color: 'bg-amber-100 text-amber-700' },
  { id: 'cash', label: '現金', sublabel: '車上付款', icon: Banknote, color: 'bg-emerald-100 text-emerald-700' },
];

export default function PassengerPaymentPage() {
  const { order, markPaid } = useOrder();
  const navigate = useNavigate();
  const { theme } = useTheme();
  const { t } = useI18n();
  const [method, setMethod] = useState('octopus');
  const [paying, setPaying] = useState(false);
  const [paid, setPaid] = useState(false);

  useEffect(() => {
    if (!order) {
      navigate('/passenger');
      return;
    }
    if (order.status !== 'completed' && order.status !== 'paid') {
      // Not at payment stage yet
      if (order.status === 'accepted' || order.status === 'picked_up') {
        navigate('/passenger/riding');
      } else {
        navigate('/passenger');
      }
    }
  }, [order, navigate]);

  if (!order) return null;

  const actualFare = order.actualFare ?? order.estimatedFare;
  const baseFare = theme === 'green' ? 23.5 : 29;
  const baseTotal = actualFare - order.tip;
  const baseDistanceFare = order.carType === '6-seater'
    ? Math.round((baseTotal / 1.3 - baseFare) * 10) / 10
    : Math.round((baseTotal - baseFare) * 10) / 10;
  const surcharge = order.carType === '6-seater'
    ? Math.round((baseTotal - baseTotal / 1.3) * 10) / 10
    : 0;

  const handlePay = async () => {
    setPaying(true);
    await new Promise((r) => setTimeout(r, 800));
    try {
      await markPaid(method);
      setPaid(true);
      setTimeout(() => {
        navigate('/passenger/rating');
      }, 1200);
    } catch {
      // ignore
    } finally {
      setPaying(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-emerald-50 via-white to-slate-50 pb-8">
      {/* Header */}
      <div className="px-4 pt-6 pb-2">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2"
        >
          <div className="size-10 rounded-full bg-emerald-100 flex items-center justify-center">
            <Receipt className="size-5 text-emerald-600" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground">{t.passengerPayment.arrival}</h1>
             <p className="text-sm text-muted-foreground">{t.passengerPayment.thanks}</p>
          </div>
        </motion.div>
      </div>

      {/* Fare amount */}
      <div className="px-4 mt-4">
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-lg shadow-emerald-500/25"
        >
           <div className="text-sm opacity-80 mb-1">{t.passengerPayment.totalFare}</div>
          <div className="text-5xl font-black tabular-nums tracking-tight">
            HK${actualFare.toFixed(0)}
            <span className="text-lg font-medium opacity-80">.00</span>
          </div>
          <div className="flex items-center gap-2 mt-2">
            <Badge className="bg-white/20 text-white border-0 text-xs">{order.fareExtras?.taxiTypeName ?? '市區的士'}</Badge>
            <Badge className="bg-white/20 text-white border-0 text-xs">
              {order.distanceKm?.toFixed(1) ?? '3.5'} 公里
            </Badge>
          </div>
        </motion.div>
      </div>

      {/* Fare breakdown */}
      <div className="px-4 mt-4">
        <Card className="shadow-sm">
          <CardContent className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="size-4" />
                {t.passengerPayment.from}
              </div>
              <span className="text-sm font-medium text-foreground">{order.pickup.name}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Navigation className="size-4" />
                 {t.passengerPayment.to}
              </div>
              <span className="text-sm font-medium text-foreground">{order.destination.name}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="size-4" />
                 {t.passengerPayment.duration}
              </div>
              <span className="text-sm font-medium text-foreground">約 12 分鐘</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                車型
              </div>
              <span className="text-sm font-medium text-foreground">
                {order.carType === '6-seater' ? '6 人車 (Comfort)' : '4 人車 (市區)'}
              </span>
            </div>
            <div className="border-t border-slate-100 pt-3 mt-3 space-y-2">
              <div className="flex items-center justify-between text-sm">
                 <span className="text-muted-foreground">{t.passengerPayment.flagfall}</span>
                 <span className="text-foreground">HK${baseFare.toFixed(2)}</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                 <span className="text-muted-foreground">{t.passengerPayment.mileage}</span>
                <span className="text-foreground">HK${baseDistanceFare.toFixed(1)}</span>
              </div>
              {surcharge > 0 && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">6 人車附加費 (+30%)</span>
                  <span className="text-foreground">HK${surcharge.toFixed(1)}</span>
                </div>
              )}
              {order.tip > 0 && (
                <div className="flex items-center justify-between text-sm">
                   <span className="text-muted-foreground">{t.passengerPayment.tip}</span>
                  <span className="text-foreground">HK${order.tip.toFixed(0)}.00</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm pt-2 border-t border-slate-50">
                 <span className="font-semibold text-foreground">{t.passengerPayment.totalFare}</span>
                <span className="font-bold text-emerald-600">
                  HK${actualFare.toFixed(0)}.00
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment methods */}
      <div className="px-4 mt-4">
        <div className="text-sm font-semibold text-foreground mb-3">{t.passengerPayment.paymentMethod}</div>
        <RadioGroup value={method} onValueChange={setMethod} className="grid grid-cols-2 gap-2">
          {paymentMethods.map((m) => {
            const Icon = m.icon;
            return (
              <div key={m.id}>
                <Label
                  htmlFor={m.id}
                  className={`flex items-center gap-3 p-3 rounded-xl border cursor-pointer transition-all h-16 ${
                    method === m.id
                      ? 'border-primary bg-primary/5 shadow-sm ring-2 ring-primary/20'
                      : 'border-slate-200 hover:border-slate-300 bg-card'
                  }`}
                >
                  <RadioGroupItem value={m.id} id={m.id} className="sr-only" />
                  <div className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${m.color}`}>
                    <Icon className="size-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-foreground truncate">{m.label}</div>
                    {m.sublabel && (
                      <div className="text-[11px] text-muted-foreground truncate">{m.sublabel}</div>
                    )}
                  </div>
                  <div
                    className={`size-5 shrink-0 rounded-full border-2 flex items-center justify-center ${
                      method === m.id ? 'border-primary bg-primary' : 'border-slate-300'
                    }`}
                  >
                    {method === m.id && <Check className="size-3 text-white" />}
                  </div>
                </Label>
              </div>
            );
          })}
        </RadioGroup>
      </div>

      {/* Pay button */}
      <div className="px-4 mt-6">
        <AnimatePresence mode="wait">
          {paid ? (
            <motion.div
              key="paid"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex items-center justify-center gap-2 h-14 bg-emerald-500 text-white rounded-2xl font-semibold text-base shadow-lg shadow-emerald-500/30"
            >
              <Check className="size-5" />
               {t.passengerPayment.payNow} ✓
            </motion.div>
          ) : (
            <motion.button
              key="pay"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onClick={handlePay}
              disabled={paying}
              className="w-full h-14 bg-primary text-primary-foreground rounded-2xl font-semibold text-base shadow-lg shadow-primary/25 flex items-center justify-center gap-2 hover:bg-primary/90 active:scale-[0.98] transition-all disabled:opacity-70"
            >
              {paying ? (
                <>
                  <Loader2 className="size-5 animate-spin" />
                   {t.passengerPayment.paying}
                </>
              ) : (
                <>
                   {t.passengerPayment.payNow}
                  <span className="font-bold">HK${actualFare.toFixed(0)}</span>
                </>
              )}
            </motion.button>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
