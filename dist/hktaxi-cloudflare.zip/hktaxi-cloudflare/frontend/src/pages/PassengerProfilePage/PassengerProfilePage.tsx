import { User, Settings, MapPin, CreditCard, HelpCircle, ChevronRight, Star, Car, RotateCcw, ArrowRightLeft } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useState } from 'react';
import { useOrder } from '@/lib/order-context';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { Image } from '@/components/ui/image';
import { useI18n } from '@/lib/i18n';

const menuItems = [
  { icon: MapPin, label: '常用地址', value: '2 個地址' },
  { icon: CreditCard, label: '付款方式', value: '八達通' },
  { icon: Star, label: '我的優惠', value: '2 張優惠券' },
  { icon: HelpCircle, label: '幫助中心', value: '' },
  { icon: Settings, label: '設定', value: '' },
];

export default function PassengerProfilePage() {
  const { resetDemoData, setCurrentRole } = useOrder();
  const navigate = useNavigate();
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const { t } = useI18n();

  const handleSwitchToDriver = () => {
    setCurrentRole('driver');
    navigate('/driver');
  };

  const handleReset = () => {
    resetDemoData();
    toast.success('示範資料已重置');
    setShowResetConfirm(false);
  };
  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-slate-50 pb-24">
      {/* Profile header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground px-4 pt-10 pb-16 rounded-b-3xl">
        <div className="flex items-center gap-4">
          <Avatar className="size-16 border-2 border-white/30">
            <AvatarImage
              src="https://lf3-static.bytednsdoc.com/obj/eden-cn/ylcylz_fsph_ryhs/ljhwZthlaukjlkulzlp/feisuda/avatar/base/1.jpg"
              alt="用戶"
            />
            <AvatarFallback>陳</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h1 className="text-xl font-bold">陳先生</h1>
            <p className="text-sm opacity-80">普通會員</p>
          </div>
          <button className="size-9 rounded-full bg-white/20 flex items-center justify-center">
            <Settings className="size-5" />
          </button>
        </div>
      </div>

      {/* Stats card */}
      <div className="px-4 -mt-8">
        <Card className="shadow-lg">
          <CardContent className="p-4 grid grid-cols-3 divide-x divide-slate-100">
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">12</div>
              <div className="text-xs text-muted-foreground mt-0.5">{t.passengerProfile.totalTrips}</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-foreground">HK$856</div>
              <div className="text-xs text-muted-foreground mt-0.5">{t.passengerProfile.totalSpent}</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-500">4.8</div>
              <div className="text-xs text-muted-foreground mt-0.5">{t.passengerProfile.avgRating}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Menu */}
      <div className="px-4 mt-6">
        <Card className="shadow-sm overflow-hidden">
          {menuItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <button
                key={item.label}
                className={`w-full flex items-center gap-3 p-4 hover:bg-slate-50 transition-colors text-left ${
                  i !== 0 ? 'border-t border-slate-100' : ''
                }`}
              >
                <div className="size-9 rounded-full bg-primary/10 flex items-center justify-center">
                  <Icon className="size-4 text-primary" />
                </div>
                <span className="flex-1 text-sm font-medium text-foreground">
                  {item.label}
                </span>
                {item.value && (
                  <span className="text-xs text-muted-foreground">{item.value}</span>
                )}
                <ChevronRight className="size-4 text-slate-400" />
              </button>
            );
          })}
        </Card>
      </div>

      {/* 切換角色 */}
      <div className="px-4 mt-6">
        <button
          onClick={handleSwitchToDriver}
          className="w-full flex items-center justify-center gap-2 p-4 rounded-xl border border-border bg-card hover:bg-muted transition-colors text-foreground shadow-sm"
        >
          <ArrowRightLeft className="size-4 text-primary" />
          <span className="text-sm font-semibold">{t.passengerProfile.switchRole}</span>
        </button>
      </div>

      {/* Reset demo data */}
      <div className="px-4 mt-6">
        <AlertDialog open={showResetConfirm} onOpenChange={setShowResetConfirm}>
          <AlertDialogTrigger asChild>
            <button className="w-full flex items-center justify-center gap-2 p-4 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 transition-colors text-muted-foreground">
              <RotateCcw className="size-4" />
              <span className="text-sm font-medium">重置示範資料</span>
            </button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>重置示範資料？</AlertDialogTitle>
              <AlertDialogDescription>
                呢個操作會清除所有行程記錄、優惠券同訂單狀態，將 App 回復到初始示範狀態。
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>取消</AlertDialogCancel>
              <AlertDialogAction onClick={handleReset} className="bg-destructive hover:bg-destructive/90">
                確認重置
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>

      {/* Promo */}
      <div className="px-4 mt-6">
        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/50 rounded-2xl p-4 flex items-center gap-3">
          <div className="size-12 rounded-xl bg-amber-400 flex items-center justify-center text-white">
            <Car className="size-6" />
          </div>
          <div className="flex-1">
            <div className="text-sm font-semibold text-amber-900">邀請朋友賞你</div>
            <div className="text-xs text-amber-700">每邀請一位朋友，雙方各得 HK$20</div>
          </div>
          <ChevronRight className="size-4 text-amber-600" />
        </div>
      </div>

      {/* App info */}
      <div className="px-4 mt-8 mb-8 text-center">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Image
            src="https://aka.doubaocdn.com/s/1L23UMNBh7"
            alt="的道"
            className="size-6 rounded-full object-cover"
          />
          <span className="text-sm font-semibold text-foreground">的道</span>
        </div>
        <div className="text-xs text-muted-foreground">版本 1.0.0 · 示範版</div>
      </div>
    </div>
  );
}
