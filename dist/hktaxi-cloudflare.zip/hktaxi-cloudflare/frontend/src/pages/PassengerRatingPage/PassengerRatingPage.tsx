import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Navigation, Check, Star, ThumbsUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import StarRating from '@/components/StarRating';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';

const tags = ['車廂整潔', '駕駛穩陣', '態度友善', '路線熟悉', '車速適中', '按時到達'];

export default function PassengerRatingPage() {
  const { order, submitDriverRating, resetToIdle } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [rating, setRating] = useState(5);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!order) {
      navigate('/passenger');
      return;
    }
  }, [order, navigate]);

  if (!order || !order.driver) return null;

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = async () => {
    try {
      await submitDriverRating(rating);
    } catch {
      // ignore
    }
    setSubmitted(true);
    setTimeout(() => {
      resetToIdle();
      navigate('/passenger');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 via-white to-slate-50 flex flex-col">
      <div className="flex-1 px-4 pt-8 pb-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-6"
        >
          <div className="size-20 mx-auto rounded-full bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center mb-4 shadow-lg shadow-amber-500/30">
            <Star className="size-10 text-white fill-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">{t.passengerRating.title}</h1>
           <p className="text-sm text-muted-foreground mt-1">
             {t.passengerRating.subtitle}
           </p>
        </motion.div>

        {/* Driver card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="shadow-sm mb-4">
            <CardContent className="p-5 flex items-center gap-4">
              <Avatar className="size-16 border-2 border-amber-200">
                <AvatarImage src={order.driver.imageUrl} alt={order.driver.name} />
                <AvatarFallback>{order.driver.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <div className="font-semibold text-foreground text-lg">
                  {order.driver.name}
                </div>
                <div className="text-sm text-muted-foreground">
                  {order.driver.carModel} · {order.driver.plate}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <div className="flex items-center gap-1 text-amber-500">
                    <Star className="size-4 fill-amber-400" />
                    <span className="text-sm font-medium">{order.driver.rating}</span>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {order.carType === '6-seater' ? '6 人車' : '4 人車'}
                  </Badge>
                </div>
              </div>
              <div className="text-right">
                 <div className="text-xs text-muted-foreground">{t.passengerRating.fare}</div>
                <div className="text-xl font-bold text-primary">
                  HK${(order.actualFare ?? order.estimatedFare).toFixed(0)}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Route summary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="flex items-center gap-3 px-2 mb-6"
        >
          <div className="flex flex-col items-center">
            <MapPin className="size-4 text-emerald-500" />
            <div className="w-px h-6 bg-slate-200 my-0.5" />
            <Navigation className="size-4 text-red-500" />
          </div>
          <div className="flex-1 space-y-1.5 text-sm">
            <div className="font-medium text-foreground">{order.pickup.name}</div>
            <div className="font-medium text-foreground">{order.destination.name}</div>
          </div>
        </motion.div>

        {/* Star rating */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center mb-6"
        >
          <div className="text-sm font-medium text-foreground mb-3">
             {t.passengerRating.satisfaction}
          </div>
          <div className="flex justify-center">
            <StarRating value={rating} onChange={setRating} size={40} />
          </div>
          <div className="text-sm text-muted-foreground mt-2">
            {rating === 5 ? '非常滿意！' : rating >= 4 ? '滿意' : rating >= 3 ? '一般' : '不滿意'}
          </div>
        </motion.div>

        {/* Tags */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
        >
          <div className="text-sm font-medium text-foreground mb-3">{t.passengerRating.tags}</div>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => toggleTag(tag)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                  selectedTags.includes(tag)
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Submit */}
      <div className="px-4 pb-8 pt-2">
        {submitted ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-center justify-center gap-2 h-14 bg-emerald-500 text-white rounded-2xl font-semibold text-base shadow-lg shadow-emerald-500/30"
          >
            <Check className="size-5" />
             {t.passengerRating.thanks}
          </motion.div>
        ) : (
          <Button
            size="lg"
            className="w-full h-14 text-base font-semibold rounded-2xl shadow-lg shadow-primary/25"
            onClick={handleSubmit}
          >
            <ThumbsUp className="size-5 mr-2" />
             {t.passengerRating.submit}
          </Button>
        )}
      </div>
    </div>
  );
}
