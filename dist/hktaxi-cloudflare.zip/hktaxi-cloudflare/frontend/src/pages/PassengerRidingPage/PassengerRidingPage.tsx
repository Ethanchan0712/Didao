import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Phone, MessageCircle, Star, Navigation, MapPin, Clock, PhoneOff } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import AMapView from '@/components/AMapView';
import ChatSheet from '@/components/ChatSheet';
import StarRating from '@/components/StarRating';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';

export default function PassengerRidingPage() {
  const { order } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [showChat, setShowChat] = useState(false);
  const [showCall, setShowCall] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const callTimerRef = useState<number | null>(null);

  useEffect(() => {
    if (!order) {
      navigate('/passenger');
      return;
    }
    if (order.status === 'completed' || order.status === 'paid') {
      navigate('/passenger/payment');
      return;
    }
    if (order.status === 'searching') {
      navigate('/passenger/waiting');
      return;
    }
  }, [order, navigate]);

  if (!order || !order.driver) return null;

  const isPickedUp = order.status === 'picked_up';
  const statusLabel = isPickedUp ? t.passengerRiding.headingToDest : t.passengerRiding.driverOnTheWay;
  const statusColor = isPickedUp ? 'text-blue-600 bg-blue-50' : 'text-emerald-600 bg-emerald-50';
  const eta = order.etaMinutes ?? (isPickedUp ? 8 : 3);

  const handleCall = () => {
    setShowCall(true);
    setCallDuration(0);
    toast.info(`正在致電 ${order.driver!.name}...`);
  };

  const handleHangUp = () => {
    setShowCall(false);
    toast.success('通話已結束');
  };

  const formatCallDuration = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m.toString().padStart(2, '0')}:${sec.toString().padStart(2, '0')}`;
  };

  const driverLat = order.driver.currentLat;
  const driverLng = order.driver.currentLng;

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-slate-50 pb-6">
      {/* Header status */}
      <div className="px-4 pt-4 pb-2">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2"
        >
          <Badge className={`${statusColor} border-0 text-sm font-medium px-3 py-1`}>
            <Clock className="size-3.5 mr-1" />
            {statusLabel}
          </Badge>
          <span className="text-xs text-muted-foreground">
             預計 {eta} {t.common.minute}
          </span>
        </motion.div>
      </div>

      {/* Map */}
      <div className="px-4 pt-2">
        <AMapView
          pickupName={isPickedUp ? undefined : order.pickup.name}
          destinationName={order.destination.name}
          driverLat={driverLat}
          driverLng={driverLng}
          passengerLat={order.pickup.lat}
          passengerLng={order.pickup.lng}
          showRoute
          height="h-72"
        />
      </div>

      {/* ETA big display */}
      <div className="px-4 mt-4">
        <Card className="bg-gradient-to-br from-primary to-primary/90 text-primary-foreground shadow-lg shadow-primary/20 border-0">
          <CardContent className="p-5">
            <div className="flex items-center justify-between">
              <div>
                 <div className="text-xs opacity-80 mb-1">{t.passengerRiding.eta}</div>
                <div className="text-4xl font-black tabular-nums">
                   {eta}<span className="text-lg font-medium ml-1">{t.common.minute}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs opacity-80 mb-1">{t.passengerRiding.remainingDist}</div>
                <div className="text-2xl font-bold">
                  {(eta * 0.4).toFixed(1)}<span className="text-sm font-medium ml-1">km</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Driver info card */}
      <div className="px-4 mt-4">
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Avatar className="size-14 border-2 border-primary/20">
                <AvatarImage src={order.driver.imageUrl} alt={order.driver.name} />
                <AvatarFallback>{order.driver.name[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-foreground">{order.driver.name}</span>
                  <div className="flex items-center gap-0.5 text-amber-500">
                    <Star className="size-3 fill-amber-400" />
                    <span className="text-xs font-medium">{order.driver.rating}</span>
                  </div>
                </div>
                <div className="text-sm text-muted-foreground mt-0.5">
                  {order.driver.carModel}
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-xs font-mono">
                    {order.driver.plate}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {order.carType === '6-seater' ? '6 人車' : '4 人車'}
                  </Badge>
                  {order.tip > 0 && (
                    <Badge variant="secondary" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                      貼士 HK${order.tip}
                    </Badge>
                  )}
                </div>
              </div>
               <div className="flex gap-2">
                 <button
                   onClick={handleCall}
                   className="size-10 rounded-full bg-green-50 hover:bg-green-100 flex items-center justify-center transition-colors"
                   aria-label="致電司機"
                 >
                   <Phone className="size-4 text-green-600" />
                 </button>
                 <button
                   onClick={() => setShowChat(true)}
                   className="size-10 rounded-full bg-primary/10 hover:bg-primary/20 flex items-center justify-center transition-colors relative"
                   aria-label="訊息"
                 >
                   <MessageCircle className="size-4 text-primary" />
                   {(order.messages?.length ?? 0) > 0 && (
                     <span className="absolute -top-1 -right-1 size-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                       {order.messages.length}
                     </span>
                   )}
                 </button>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Route summary */}
      <div className="px-4 mt-4">
        <Card className="shadow-sm">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-center">
                <MapPin className="size-4 text-emerald-500" />
                <div className="w-px h-8 bg-slate-200 my-1" />
                <Navigation className="size-4 text-red-500" />
              </div>
              <div className="flex-1 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    {isPickedUp ? '已上車 · ' : ''}{order.pickup.name}
                  </span>
                  {!isPickedUp && (
                    <Badge variant="secondary" className="text-xs">上車點</Badge>
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    {order.destination.name}
                  </span>
                  <Badge variant="secondary" className="text-xs">目的地</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 聊天彈層 */}
      <ChatSheet
        open={showChat}
        onClose={() => setShowChat(false)}
        role="passenger"
        otherName={order.driver.name}
        otherAvatar={order.driver.imageUrl}
      />

      {/* 通話中 Dialog */}
      {showCall && (
        <div className="fixed inset-0 z-[60] bg-black/80 backdrop-blur-md flex items-center justify-center">
          <div className="text-center text-white">
            <div className="size-24 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-5 animate-pulse">
              <div className="size-16 rounded-full bg-green-500/30 flex items-center justify-center">
                <Phone className="size-7 text-green-400" />
              </div>
            </div>
            <div className="text-lg font-semibold mb-1">{order.driver.name}</div>
            <div className="text-sm text-white/60 mb-1">
              {callDuration === 0 ? '正在呼叫...' : '通話中'}
            </div>
            {callDuration > 0 && (
              <div className="text-xs text-white/50 tabular-nums mb-6">
                {formatCallDuration(callDuration)}
              </div>
            )}
            {callDuration === 0 && <div className="h-6 mb-6" />}
            <button
              onClick={handleHangUp}
              className="size-14 rounded-full bg-red-500 flex items-center justify-center mx-auto hover:bg-red-600 transition-colors shadow-lg shadow-red-500/30"
              aria-label="掛線"
            >
              <PhoneOff className="size-6 text-white" />
            </button>
            <div className="text-xs text-white/40 mt-2">掛線</div>
          </div>
        </div>
      )}
    </div>
  );
}
