import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { X, MapPin, Clock, Loader2, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AMapView from '@/components/AMapView';
import ChatSheet from '@/components/ChatSheet';
import { useOrder } from '@/lib/order-context';
import { useI18n } from '@/lib/i18n';
import { toast } from 'sonner';

export default function PassengerWaitingPage() {
  const { order, cancelOrder } = useOrder();
  const navigate = useNavigate();
  const { t } = useI18n();
  const [showChat, setShowChat] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    if (!order) {
      navigate('/passenger');
      return;
    }
    if (order.status === 'accepted') {
      navigate('/passenger/riding');
      return;
    }
    if (order.status === 'searching') {
      // keep waiting
      return;
    }
    // other unexpected states
    if (order.status === 'picked_up' || order.status === 'completed') {
      navigate('/passenger/riding');
    }
  }, [order, navigate]);

  if (!order) return null;

  const handleCancel = async () => {
    setCancelling(true);
    try {
      await cancelOrder();
      toast.success('已取消叫車');
      navigate('/passenger');
    } catch {
      toast.error('取消失敗，請重試');
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-white to-slate-50 pb-8">
      {/* Map */}
      <div className="relative px-4 pt-6">
        <AMapView
          pickupName={order.pickup.name}
          destinationName={order.destination.name}
          passengerLat={order.pickup.lat}
          passengerLng={order.pickup.lng}
          showRoute
          height="h-64"
        />

        {/* Searching overlay */}
        <div className="absolute inset-4 flex items-center justify-center bg-black/20 backdrop-blur-[2px] rounded-2xl">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white/95 backdrop-blur rounded-2xl p-6 shadow-xl text-center max-w-[280px]"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              className="mx-auto mb-3"
            >
              <Loader2 className="size-10 text-primary" />
            </motion.div>
             <div className="text-base font-semibold text-foreground mb-1">
                {t.passengerWaiting.title}
              </div>
              <div className="text-sm text-muted-foreground">
                {t.passengerWaiting.subtitle}
              </div>
          </motion.div>
        </div>
      </div>

      {/* Order details */}
      <div className="px-4 mt-4">
        <Card className="shadow-sm">
          <CardContent className="p-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="flex flex-col items-center">
                <div className="size-3 rounded-full bg-emerald-500" />
                <div className="w-px h-8 bg-slate-300" />
                <div className="size-3 rounded-full bg-red-500" />
              </div>
              <div className="flex-1 space-y-5">
                <div>
                   <div className="text-xs text-emerald-600 font-medium">{t.passengerWaiting.pickup}</div>
                  <div className="text-sm font-semibold text-foreground">
                    {order.pickup.name}
                  </div>
                </div>
                <div>
                   <div className="text-xs text-red-600 font-medium">{t.passengerWaiting.destination}</div>
                  <div className="text-sm font-semibold text-foreground">
                    {order.destination.name}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">
                  {order.carType === '6-seater' ? '6 人車' : '4 人車'}
                </Badge>
                {order.tip > 0 && (
                  <Badge variant="secondary" className="text-xs bg-amber-50 text-amber-700 border-amber-200">
                    貼士 HK${order.tip}
                  </Badge>
                )}
                <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <Clock className="size-4" />
                   預計 {Math.ceil(order.distanceKm ?? 3)} {t.common.minute}
                </div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-primary">
                  HK${order.estimatedFare.toFixed(0)}
                </div>
                {order.tip > 0 && (
                   <div className="text-[10px] text-amber-600">{t.passengerHome.inclTip}</div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tips */}
      <div className="px-4 mt-4">
        <div className="bg-amber-50 border border-amber-200/60 rounded-xl p-3 flex items-start gap-2">
          <div className="size-5 rounded-full bg-amber-400 text-white flex items-center justify-center shrink-0 text-xs font-bold mt-0.5">
            !
          </div>
          <div className="text-xs text-amber-800 leading-relaxed">
            叫車成功！請前往 <strong>{order.pickup.name}</strong> 上車點等候。
            <br />
            你可以喺另一個視窗打開「司機端」睇到呢個訂單㗎。
          </div>
        </div>
      </div>

      {/* Cancel button */}
      <div className="px-4 mt-6 flex gap-3">
        <Button
          variant="outline"
          size="lg"
          className="flex-1 h-12 rounded-2xl"
          onClick={() => setShowChat(true)}
        >
          <MessageCircle className="size-4 mr-2" />
          聯絡
        </Button>
        <Button
          variant="outline"
          size="lg"
          className="flex-1 h-12 rounded-2xl border-red-200 text-red-600 hover:bg-red-50"
          onClick={handleCancel}
          disabled={cancelling}
        >
          <X className="size-4 mr-2" />
           {cancelling ? '取消中...' : t.passengerWaiting.cancel}
        </Button>
      </div>

      {/* 聊天彈層 */}
      <ChatSheet
        open={showChat}
        onClose={() => setShowChat(false)}
        role="passenger"
        otherName="司機"
      />
    </div>
  );
}
