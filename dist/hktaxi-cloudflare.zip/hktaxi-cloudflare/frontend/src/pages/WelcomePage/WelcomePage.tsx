import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Car, User, MapPin, Shield, Zap, Settings, Globe, X, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { useOrder } from '@/lib/order-context';
import { useTheme } from '@/lib/theme-context';
import { useI18n } from '@/lib/i18n';
import { Image } from '@/components/ui/image';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  passengerRegister,
  passengerLogin,
  driverRegister,
  driverLogin,
} from '@/lib/api';

const LOGO_URL = 'https://aka.doubaocdn.com/s/1L23UMNBh7';

type AuthRole = 'passenger' | 'driver';
type AuthMode = 'login' | 'register';

export default function WelcomePage() {
  const navigate = useNavigate();
  const { login: setAuthLogin, setCurrentRole } = useOrder();
  const { theme, setTheme, primaryColor } = useTheme();
  const { t, lang, setLang } = useI18n();
  const [logoLoaded, setLogoLoaded] = useState(false);
  const [langSheetOpen, setLangSheetOpen] = useState(false);
  const [authRole, setAuthRole] = useState<AuthRole>('passenger');
  const [authMode, setAuthMode] = useState<AuthMode>('login');
  const [authSheetOpen, setAuthSheetOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // form states
  const [username, setUsername] = useState('');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [plate, setPlate] = useState('');
  const [carModel, setCarModel] = useState('');
  const [driverLicense, setDriverLicense] = useState('');

  const resetForm = () => {
    setUsername('');
    setPhone('');
    setName('');
    setPassword('');
    setPlate('');
    setCarModel('');
    setDriverLicense('');
  };

  const openPassengerAuth = () => {
    setAuthRole('passenger');
    setAuthMode('login');
    resetForm();
    setAuthSheetOpen(true);
  };

  const openDriverAuth = () => {
    setAuthRole('driver');
    setAuthMode('login');
    resetForm();
    setAuthSheetOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    setSubmitting(true);
    try {
      if (authRole === 'passenger' && authMode === 'login') {
        const data = await passengerLogin({ username, password });
        setAuthLogin('passenger', data.user, data.token);
        setCurrentRole('passenger');
        toast.success('登入成功');
        setAuthSheetOpen(false);
        navigate('/passenger');
      } else if (authRole === 'passenger' && authMode === 'register') {
        if (!username || !password) {
          toast.error('請輸入帳號同密碼');
          return;
        }
        const data = await passengerRegister({ username, phone, password, name });
        setAuthLogin('passenger', data.user, data.token);
        setCurrentRole('passenger');
        toast.success('註冊成功，歡迎使用 的道！');
        setAuthSheetOpen(false);
        navigate('/passenger');
      } else if (authRole === 'driver' && authMode === 'login') {
        const data = await driverLogin({ username, password });
        setAuthLogin('driver', data.user, data.token);
        setCurrentRole('driver');
        toast.success('登入成功');
        setAuthSheetOpen(false);
        if (data.user.status === 'approved') {
          navigate('/driver');
        } else {
          navigate('/driver/verify');
        }
      } else if (authRole === 'driver' && authMode === 'register') {
        if (!username || !password) {
          toast.error('請輸入帳號同密碼');
          return;
        }
        const data = await driverRegister({
          username, phone, password, name, plate, carModel, driverLicense,
        });
        setAuthLogin('driver', data.user, data.token);
        setCurrentRole('driver');
        toast.success('註冊成功，請等待管理員審批');
        setAuthSheetOpen(false);
        navigate('/driver/verify');
      }
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || '操作失敗，請重試';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-background text-foreground flex flex-col relative overflow-hidden">
      {/* 背景裝飾 - 柔和光斑 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div
          className="absolute top-16 left-8 size-72 rounded-full blur-3xl"
          style={{ backgroundColor: primaryColor, opacity: 0.08 }}
        />
        <div className="absolute bottom-48 right-6 size-80 rounded-full bg-amber-300/20 blur-3xl" />
        <div className="absolute top-1/3 right-1/4 size-40 rounded-full bg-emerald-300/10 blur-2xl" />
      </div>

      {/* 頂部：主題切換 + 語言 */}
      <div className="relative z-10 pt-4 px-4 flex items-center gap-2">
        <div className="flex-1 flex items-center justify-center gap-2">
          <button
            onClick={() => setTheme('red')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              theme === 'red'
                ? 'bg-red-500 text-white shadow-lg shadow-red-500/25'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            市區 · 紅
          </button>
          <button
            onClick={() => setTheme('green')}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all ${
              theme === 'green'
                ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/25'
                : 'bg-muted text-muted-foreground hover:text-foreground'
            }`}
          >
            新界 · 綠
          </button>
        </div>
        <Sheet open={langSheetOpen} onOpenChange={setLangSheetOpen}>
          <SheetTrigger asChild>
            <button className="size-9 rounded-full bg-card border border-border flex items-center justify-center hover:bg-muted transition-colors shrink-0 shadow-sm">
              <Globe className="size-4 text-muted-foreground" />
            </button>
          </SheetTrigger>
          <SheetContent side="bottom" className="rounded-t-3xl pb-8 bg-background text-foreground border-t border-border">
            <SheetHeader>
              <SheetTitle className="text-foreground">{t.language.title}</SheetTitle>
            </SheetHeader>
            <div className="px-5 pt-4 space-y-2">
              {(['zh-Hant', 'en', 'ja'] as const).map((l) => (
                <button
                  key={l}
                  onClick={() => {
                    setLang(l);
                    setLangSheetOpen(false);
                  }}
                  className={`w-full flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                    lang === l
                      ? 'border-primary bg-primary/5'
                      : 'border-border hover:border-muted-foreground/30'
                  }`}
                >
                  <span className={`font-medium ${lang === l ? 'text-primary' : 'text-foreground'}`}>
                    {t.language[l === 'zh-Hant' ? 'zhHant' : l]}
                  </span>
                  {lang === l && (
                    <div className="size-5 rounded-full bg-primary flex items-center justify-center">
                      <svg className="size-3 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </button>
              ))}
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* 主內容 */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 pt-6 pb-8">
        {/* Logo */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="mb-6"
        >
          <div
            className="relative size-32 md:size-40 rounded-full overflow-hidden shadow-xl ring-4 ring-white"
            style={{ boxShadow: `0 20px 50px ${primaryColor}25` }}
          >
            {!logoLoaded && (
              <div className="absolute inset-0 bg-muted animate-pulse flex items-center justify-center">
                <Car className="size-12 text-muted-foreground/40" />
              </div>
            )}
            <Image
              src={LOGO_URL}
              alt="Logo"
              className={`w-full h-full object-cover transition-opacity duration-500 ${
                logoLoaded ? 'opacity-100' : 'opacity-0'
              }`}
              onLoad={() => setLogoLoaded(true)}
            />
          </div>
        </motion.div>

        {/* 品牌名 */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, ease: 'easeOut' }}
          className="text-center mb-2"
        >
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-foreground">
            的<span style={{ color: primaryColor }}>道</span>
          </h1>
        </motion.div>

        {/* 簡介 */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.35 }}
          className="text-muted-foreground text-sm md:text-base mb-10 text-center max-w-xs"
        >
          {t.welcome.tagline}
        </motion.p>

        {/* 特色亮點 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid grid-cols-3 gap-4 mb-12 w-full max-w-sm"
        >
          {[
            { icon: Zap, label: t.welcome.features.instant },
            { icon: Shield, label: t.welcome.features.safe },
            { icon: MapPin, label: t.welcome.features.track },
          ].map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.label}
                className="flex flex-col items-center gap-2"
              >
                <div className="size-12 rounded-2xl bg-card border border-border flex items-center justify-center shadow-sm">
                  <Icon className="size-5" style={{ color: primaryColor }} />
                </div>
                <span className="text-xs text-muted-foreground text-center">{item.label}</span>
              </div>
            );
          })}
        </motion.div>

        {/* 入口按鈕 */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.65 }}
          className="w-full max-w-sm space-y-3"
        >
          <button
            onClick={openPassengerAuth}
            className="w-full h-14 rounded-2xl text-primary-foreground font-bold text-base shadow-lg hover:scale-[1.02] active:scale-[0.98] transition-transform flex items-center justify-center gap-2 bg-primary"
            style={{ boxShadow: `0 10px 30px ${primaryColor}40` }}
          >
            <User className="size-5" />
            {t.welcome.startPassenger}
            <ArrowRight className="size-4 ml-1 opacity-80" />
          </button>

          <button
            onClick={openDriverAuth}
            className="w-full h-14 rounded-2xl bg-card border border-border text-foreground font-semibold text-base hover:bg-muted active:bg-accent transition-colors flex items-center justify-center gap-2 shadow-sm"
          >
            <Car className="size-5" style={{ color: primaryColor }} />
            {t.welcome.startDriver}
            <ArrowRight className="size-4 ml-1 opacity-60" />
          </button>

          <button
            onClick={() => navigate('/admin/login')}
            className="w-full h-11 rounded-2xl text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-all flex items-center justify-center gap-2"
          >
            <Settings className="size-4" />
            {t.welcome.adminEntry}
          </button>
        </motion.div>
      </div>

      {/* 底部版權 */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6, delay: 0.9 }}
        className="relative z-10 text-center pb-6 text-xs text-muted-foreground"
      >
        {t.welcome.copyright}
      </motion.div>

      {/* 登入/註冊 Sheet */}
      <Sheet open={authSheetOpen} onOpenChange={setAuthSheetOpen}>
        <SheetContent side="bottom" className="rounded-t-3xl bg-background text-foreground border-t border-border max-h-[90vh] overflow-y-auto">
          <SheetHeader className="mb-2">
            <SheetTitle className="text-foreground text-xl">
              {authRole === 'passenger' ? '乘客登入 / 註冊' : '司機登入 / 註冊'}
            </SheetTitle>
          </SheetHeader>

          <div className="px-5 py-2">
            {/* 角色切換（乘客 / 司機） */}
            <Tabs
              value={authRole}
              onValueChange={(v) => { setAuthRole(v as AuthRole); setAuthMode('login'); resetForm(); }}
              className="mb-5"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="passenger">乘客</TabsTrigger>
                <TabsTrigger value="driver">司機</TabsTrigger>
              </TabsList>
            </Tabs>

            {/* 模式切換（登入 / 註冊） */}
            <Tabs value={authMode} onValueChange={(v) => setAuthMode(v as AuthMode)} className="mb-5">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">登入</TabsTrigger>
                <TabsTrigger value="register">註冊</TabsTrigger>
              </TabsList>
            </Tabs>

            <form onSubmit={handleSubmit} className="space-y-4">
              {authMode === 'register' && (
                <div className="space-y-2">
                  <Label htmlFor="name">姓名 / 暱稱</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="輸入姓名"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="username">帳號</Label>
                <Input
                  id="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="輸入帳號"
                  autoComplete="username"
                />
              </div>

              {authMode === 'register' && (
                <div className="space-y-2">
                  <Label htmlFor="phone">電話號碼</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="輸入電話號碼"
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="password">密碼</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="至少 6 位"
                  autoComplete="current-password"
                />
              </div>

              {authRole === 'driver' && authMode === 'register' && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="plate">車牌號碼</Label>
                    <Input
                      id="plate"
                      value={plate}
                      onChange={(e) => setPlate(e.target.value)}
                      placeholder="例如：AB 1234"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="carModel">車型</Label>
                    <Input
                      id="carModel"
                      value={carModel}
                      onChange={(e) => setCarModel(e.target.value)}
                      placeholder="例如：豐田 Crown"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="license">司機證編號</Label>
                    <Input
                      id="license"
                      value={driverLicense}
                      onChange={(e) => setDriverLicense(e.target.value)}
                      placeholder="輸入司機證編號"
                    />
                  </div>
                </>
              )}

              <Button
                type="submit"
                className="w-full h-12 rounded-2xl text-base font-semibold mt-2"
                disabled={submitting}
              >
                {submitting ? '處理中...' : authMode === 'login' ? '登入' : '註冊'}
              </Button>

              {authMode === 'login' && (
                <p className="text-xs text-center text-muted-foreground pt-1">
                  未有帳號？
                  <button
                    type="button"
                    onClick={() => setAuthMode('register')}
                    className="text-primary font-medium ml-1 hover:underline"
                  >
                    立即註冊
                  </button>
                </p>
              )}
              {authMode === 'register' && (
                <p className="text-xs text-center text-muted-foreground pt-1">
                  已有帳號？
                  <button
                    type="button"
                    onClick={() => setAuthMode('login')}
                    className="text-primary font-medium ml-1 hover:underline"
                  >
                    立即登入
                  </button>
                </p>
              )}
            </form>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
