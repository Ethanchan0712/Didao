import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { jwt } from 'hono/jwt';
import { logger } from 'hono/logger';

import authRoutes from './routes/auth';
import orderRoutes from './routes/orders';
import chatRoutes from './routes/chat';
import adminRoutes from './routes/admin';

export type Env = {
  DB: D1Database;
  JWT_SECRET: string;
  FRONTEND_ORIGIN: string;
};

const app = new Hono<Env>();

// Middleware
app.use('*', logger());
app.use('*', async (c, next) => {
  const origin = c.env.FRONTEND_ORIGIN || '*';
  return cors({
    origin: origin === '*' ? true : origin,
    allowHeaders: ['Authorization', 'Content-Type'],
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
  })(c, next);
});

// Health check
app.get('/api/health', (c) => {
  return c.json({ ok: true, ts: Date.now() });
});

// API routes
app.route('/api/auth', authRoutes);
app.route('/api/orders', orderRoutes);
app.route('/api/chat', chatRoutes);
app.route('/api/admin', adminRoutes);

// 404 fallback
app.all('*', (c) => {
  return c.json({ error: 'Not Found' }, 404);
});

export default app;
