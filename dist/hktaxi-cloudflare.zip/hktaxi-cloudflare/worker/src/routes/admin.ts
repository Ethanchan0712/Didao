import { Hono } from 'hono';

import type { Env } from '../index';

const router = new Hono<Env>();

// ========== 統計 ==========
router.get('/stats', async (c) => {
  const role = c.get('jwtPayload')?.role;
  if (role !== 'admin') return c.json({ error: '未登入' }, 401);

  const pending = (await c.env.DB.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'pending'").first()) as any;
  const approved = (await c.env.DB.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'approved'").first()) as any;
  const rejected = (await c.env.DB.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'rejected'").first()) as any;
  const totalOrders = (await c.env.DB.prepare('SELECT COUNT(*) as c FROM orders').first()) as any;
  const todayOrders = (await c.env.DB.prepare('SELECT COUNT(*) as c FROM orders WHERE created_at > ?1').bind(Date.now() - 86400000).first()) as any;
  const totalRevenue = (await c.env.DB.prepare("SELECT COALESCE(SUM(actual_fare), 0) as s FROM orders WHERE status IN ('paid','finished')").first()) as any;
  const passengerCount = (await c.env.DB.prepare('SELECT COUNT(*) as c FROM passengers').first()) as any;

  return c.json({
    pending: pending?.c || 0,
    approved: approved?.c || 0,
    rejected: rejected?.c || 0,
    totalOrders: totalOrders?.c || 0,
    todayOrders: todayOrders?.c || 0,
    totalRevenue: totalRevenue?.s || 0,
    passengerCount: passengerCount?.c || 0,
  });
});

// ========== 司機申請列表 ==========
router.get('/drivers', async (c) => {
  const role = c.get('jwtPayload')?.role;
  if (role !== 'admin') return c.json({ error: '未登入' }, 401);

  const { status = 'pending' } = c.req.query();
  let results;
  if (status === 'all') {
    const stmt = await c.env.DB.prepare('SELECT * FROM drivers ORDER BY created_at DESC LIMIT 100');
    results = (await stmt.all()).results;
  } else {
    const stmt = await c.env.DB.prepare('SELECT * FROM drivers WHERE status = ?1 ORDER BY created_at DESC LIMIT 100').bind(status);
    results = (await stmt.all()).results;
  }
  return c.json({ drivers: results });
});

// ========== 批准司機 ==========
router.post('/drivers/:id/approve', async (c) => {
  const role = c.get('jwtPayload')?.role;
  if (role !== 'admin') return c.json({ error: '未登入' }, 401);

  const { id } = c.req.param();
  const driver = await c.env.DB.prepare('SELECT * FROM drivers WHERE id = ?1').bind(id).first();
  if (!driver) return c.json({ error: '司機唔存在' }, 404);

  await c.env.DB
    .prepare("UPDATE drivers SET status = 'approved', approved_at = ?1 WHERE id = ?2")
    .bind(Date.now(), id)
    .run();

  const updated = await c.env.DB.prepare('SELECT * FROM drivers WHERE id = ?1').bind(id).first();
  return c.json({ driver: updated });
});

// ========== 拒絕司機 ==========
router.post('/drivers/:id/reject', async (c) => {
  const role = c.get('jwtPayload')?.role;
  if (role !== 'admin') return c.json({ error: '未登入' }, 401);

  const { id } = c.req.param();
  const body = await c.req.json();
  const { reason } = body;

  const driver = await c.env.DB.prepare('SELECT * FROM drivers WHERE id = ?1').bind(id).first();
  if (!driver) return c.json({ error: '司機唔存在' }, 404);

  await c.env.DB
    .prepare("UPDATE drivers SET status = 'rejected', reject_reason = ?1 WHERE id = ?2")
    .bind(reason || '', id)
    .run();

  const updated = await c.env.DB.prepare('SELECT * FROM drivers WHERE id = ?1').bind(id).first();
  return c.json({ driver: updated });
});

// ========== 訂單列表 ==========
router.get('/orders', async (c) => {
  const role = c.get('jwtPayload')?.role;
  if (role !== 'admin') return c.json({ error: '未登入' }, 401);

  const { status } = c.req.query();
  let query = `
    SELECT o.*,
           p.name as passenger_name, p.phone as passenger_phone,
           d.name as driver_name, d.plate as driver_plate
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
  `;
  const params: any[] = [];

  if (status && status !== 'all') {
    query += ' WHERE o.status = ?1';
    params.push(status);
  }
  query += ' ORDER BY o.created_at DESC LIMIT 100';

  const stmt = c.env.DB.prepare(query);
  const result = params.length > 0 ? await stmt.bind(...params).all() : await stmt.all();

  return c.json({ orders: result.results });
});

export default router;
