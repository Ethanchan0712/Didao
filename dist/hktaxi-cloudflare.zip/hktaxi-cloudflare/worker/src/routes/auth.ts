import { Hono } from 'hono';
import bcrypt from 'bcryptjs';
import { sign } from 'hono/jwt';

import type { Env } from '../index';

const router = new Hono<Env>();

function genId(prefix: string): string {
  return (
    prefix +
    '_' +
    Math.random().toString(36).slice(2, 10) +
    Date.now().toString(36).slice(-4)
  );
}

async function signToken(payload: { id: string; role: string }, secret: string) {
  return sign({ ...payload, exp: Math.floor(Date.now() / 1000) + 30 * 24 * 60 * 60 }, secret);
}

// ========== 乘客註冊 ==========
router.post('/passenger/register', async (c) => {
  const body = await c.req.json();
  const { username, phone, password, name } = body;

  if (!username || !password) {
    return c.json({ error: '請輸入帳號同密碼' }, 400);
  }
  if (password.length < 6) {
    return c.json({ error: '密碼至少 6 位' }, 400);
  }

  // Check existing
  const existing = await c.env.DB
    .prepare('SELECT id FROM passengers WHERE username = ?1 OR phone = ?2')
    .bind(username, phone || '')
    .first();

  if (existing) {
    return c.json({ error: '帳號或電話已經註冊咗' }, 400);
  }

  const id = genId('p');
  const hash = bcrypt.hashSync(password, 10);
  const now = Date.now();

  await c.env.DB
    .prepare(
      `INSERT INTO passengers (id, username, phone, password, name, created_at)
       VALUES (?1, ?2, ?3, ?4, ?5, ?6)`
    )
    .bind(id, username, phone || '', hash, name || username, now)
    .run();

  const user = await c.env.DB
    .prepare(
      'SELECT id, username, phone, name, rating, rating_count FROM passengers WHERE id = ?1'
    )
    .bind(id)
    .first();

  const token = await signToken({ id, role: 'passenger' }, c.env.JWT_SECRET);

  return c.json({ user, token });
});

// ========== 乘客登入 ==========
router.post('/passenger/login', async (c) => {
  const body = await c.req.json();
  const { username, password } = body;

  if (!username || !password) {
    return c.json({ error: '請輸入帳號同密碼' }, 400);
  }

  const row: any = await c.env.DB
    .prepare('SELECT * FROM passengers WHERE username = ?1 OR phone = ?2')
    .bind(username, username)
    .first();

  if (!row) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const user = {
    id: row.id,
    username: row.username,
    phone: row.phone,
    name: row.name,
    avatar: row.avatar,
    rating: row.rating,
    rating_count: row.rating_count,
  };

  const token = await signToken({ id: row.id, role: 'passenger' }, c.env.JWT_SECRET);

  return c.json({ user, token });
});

// ========== 乘客資料 ==========
router.get('/passenger/me', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const user = await c.env.DB
    .prepare(
      'SELECT id, username, phone, name, avatar, rating, rating_count FROM passengers WHERE id = ?1'
    )
    .bind(userId)
    .first();

  return c.json({ user });
});

// ========== 司機註冊 ==========
router.post('/driver/register', async (c) => {
  const body = await c.req.json();
  const { username, phone, password, name, plate, carModel, driverLicense } = body;

  if (!username || !password) {
    return c.json({ error: '請輸入帳號同密碼' }, 400);
  }
  if (password.length < 6) {
    return c.json({ error: '密碼至少 6 位' }, 400);
  }

  const existing = await c.env.DB
    .prepare('SELECT id FROM drivers WHERE username = ?1 OR phone = ?2')
    .bind(username, phone || '')
    .first();

  if (existing) {
    return c.json({ error: '帳號或電話已經註冊咗' }, 400);
  }

  const id = genId('d');
  const hash = bcrypt.hashSync(password, 10);
  const now = Date.now();

  await c.env.DB
    .prepare(
      `INSERT INTO drivers (id, username, phone, password, name, plate, car_model, driver_license, status, created_at)
       VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, 'pending', ?9)`
    )
    .bind(
      id,
      username,
      phone || '',
      hash,
      name || username,
      plate || '',
      carModel || '',
      driverLicense || '',
      now
    )
    .run();

  const user = await c.env.DB
    .prepare(
      `SELECT id, username, phone, name, plate, car_model, driver_license, status, rating, rating_count
       FROM drivers WHERE id = ?1`
    )
    .bind(id)
    .first();

  const token = await signToken({ id, role: 'driver' }, c.env.JWT_SECRET);

  return c.json({ user, token });
});

// ========== 司機登入 ==========
router.post('/driver/login', async (c) => {
  const body = await c.req.json();
  const { username, password } = body;

  if (!username || !password) {
    return c.json({ error: '請輸入帳號同密碼' }, 400);
  }

  const row: any = await c.env.DB
    .prepare('SELECT * FROM drivers WHERE username = ?1 OR phone = ?2')
    .bind(username, username)
    .first();

  if (!row) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const user = {
    id: row.id,
    username: row.username,
    phone: row.phone,
    name: row.name,
    avatar: row.avatar,
    plate: row.plate,
    car_model: row.car_model,
    driver_license: row.driver_license,
    status: row.status,
    online: !!row.online,
    rating: row.rating,
    rating_count: row.rating_count,
    current_lat: row.current_lat,
    current_lng: row.current_lng,
  };

  const token = await signToken({ id: row.id, role: 'driver' }, c.env.JWT_SECRET);

  return c.json({ user, token });
});

// ========== 司機資料 ==========
router.get('/driver/me', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const user = await c.env.DB
    .prepare(
      'SELECT id, username, phone, name, avatar, plate, car_model, driver_license, status, online, rating, rating_count, current_lat, current_lng FROM drivers WHERE id = ?1'
    )
    .bind(userId)
    .first();

  return c.json({ user });
});

// ========== 管理員登入 ==========
router.post('/admin/login', async (c) => {
  const body = await c.req.json();
  const { username, password } = body;

  if (!username || !password) {
    return c.json({ error: '請輸入帳號同密碼' }, 400);
  }

  const row: any = await c.env.DB
    .prepare('SELECT * FROM admins WHERE username = ?1')
    .bind(username)
    .first();

  if (!row) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return c.json({ error: '帳號或密碼錯誤' }, 401);
  }

  const user = { id: row.id, username: row.username };
  const token = await signToken({ id: row.id, role: 'admin' }, c.env.JWT_SECRET);

  return c.json({ user, token });
});

export default router;
