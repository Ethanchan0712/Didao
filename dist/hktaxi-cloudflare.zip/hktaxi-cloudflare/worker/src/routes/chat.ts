import { Hono } from 'hono';

import type { Env } from '../index';

const router = new Hono<Env>();

function genId(): string {
  return (
    'msg_' +
    Math.random().toString(36).slice(2, 10) +
    Date.now().toString(36).slice(-4)
  );
}

// ========== 發送訊息（乘客） ==========
router.post('/passenger/send', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { orderId, text } = body;
  if (!orderId || !text) return c.json({ error: '參數唔完整' }, 400);

  const order: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1 AND passenger_id = ?2')
    .bind(orderId, userId)
    .first();

  if (!order) return c.json({ error: '訂單唔存在' }, 404);
  if (['cancelled', 'finished'].includes(order.status)) {
    return c.json({ error: '訂單已完結，唔可以再發訊息' }, 400);
  }

  const id = genId();
  const now = Date.now();

  await c.env.DB
    .prepare(
      `INSERT INTO chat_messages (id, order_id, sender_role, sender_id, text, timestamp)
       VALUES (?1, ?2, 'passenger', ?3, ?4, ?5)`
    )
    .bind(id, orderId, userId, text, now)
    .run();

  const message = { id, orderId, from: 'passenger', text, timestamp: now };
  return c.json({ message });
});

// ========== 發送訊息（司機） ==========
router.post('/driver/send', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { orderId, text } = body;
  if (!orderId || !text) return c.json({ error: '參數唔完整' }, 400);

  const order: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1 AND driver_id = ?2')
    .bind(orderId, userId)
    .first();

  if (!order) return c.json({ error: '訂單唔存在' }, 404);
  if (['cancelled', 'finished'].includes(order.status)) {
    return c.json({ error: '訂單已完結，唔可以再發訊息' }, 400);
  }

  const id = genId();
  const now = Date.now();

  await c.env.DB
    .prepare(
      `INSERT INTO chat_messages (id, order_id, sender_role, sender_id, text, timestamp)
       VALUES (?1, ?2, 'driver', ?3, ?4, ?5)`
    )
    .bind(id, orderId, userId, text, now)
    .run();

  const message = { id, orderId, from: 'driver', text, timestamp: now };
  return c.json({ message });
});

// ========== 攞訂單訊息列表 ==========
router.get('/order/:orderId', async (c) => {
  const { orderId } = c.req.param();

  const { results } = await c.env.DB
    .prepare(
      `SELECT id, order_id, sender_role as "from", text, timestamp
       FROM chat_messages
       WHERE order_id = ?1
       ORDER BY timestamp ASC
       LIMIT 200`
    )
    .bind(orderId)
    .all();

  const messages = results.map((r: any) => ({
    id: r.id,
    orderId: r.order_id,
    from: r.from,
    text: r.text,
    timestamp: r.timestamp,
  }));

  return c.json({ messages });
});

export default router;
