import { Hono } from 'hono';

import type { Env } from '../index';

const router = new Hono<Env>();

function genOrderId(): string {
  return (
    'HK' +
    Math.random().toString(36).slice(2, 8).toUpperCase() +
    Date.now().toString(36).slice(-4)
  );
}

function orderToJson(row: any): any {
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    passenger: row.passenger_id
      ? {
          id: row.passenger_id,
          name: row.passenger_name,
          rating: row.passenger_rating,
        }
      : undefined,
    driver: row.driver_id
      ? {
          id: row.driver_id,
          name: row.driver_name,
          plate: row.driver_plate,
          carModel: row.driver_car_model,
          rating: row.driver_rating,
          currentLat: row.driver_lat,
          currentLng: row.driver_lng,
        }
      : undefined,
    pickup: {
      name: row.pickup_name,
      lat: row.pickup_lat,
      lng: row.pickup_lng,
    },
    destination: {
      name: row.destination_name,
      lat: row.destination_lat,
      lng: row.destination_lng,
    },
    carType: row.car_type,
    hasDiscount: !!row.has_discount,
    tipAmount: row.tip_amount || 0,
    estimatedFare: row.estimated_fare,
    actualFare: row.actual_fare,
    paymentMethod: row.payment_method,
    distanceKm: row.distance_km,
    etaMinutes: row.eta_minutes,
    passengerLat: row.passenger_lat,
    passengerLng: row.passenger_lng,
    taxiType: row.taxi_type,
    driverRating: row.driver_rating,
    passengerRating: row.passenger_rating,
    createdAt: row.created_at,
    acceptedAt: row.accepted_at,
    pickedUpAt: row.picked_up_at,
    completedAt: row.completed_at,
    paidAt: row.paid_at,
    finishedAt: row.finished_at,
  };
}

async function getOrderById(db: D1Database, id: string): Promise<any> {
  const row = await db
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.id = ?1`
    )
    .bind(id)
    .first();
  return orderToJson(row);
}

// ========== 乘客叫車 ==========
router.post('/passenger/request', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const {
    pickup,
    destination,
    carType,
    hasDiscount,
    tipAmount,
    estimatedFare,
    distanceKm,
    etaMinutes,
    taxiType,
    pickupName,
    pickupLat,
    pickupLng,
    destinationName,
    destinationLat,
    destinationLng,
    discount,
    tip,
  } = body;

  const pickupObj = pickup || { name: pickupName, lat: pickupLat, lng: pickupLng };
  const destObj = destination || { name: destinationName, lat: destinationLat, lng: destinationLng };
  const hasDiscountVal = hasDiscount !== undefined ? hasDiscount : discount === true;
  const tipVal = tipAmount !== undefined ? tipAmount : tip || 0;

  if (!pickupObj || !destObj || !estimatedFare) {
    return c.json({ error: '參數唔完整' }, 400);
  }

  // Check active order
  const active = await c.env.DB
    .prepare(
      `SELECT id FROM orders
       WHERE passenger_id = ?1 AND status IN ('searching','accepted','picked_up','completed','paid')`
    )
    .bind(userId)
    .first();

  if (active) {
    return c.json({ error: '你有進行中嘅訂單，請先完成' }, 400);
  }

  const id = genOrderId();
  const now = Date.now();
  const pLat = pickupObj.lat ?? 22.3;
  const pLng = pickupObj.lng ?? 114.17;

  await c.env.DB
    .prepare(
      `INSERT INTO orders (
        id, status, passenger_id,
        pickup_name, pickup_lat, pickup_lng,
        destination_name, destination_lat, destination_lng,
        car_type, has_discount, tip_amount, estimated_fare,
        distance_km, eta_minutes,
        passenger_lat, passenger_lng,
        taxi_type, created_at
      ) VALUES (?1, 'searching', ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18)`
    )
    .bind(
      id,
      userId,
      pickupObj.name,
      pLat,
      pLng,
      destObj.name,
      destObj.lat,
      destObj.lng,
      carType || '4pax',
      hasDiscountVal ? 1 : 0,
      tipVal || 0,
      estimatedFare,
      distanceKm || null,
      etaMinutes || null,
      pLat,
      pLng,
      taxiType || 'red',
      now
    )
    .run();

  const order = await getOrderById(c.env.DB, id);
  return c.json({ order });
});

// ========== 乘客取消叫車 ==========
router.post('/passenger/cancel', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const order = await c.env.DB
    .prepare(
      "SELECT * FROM orders WHERE passenger_id = ?1 AND status = 'searching' ORDER BY created_at DESC LIMIT 1"
    )
    .bind(userId)
    .first();

  if (!order) return c.json({ error: '冇可取消嘅訂單' }, 400);

  await c.env.DB.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?1").bind((order as any).id).run();

  return c.json({ ok: true });
});

// ========== 乘客當前訂單 ==========
router.get('/passenger/current', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ order: null });

  const row = await c.env.DB
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.passenger_id = ?1 AND o.status IN ('searching','accepted','picked_up','completed','paid')
       ORDER BY o.created_at DESC
       LIMIT 1`
    )
    .bind(userId)
    .first();

  return c.json({ order: orderToJson(row) || null });
});

// ========== 乘客歷史訂單 ==========
router.get('/passenger/history', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ orders: [] });

  const { results } = await c.env.DB
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.passenger_id = ?1 AND o.status IN ('paid','finished')
       ORDER BY o.created_at DESC
       LIMIT 20`
    )
    .bind(userId)
    .all();

  return c.json({ orders: results.map(orderToJson) });
});

// ========== 乘客評分司機 ==========
router.post('/passenger/rate', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { orderId, rating } = body;
  if (!orderId || !rating) return c.json({ error: '參數唔完整' }, 400);

  const order: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1 AND passenger_id = ?2')
    .bind(orderId, userId)
    .first();

  if (!order) return c.json({ error: '訂單唔存在' }, 404);

  await c.env.DB
    .prepare('UPDATE orders SET driver_rating = ?1 WHERE id = ?2')
    .bind(rating, orderId)
    .run();

  // Update driver average rating
  if (order.driver_id) {
    const d: any = await c.env.DB
      .prepare('SELECT rating, rating_count FROM drivers WHERE id = ?1')
      .bind(order.driver_id)
      .first();

    if (d) {
      const newCount = d.rating_count + 1;
      const newRating = ((d.rating * d.rating_count) + rating) / newCount;
      await c.env.DB
        .prepare('UPDATE drivers SET rating = ?1, rating_count = ?2 WHERE id = ?3')
        .bind(Math.round(newRating * 10) / 10, newCount, order.driver_id)
        .run();
    }
  }

  // Check both rated
  const updated: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1')
    .bind(orderId)
    .first();

  if (updated.passenger_rating) {
    await c.env.DB
      .prepare("UPDATE orders SET status = 'finished', finished_at = ?1 WHERE id = ?2")
      .bind(Date.now(), orderId)
      .run();
  }

  return c.json({ ok: true });
});

// ========== 司機接單大廳列表 ==========
router.get('/driver/hall', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ orders: [] });

  const driver: any = await c.env.DB
    .prepare('SELECT status, online FROM drivers WHERE id = ?1')
    .bind(userId)
    .first();

  if (!driver || driver.status !== 'approved') {
    return c.json({ orders: [] });
  }

  const { results } = await c.env.DB
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.status = 'searching'
       ORDER BY o.created_at DESC
       LIMIT 10`
    )
    .all();

  return c.json({ orders: results.map(orderToJson) });
});

// ========== 司機接單 ==========
router.post('/driver/accept/:orderId', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  const { orderId } = c.req.param();

  if (!userId) return c.json({ error: '未登入' }, 401);

  const driver: any = await c.env.DB
    .prepare('SELECT * FROM drivers WHERE id = ?1')
    .bind(userId)
    .first();

  if (!driver || driver.status !== 'approved') {
    return c.json({ error: '你嘅帳號未審批，唔可以接單' }, 400);
  }
  if (!driver.online) {
    return c.json({ error: '請先上線先可以接單' }, 400);
  }

  // Check active order
  const active = await c.env.DB
    .prepare(
      `SELECT id FROM orders
       WHERE driver_id = ?1 AND status IN ('accepted','picked_up','completed')`
    )
    .bind(userId)
    .first();

  if (active) {
    return c.json({ error: '你有進行中嘅訂單' }, 400);
  }

  const order: any = await c.env.DB
    .prepare("SELECT * FROM orders WHERE id = ?1 AND status = 'searching'")
    .bind(orderId)
    .first();

  if (!order) {
    return c.json({ error: '訂單已經俾人接咗或者取消咗' }, 400);
  }

  const now = Date.now();
  const driverLat = driver.current_lat || order.pickup_lat + 0.01;
  const driverLng = driver.current_lng || order.pickup_lng + 0.01;

  await c.env.DB
    .prepare(
      `UPDATE orders SET
        status = 'accepted', driver_id = ?1, accepted_at = ?2,
        driver_lat = ?3, driver_lng = ?4
        WHERE id = ?5 AND status = 'searching'`
    )
    .bind(userId, now, driverLat, driverLng, orderId)
    .run();

  const updated = await getOrderById(c.env.DB, orderId);
  return c.json({ order: updated });
});

// ========== 司機拒單 ==========
router.post('/driver/reject/:orderId', async (c) => {
  // Demo: reject simply hides from this driver (no persistent tracking)
  return c.json({ ok: true });
});

// ========== 司機當前訂單 ==========
router.get('/driver/current', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ order: null });

  const row = await c.env.DB
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.driver_id = ?1 AND o.status IN ('accepted','picked_up','completed','paid')
       ORDER BY o.created_at DESC
       LIMIT 1`
    )
    .bind(userId)
    .first();

  return c.json({ order: orderToJson(row) || null });
});

// ========== 司機到達上車點 ==========
router.post('/driver/arrive-pickup', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const order: any = await c.env.DB
    .prepare(
      "SELECT * FROM orders WHERE driver_id = ?1 AND status = 'accepted' ORDER BY created_at DESC LIMIT 1"
    )
    .bind(userId)
    .first();

  if (!order) return c.json({ error: '冇進行中嘅接單' }, 400);

  await c.env.DB
    .prepare("UPDATE orders SET status = 'picked_up', picked_up_at = ?1 WHERE id = ?2")
    .bind(Date.now(), order.id)
    .run();

  const updated = await getOrderById(c.env.DB, order.id);
  return c.json({ order: updated });
});

// ========== 司機到達目的地 ==========
router.post('/driver/complete', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { actualFare } = body;

  const order: any = await c.env.DB
    .prepare(
      "SELECT * FROM orders WHERE driver_id = ?1 AND status IN ('picked_up', 'accepted') ORDER BY created_at DESC LIMIT 1"
    )
    .bind(userId)
    .first();

  if (!order) return c.json({ error: '冇進行中嘅行程' }, 400);

  const fare = actualFare ?? order.estimated_fare;
  await c.env.DB
    .prepare("UPDATE orders SET status = 'completed', actual_fare = ?1, completed_at = ?2 WHERE id = ?3")
    .bind(fare, Date.now(), order.id)
    .run();

  const updated = await getOrderById(c.env.DB, order.id);
  return c.json({ order: updated });
});

// ========== 司機收入記錄 ==========
router.get('/driver/earnings', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ orders: [] });

  const { results } = await c.env.DB
    .prepare(
      `SELECT o.*,
              p.name as passenger_name, p.rating as passenger_rating,
              d.name as driver_name, d.plate as driver_plate,
              d.car_model as driver_car_model, d.rating as driver_rating
       FROM orders o
       LEFT JOIN passengers p ON o.passenger_id = p.id
       LEFT JOIN drivers d ON o.driver_id = d.id
       WHERE o.driver_id = ?1 AND o.status IN ('paid','finished')
       ORDER BY o.created_at DESC
       LIMIT 30`
    )
    .bind(userId)
    .all();

  return c.json({ orders: results.map(orderToJson) });
});

// ========== 司機評分乘客 ==========
router.post('/driver/rate', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { orderId, rating } = body;
  if (!orderId || !rating) return c.json({ error: '參數唔完整' }, 400);

  const order: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1 AND driver_id = ?2')
    .bind(orderId, userId)
    .first();

  if (!order) return c.json({ error: '訂單唔存在' }, 404);

  await c.env.DB
    .prepare('UPDATE orders SET passenger_rating = ?1 WHERE id = ?2')
    .bind(rating, orderId)
    .run();

  // Update passenger average rating
  if (order.passenger_id) {
    const p: any = await c.env.DB
      .prepare('SELECT rating, rating_count FROM passengers WHERE id = ?1')
      .bind(order.passenger_id)
      .first();

    if (p) {
      const newCount = p.rating_count + 1;
      const newRating = ((p.rating * p.rating_count) + rating) / newCount;
      await c.env.DB
        .prepare('UPDATE passengers SET rating = ?1, rating_count = ?2 WHERE id = ?3')
        .bind(Math.round(newRating * 10) / 10, newCount, order.passenger_id)
        .run();
    }
  }

  // Check both rated
  const updated: any = await c.env.DB
    .prepare('SELECT * FROM orders WHERE id = ?1')
    .bind(orderId)
    .first();

  if (updated.driver_rating) {
    await c.env.DB
      .prepare("UPDATE orders SET status = 'finished', finished_at = ?1 WHERE id = ?2")
      .bind(Date.now(), orderId)
      .run();
  }

  return c.json({ ok: true });
});

// ========== 司機上線/落線 ==========
router.post('/driver/online', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { online, lat, lng } = body;

  await c.env.DB
    .prepare('UPDATE drivers SET online = ?1, current_lat = ?2, current_lng = ?3 WHERE id = ?4')
    .bind(online ? 1 : 0, lat || null, lng || null, userId)
    .run();

  return c.json({ online: !!online });
});

// ========== 更新司機位置 ==========
router.post('/driver/location', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { lat, lng, orderId } = body;

  if (lat == null || lng == null) return c.json({ error: '位置參數唔完整' }, 400);

  await c.env.DB
    .prepare('UPDATE drivers SET current_lat = ?1, current_lng = ?2 WHERE id = ?3')
    .bind(lat, lng, userId)
    .run();

  if (orderId) {
    await c.env.DB
      .prepare(
        'UPDATE orders SET driver_lat = ?1, driver_lng = ?2 WHERE id = ?3 AND driver_id = ?4'
      )
      .bind(lat, lng, orderId, userId)
      .run();
  }

  return c.json({ ok: true });
});

// ========== 更新乘客位置 ==========
router.post('/passenger/location', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { lat, lng, orderId } = body;

  if (lat == null || lng == null || !orderId)
    return c.json({ error: '參數唔完整' }, 400);

  await c.env.DB
    .prepare(
      'UPDATE orders SET passenger_lat = ?1, passenger_lng = ?2 WHERE id = ?3 AND passenger_id = ?4'
    )
    .bind(lat, lng, orderId, userId)
    .run();

  return c.json({ ok: true });
});

// ========== 付款 ==========
router.post('/passenger/pay', async (c) => {
  const userId = c.get('jwtPayload')?.id;
  if (!userId) return c.json({ error: '未登入' }, 401);

  const body = await c.req.json();
  const { method, orderId } = body;

  const order: any = await c.env.DB
    .prepare(
      "SELECT * FROM orders WHERE id = ?1 AND passenger_id = ?2 AND status = 'completed'"
    )
    .bind(orderId || '', userId)
    .first();

  if (!order) return c.json({ error: '冇待付款嘅訂單' }, 400);

  const now = Date.now();
  await c.env.DB
    .prepare(
      "UPDATE orders SET status = 'paid', payment_method = ?1, paid_at = ?2 WHERE id = ?3"
    )
    .bind(method || 'cash', now, order.id)
    .run();

  const updated = await getOrderById(c.env.DB, order.id);
  return c.json({ order: updated });
});

// ========== 訂單詳情 ==========
router.get('/:id', async (c) => {
  const { id } = c.req.param();
  const order = await getOrderById(c.env.DB, id);
  if (!order) return c.json({ error: '訂單唔存在' }, 404);
  return c.json({ order });
});

export default router;
