const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const DB_PATH = path.join(__dirname, 'taxi.db');
const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ========== Schema ==========
db.exec(`
CREATE TABLE IF NOT EXISTS passengers (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE,
  password TEXT NOT NULL,
  name TEXT,
  avatar TEXT,
  rating REAL DEFAULT 5,
  rating_count INTEGER DEFAULT 0,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS drivers (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE,
  password TEXT NOT NULL,
  name TEXT,
  avatar TEXT,
  plate TEXT,
  car_model TEXT,
  driver_license TEXT,
  rating REAL DEFAULT 5,
  rating_count INTEGER DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', -- pending / approved / rejected
  reject_reason TEXT,
  online INTEGER DEFAULT 0,
  current_lat REAL,
  current_lng REAL,
  created_at INTEGER NOT NULL,
  approved_at INTEGER
);

CREATE TABLE IF NOT EXISTS admins (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL DEFAULT 'searching',
  passenger_id TEXT NOT NULL,
  driver_id TEXT,
  pickup_name TEXT NOT NULL,
  pickup_lat REAL NOT NULL,
  pickup_lng REAL NOT NULL,
  destination_name TEXT NOT NULL,
  destination_lat REAL NOT NULL,
  destination_lng REAL NOT NULL,
  car_type TEXT NOT NULL DEFAULT '4pax',
  has_discount INTEGER DEFAULT 0,
  tip_amount REAL DEFAULT 0,
  estimated_fare REAL NOT NULL,
  actual_fare REAL,
  payment_method TEXT,
  distance_km REAL,
  eta_minutes INTEGER,
  driver_lat REAL,
  driver_lng REAL,
  passenger_lat REAL,
  passenger_lng REAL,
  taxi_type TEXT DEFAULT 'red',
  driver_rating INTEGER,
  passenger_rating INTEGER,
  created_at INTEGER NOT NULL,
  accepted_at INTEGER,
  picked_up_at INTEGER,
  completed_at INTEGER,
  paid_at INTEGER,
  finished_at INTEGER,
  FOREIGN KEY (passenger_id) REFERENCES passengers(id),
  FOREIGN KEY (driver_id) REFERENCES drivers(id)
);

CREATE TABLE IF NOT EXISTS chat_messages (
  id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL,
  sender_role TEXT NOT NULL, -- passenger / driver
  sender_id TEXT NOT NULL,
  text TEXT NOT NULL,
  timestamp INTEGER NOT NULL,
  read_by_other INTEGER DEFAULT 0,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_passenger ON orders(passenger_id);
CREATE INDEX IF NOT EXISTS idx_orders_driver ON orders(driver_id);
CREATE INDEX IF NOT EXISTS idx_chat_order ON chat_messages(order_id);
CREATE INDEX IF NOT EXISTS idx_drivers_status ON drivers(status);
`);

// ========== Seed admin ==========
const adminCheck = db.prepare('SELECT COUNT(*) as c FROM admins WHERE username = ?');
const { c: adminCount } = adminCheck.get('admin');
if (adminCount === 0) {
  const hash = bcrypt.hashSync('lovevivi815', 10);
  db.prepare('INSERT INTO admins (id, username, password, created_at) VALUES (?, ?, ?, ?)').run(
    'admin_001', 'admin', hash, Date.now()
  );
  console.log('[DB] Admin seeded: admin / lovevivi815');
}

module.exports = db;
