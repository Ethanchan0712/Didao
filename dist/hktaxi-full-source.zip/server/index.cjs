const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));

// DB init (side effect - creates tables + seeds)
require('./db/index.cjs');

// API routes
app.use('/api/auth', require('./routes/auth.cjs'));
app.use('/api/orders', require('./routes/orders.cjs'));
app.use('/api/chat', require('./routes/chat.cjs'));
app.use('/api/admin', require('./routes/admin.cjs'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ ok: true, ts: Date.now() });
});

// Serve static client build in production
const clientDist = path.join(__dirname, '..', 'dist');
const fs = require('fs');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  // SPA fallback
  app.use((req, res, next) => {
    if (req.method === 'GET' && !req.path.startsWith('/api/')) {
      res.sendFile(path.join(clientDist, 'index.html'));
    } else {
      next();
    }
  });
}

app.listen(PORT, () => {
  console.log(`\n🚕 的道後端服務啟動成功！`);
  console.log(`   端口: ${PORT}`);
  console.log(`   API:  http://localhost:${PORT}/api/`);
  console.log(`   管理員: admin / lovevivi815\n`);
});
