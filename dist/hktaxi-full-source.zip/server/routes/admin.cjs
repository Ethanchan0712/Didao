const express = require('express');
const db = require('../db/index.cjs');
const sseHub = require('../sse/hub.cjs');
const { authAdmin } = require('../middleware/auth.cjs');

const router = express.Router();

// ========== 統計 ==========
router.get('/stats', authAdmin, (req, res) => {
  const pending = db.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'pending'").get().c;
  const approved = db.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'approved'").get().c;
  const rejected = db.prepare("SELECT COUNT(*) as c FROM drivers WHERE status = 'rejected'").get().c;
  const totalOrders = db.prepare('SELECT COUNT(*) as c FROM orders').get().c;
  const todayOrders = db.prepare('SELECT COUNT(*) as c FROM orders WHERE created_at > ?').get(Date.now() - 86400000).c;
  const totalRevenue = db.prepare("SELECT COALESCE(SUM(actual_fare), 0) as s FROM orders WHERE status IN ('paid','finished')").get().s;
  const passengerCount = db.prepare('SELECT COUNT(*) as c FROM passengers').get().c;

  res.json({
    pending, approved, rejected,
    totalOrders, todayOrders,
    totalRevenue, passengerCount,
  });
});

// ========== 司機申請列表 ==========
router.get('/drivers', authAdmin, (req, res) => {
  const { status = 'pending' } = req.query;
  let rows;
  if (status === 'all') {
    rows = db.prepare('SELECT * FROM drivers ORDER BY created_at DESC LIMIT 100').all();
  } else {
    rows = db.prepare('SELECT * FROM drivers WHERE status = ? ORDER BY created_at DESC LIMIT 100').all(status);
  }
  res.json({ drivers: rows });
});

// ========== 批准司機 ==========
router.post('/drivers/:id/approve', authAdmin, (req, res) => {
  const { id } = req.params;
  const driver = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);
  if (!driver) return res.status(404).json({ error: '司機唔存在' });

  db.prepare("UPDATE drivers SET status = 'approved', approved_at = ? WHERE id = ?").run(Date.now(), id);
  const updated = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);

  sseHub.publishToAdmin('driver-updated', { driver: updated });
  res.json({ driver: updated });
});

// ========== 拒絕司機 ==========
router.post('/drivers/:id/reject', authAdmin, (req, res) => {
  const { id } = req.params;
  const { reason } = req.body;
  const driver = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);
  if (!driver) return res.status(404).json({ error: '司機唔存在' });

  db.prepare("UPDATE drivers SET status = 'rejected', reject_reason = ? WHERE id = ?").run(reason || '', id);
  const updated = db.prepare('SELECT * FROM drivers WHERE id = ?').get(id);

  sseHub.publishToAdmin('driver-updated', { driver: updated });
  res.json({ driver: updated });
});

// ========== 訂單列表 ==========
router.get('/orders', authAdmin, (req, res) => {
  const { status } = req.query;
  let query = `
    SELECT o.*,
           p.name as passenger_name, p.phone as passenger_phone,
           d.name as driver_name, d.plate as driver_plate
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
  `;
  const params = [];
  if (status && status !== 'all') {
    query += ' WHERE o.status = ?';
    params.push(status);
  }
  query += ' ORDER BY o.created_at DESC LIMIT 100';
  const rows = db.prepare(query).all(...params);
  res.json({ orders: rows });
});

// ========== SSE 管理員 ==========
router.get('/stream', authAdmin, (req, res) => {
  sseHub.subscribe(req, res, 'admin', null);
});

module.exports = router;
