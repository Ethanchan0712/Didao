const express = require('express');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('../db/index.cjs');
const { signToken, authPassenger, authDriver } = require('../middleware/auth.cjs');

const router = express.Router();

function genId(prefix) {
  return prefix + '_' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

// ========== 乘客註冊 ==========
router.post('/passenger/register', (req, res) => {
  const { username, phone, password, name } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號同密碼' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: '密碼至少 6 位' });
  }

  const existing = db.prepare('SELECT id FROM passengers WHERE username = ? OR phone = ?').get(username, phone || '');
  if (existing) {
    return res.status(400).json({ error: '帳號或電話已經註冊咗' });
  }

  const id = genId('p');
  const hash = bcrypt.hashSync(password, 10);
  const now = Date.now();

  db.prepare(`INSERT INTO passengers (id, username, phone, password, name, created_at)
              VALUES (?, ?, ?, ?, ?, ?)`).run(id, username, phone || '', hash, name || username, now);

  const user = db.prepare('SELECT id, username, phone, name, rating, rating_count FROM passengers WHERE id = ?').get(id);
  const token = signToken({ id, role: 'passenger' });

  res.json({ user, token });
});

// ========== 乘客登入 ==========
router.post('/passenger/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號同密碼' });
  }

  const row = db.prepare('SELECT * FROM passengers WHERE username = ? OR phone = ?').get(username, username);
  if (!row) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const user = {
    id: row.id,
    username: row.username,
    phone: row.phone,
    name: row.name,
    avatar: row.avatar,
    rating: row.rating,
    rating_count: row.rating_count,
  };
  const token = signToken({ id: row.id, role: 'passenger' });

  res.json({ user, token });
});

// ========== 乘客資料 ==========
router.get('/passenger/me', authPassenger, (req, res) => {
  res.json({ user: req.user });
});

// ========== 司機註冊 ==========
router.post('/driver/register', (req, res) => {
  const { username, phone, password, name, plate, carModel, driverLicense } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號同密碼' });
  }
  if (password.length < 6) {
    return res.status(400).json({ error: '密碼至少 6 位' });
  }

  const existing = db.prepare('SELECT id FROM drivers WHERE username = ? OR phone = ?').get(username, phone || '');
  if (existing) {
    return res.status(400).json({ error: '帳號或電話已經註冊咗' });
  }

  const id = genId('d');
  const hash = bcrypt.hashSync(password, 10);
  const now = Date.now();

  db.prepare(`INSERT INTO drivers (id, username, phone, password, name, plate, car_model, driver_license, status, created_at)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`).run(
    id, username, phone || '', hash, name || username,
    plate || '', carModel || '', driverLicense || '', now
  );

  const user = db.prepare(`SELECT id, username, phone, name, plate, car_model, driver_license, status, rating, rating_count
                           FROM drivers WHERE id = ?`).get(id);
  const token = signToken({ id, role: 'driver' });

  // 通知管理員有新申請
  const sseHub = require('../sse/hub.cjs');
  sseHub.publishToAdmin('new-driver-application', { driver: user });

  res.json({ user, token });
});

// ========== 司機登入 ==========
router.post('/driver/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號同密碼' });
  }

  const row = db.prepare('SELECT * FROM drivers WHERE username = ? OR phone = ?').get(username, username);
  if (!row) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const user = {
    id: row.id,
    username: row.username,
    phone: row.phone,
    name: row.name,
    avatar: row.avatar,
    plate: row.plate,
    car_model: row.car_model,
    driver_license: row.driver_license,
    status: row.status,
    online: !!row.online,
    rating: row.rating,
    rating_count: row.rating_count,
    current_lat: row.current_lat,
    current_lng: row.current_lng,
  };
  const token = signToken({ id: row.id, role: 'driver' });

  res.json({ user, token });
});

// ========== 司機資料 ==========
router.get('/driver/me', authDriver, (req, res) => {
  res.json({ user: req.user });
});

// ========== 管理員登入 ==========
router.post('/admin/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: '請輸入帳號同密碼' });
  }

  const row = db.prepare('SELECT * FROM admins WHERE username = ?').get(username);
  if (!row) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const ok = bcrypt.compareSync(password, row.password);
  if (!ok) {
    return res.status(401).json({ error: '帳號或密碼錯誤' });
  }

  const user = { id: row.id, username: row.username };
  const token = signToken({ id: row.id, role: 'admin' });

  res.json({ user, token });
});

module.exports = router;
