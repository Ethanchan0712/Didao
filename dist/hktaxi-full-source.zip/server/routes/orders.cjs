const express = require('express');
const db = require('../db/index.cjs');
const sseHub = require('../sse/hub.cjs');
const { authPassenger, authDriver } = require('../middleware/auth.cjs');

const router = express.Router();

function genOrderId() {
  return 'HK' + Math.random().toString(36).slice(2, 8).toUpperCase() + Date.now().toString().slice(-4);
}

function orderToJson(row) {
  if (!row) return null;
  return {
    id: row.id,
    status: row.status,
    passenger: row.passenger_id ? {
      id: row.passenger_id,
      name: row.passenger_name,
      rating: row.passenger_rating,
    } : undefined,
    driver: row.driver_id ? {
      id: row.driver_id,
      name: row.driver_name,
      plate: row.driver_plate,
      carModel: row.driver_car_model,
      rating: row.driver_rating,
      currentLat: row.driver_lat,
      currentLng: row.driver_lng,
    } : undefined,
    pickup: {
      name: row.pickup_name,
      lat: row.pickup_lat,
      lng: row.pickup_lng,
    },
    destination: {
      name: row.destination_name,
      lat: row.destination_lat,
      lng: row.destination_lng,
    },
    carType: row.car_type,
    hasDiscount: !!row.has_discount,
    tipAmount: row.tip_amount || 0,
    estimatedFare: row.estimated_fare,
    actualFare: row.actual_fare,
    paymentMethod: row.payment_method,
    distanceKm: row.distance_km,
    etaMinutes: row.eta_minutes,
    passengerLat: row.passenger_lat,
    passengerLng: row.passenger_lng,
    taxiType: row.taxi_type,
    driverRating: row.driver_rating,
    passengerRating: row.passenger_rating,
    createdAt: row.created_at,
    acceptedAt: row.accepted_at,
    pickedUpAt: row.picked_up_at,
    completedAt: row.completed_at,
    paidAt: row.paid_at,
    finishedAt: row.finished_at,
  };
}

function getOrderById(id) {
  const row = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.id = ?
  `).get(id);
  return orderToJson(row);
}

// ========== 乘客叫車 ==========
router.post('/passenger/request', authPassenger, (req, res) => {
  const { 
    pickup, destination, carType, hasDiscount, tipAmount, estimatedFare, distanceKm, etaMinutes, taxiType,
    pickupName, pickupLat, pickupLng, destinationName, destinationLat, destinationLng,
    discount, tip
  } = req.body;

  // Support both flat and nested formats
  const pickupObj = pickup || { name: pickupName, lat: pickupLat, lng: pickupLng };
  const destObj = destination || { name: destinationName, lat: destinationLat, lng: destinationLng };
  const hasDiscountVal = hasDiscount !== undefined ? hasDiscount : (discount === true);
  const tipVal = tipAmount !== undefined ? tipAmount : (tip || 0);

  if (!pickupObj || !destObj || !estimatedFare) {
    return res.status(400).json({ error: '參數唔完整' });
  }

  // 檢查乘客有冇進行中訂單
  const active = db.prepare(`SELECT id FROM orders
    WHERE passenger_id = ? AND status IN ('searching','accepted','picked_up','completed','paid')`).get(req.userId);
  if (active) {
    return res.status(400).json({ error: '你有進行中嘅訂單，請先完成' });
  }

  const id = genOrderId();
  const now = Date.now();
  const pLat = pickupObj.lat ?? 22.3;
  const pLng = pickupObj.lng ?? 114.17;

  db.prepare(`INSERT INTO orders (
    id, status, passenger_id,
    pickup_name, pickup_lat, pickup_lng,
    destination_name, destination_lat, destination_lng,
    car_type, has_discount, tip_amount, estimated_fare,
    distance_km, eta_minutes,
    passenger_lat, passenger_lng,
    taxi_type, created_at
  ) VALUES (?, 'searching', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
    id, req.userId,
    pickupObj.name, pLat, pLng,
    destObj.name, destObj.lat, destObj.lng,
    carType || '4pax', hasDiscountVal ? 1 : 0, tipVal || 0, estimatedFare,
    distanceKm || null, etaMinutes || null,
    pLat, pLng,
    taxiType || 'red', now
  );

  const order = getOrderById(id);

  // 推送到司機大廳
  sseHub.publishToDriverHall('new-order', { order });

  res.json({ order });
});

// ========== 乘客取消叫車 ==========
router.post('/passenger/cancel', authPassenger, (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE passenger_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1').get(req.userId, 'searching');
  if (!order) return res.status(400).json({ error: '冇可取消嘅訂單' });

  db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(order.id);

  sseHub.publishToOrder(order.id, 'order-cancelled', { orderId: order.id });
  sseHub.publishToDriverHall('order-cancelled', { orderId: order.id });

  res.json({ ok: true });
});

// ========== 乘客當前訂單 ==========
router.get('/passenger/current', authPassenger, (req, res) => {
  const row = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.passenger_id = ? AND o.status IN ('searching','accepted','picked_up','completed','paid')
    ORDER BY o.created_at DESC
    LIMIT 1
  `).get(req.userId);
  res.json({ order: orderToJson(row) || null });
});

// ========== 乘客歷史訂單 ==========
router.get('/passenger/history', authPassenger, (req, res) => {
  const rows = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.passenger_id = ? AND o.status IN ('paid','finished')
    ORDER BY o.created_at DESC
    LIMIT 20
  `).all(req.userId);
  res.json({ orders: rows.map(orderToJson) });
});

// ========== 乘客評分司機 ==========
router.post('/passenger/rate', authPassenger, (req, res) => {
  const { orderId, rating } = req.body;
  if (!orderId || !rating) return res.status(400).json({ error: '參數唔完整' });

  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND passenger_id = ?').get(orderId, req.userId);
  if (!order) return res.status(404).json({ error: '訂單唔存在' });

  db.prepare('UPDATE orders SET driver_rating = ? WHERE id = ?').run(rating, orderId);

  // 更新司機平均分
  if (order.driver_id) {
    const d = db.prepare('SELECT rating, rating_count FROM drivers WHERE id = ?').get(order.driver_id);
    if (d) {
      const newCount = d.rating_count + 1;
      const newRating = ((d.rating * d.rating_count) + rating) / newCount;
      db.prepare('UPDATE drivers SET rating = ?, rating_count = ? WHERE id = ?').run(
        Math.round(newRating * 10) / 10, newCount, order.driver_id
      );
    }
  }

  // 檢查係咪雙方都評分咗
  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (updated.passenger_rating) {
    db.prepare("UPDATE orders SET status = 'finished', finished_at = ? WHERE id = ?").run(Date.now(), orderId);
  }

  sseHub.publishToOrder(orderId, 'driver-rated', { orderId, rating });

  res.json({ ok: true });
});

// ========== 司機接單大廳列表 ==========
router.get('/driver/hall', authDriver, (req, res) => {
  // 淨係俾 approved 同 online 嘅司機睇
  const driver = db.prepare('SELECT status, online FROM drivers WHERE id = ?').get(req.userId);
  if (!driver || driver.status !== 'approved') {
    return res.json({ orders: [] });
  }

  const rows = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.status = 'searching'
    ORDER BY o.created_at DESC
    LIMIT 10
  `).all();
  res.json({ orders: rows.map(orderToJson) });
});

// ========== 司機接單 ==========
router.post('/driver/accept/:orderId', authDriver, (req, res) => {
  const { orderId } = req.params;
  const driver = db.prepare('SELECT * FROM drivers WHERE id = ?').get(req.userId);

  if (!driver || driver.status !== 'approved') {
    return res.status(400).json({ error: '你嘅帳號未審批，唔可以接單' });
  }
  if (!driver.online) {
    return res.status(400).json({ error: '請先上線先可以接單' });
  }

  // 檢查司機有冇進行中訂單
  const active = db.prepare(`SELECT id FROM orders
    WHERE driver_id = ? AND status IN ('accepted','picked_up','completed')`).get(req.userId);
  if (active) {
    return res.status(400).json({ error: '你有進行中嘅訂單' });
  }

  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND status = ?').get(orderId, 'searching');
  if (!order) {
    return res.status(400).json({ error: '訂單已經俾人接咗或者取消咗' });
  }

  const now = Date.now();
  const driverLat = driver.current_lat || order.pickup_lat + 0.01;
  const driverLng = driver.current_lng || order.pickup_lng + 0.01;

  db.prepare(`UPDATE orders SET
    status = 'accepted', driver_id = ?, accepted_at = ?,
    driver_lat = ?, driver_lng = ?
    WHERE id = ? AND status = 'searching'`).run(req.userId, now, driverLat, driverLng, orderId);

  const updated = getOrderById(orderId);

  sseHub.publishToOrder(orderId, 'order-accepted', { order: updated });
  sseHub.publishToDriverHall('order-taken', { orderId, driverId: req.userId });

  res.json({ order: updated });
});

// ========== 司機拒單 ==========
router.post('/driver/reject/:orderId', authDriver, (req, res) => {
  // 示範版：拒單只係該司機唔再睇到呢張單
  // 真實版本應該有 reject 表，呢度簡化處理
  res.json({ ok: true });
});

// ========== 司機當前訂單 ==========
router.get('/driver/current', authDriver, (req, res) => {
  const row = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.driver_id = ? AND o.status IN ('accepted','picked_up','completed','paid')
    ORDER BY o.created_at DESC
    LIMIT 1
  `).get(req.userId);
  res.json({ order: orderToJson(row) || null });
});

// ========== 司機到達上車點 ==========
router.post('/driver/arrive-pickup', authDriver, (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE driver_id = ? AND status = ? ORDER BY created_at DESC LIMIT 1').get(req.userId, 'accepted');
  if (!order) return res.status(400).json({ error: '冇進行中嘅接單' });

  db.prepare("UPDATE orders SET status = 'picked_up', picked_up_at = ? WHERE id = ?").run(Date.now(), order.id);
  const updated = getOrderById(order.id);

  sseHub.publishToOrder(order.id, 'order-picked-up', { order: updated });
  res.json({ order: updated });
});

// ========== 司機到達目的地 ==========
router.post('/driver/complete', authDriver, (req, res) => {
  const { actualFare } = req.body;
  const order = db.prepare('SELECT * FROM orders WHERE driver_id = ? AND status IN (?, ?) ORDER BY created_at DESC LIMIT 1').get(req.userId, 'picked_up', 'accepted');
  if (!order) return res.status(400).json({ error: '冇進行中嘅行程' });

  const fare = actualFare ?? order.estimated_fare;
  db.prepare("UPDATE orders SET status = 'completed', actual_fare = ?, completed_at = ? WHERE id = ?").run(fare, Date.now(), order.id);
  const updated = getOrderById(order.id);

  sseHub.publishToOrder(order.id, 'order-completed', { order: updated });
  res.json({ order: updated });
});

// ========== 司機收入記錄 ==========
router.get('/driver/earnings', authDriver, (req, res) => {
  const rows = db.prepare(`
    SELECT o.*,
           p.name as passenger_name, p.rating as passenger_rating,
           d.name as driver_name, d.plate as driver_plate,
           d.car_model as driver_car_model, d.rating as driver_rating
    FROM orders o
    LEFT JOIN passengers p ON o.passenger_id = p.id
    LEFT JOIN drivers d ON o.driver_id = d.id
    WHERE o.driver_id = ? AND o.status IN ('paid','finished')
    ORDER BY o.created_at DESC
    LIMIT 30
  `).all(req.userId);
  res.json({ orders: rows.map(orderToJson) });
});

// ========== 司機評分乘客 ==========
router.post('/driver/rate', authDriver, (req, res) => {
  const { orderId, rating } = req.body;
  if (!orderId || !rating) return res.status(400).json({ error: '參數唔完整' });

  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND driver_id = ?').get(orderId, req.userId);
  if (!order) return res.status(404).json({ error: '訂單唔存在' });

  db.prepare('UPDATE orders SET passenger_rating = ? WHERE id = ?').run(rating, orderId);

  // 更新乘客平均分
  if (order.passenger_id) {
    const p = db.prepare('SELECT rating, rating_count FROM passengers WHERE id = ?').get(order.passenger_id);
    if (p) {
      const newCount = p.rating_count + 1;
      const newRating = ((p.rating * p.rating_count) + rating) / newCount;
      db.prepare('UPDATE passengers SET rating = ?, rating_count = ? WHERE id = ?').run(
        Math.round(newRating * 10) / 10, newCount, order.passenger_id
      );
    }
  }

  // 檢查雙方評分
  const updated = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (updated.driver_rating) {
    db.prepare("UPDATE orders SET status = 'finished', finished_at = ? WHERE id = ?").run(Date.now(), orderId);
  }

  sseHub.publishToOrder(orderId, 'passenger-rated', { orderId, rating });

  res.json({ ok: true });
});

// ========== 司機上線/落線 ==========
router.post('/driver/online', authDriver, (req, res) => {
  const { online, lat, lng } = req.body;
  db.prepare('UPDATE drivers SET online = ?, current_lat = ?, current_lng = ? WHERE id = ?').run(
    online ? 1 : 0, lat || null, lng || null, req.userId
  );
  res.json({ online: !!online });
});

// ========== 更新位置 ==========
router.post('/driver/location', authDriver, (req, res) => {
  const { lat, lng, orderId } = req.body;
  if (lat == null || lng == null) return res.status(400).json({ error: '位置參數唔完整' });

  db.prepare('UPDATE drivers SET current_lat = ?, current_lng = ? WHERE id = ?').run(lat, lng, req.userId);

  if (orderId) {
    db.prepare('UPDATE orders SET driver_lat = ?, driver_lng = ? WHERE id = ? AND driver_id = ?').run(
      lat, lng, orderId, req.userId
    );
    sseHub.publishToOrder(orderId, 'driver-location', { lat, lng, orderId });
  }

  res.json({ ok: true });
});

router.post('/passenger/location', authPassenger, (req, res) => {
  const { lat, lng, orderId } = req.body;
  if (lat == null || lng == null || !orderId) return res.status(400).json({ error: '參數唔完整' });

  db.prepare('UPDATE orders SET passenger_lat = ?, passenger_lng = ? WHERE id = ? AND passenger_id = ?').run(
    lat, lng, orderId, req.userId
  );
  sseHub.publishToOrder(orderId, 'passenger-location', { lat, lng, orderId });

  res.json({ ok: true });
});

// ========== 付款 ==========
router.post('/passenger/pay', authPassenger, (req, res) => {
  const { method, orderId } = req.body;
  const order = db.prepare('SELECT * FROM orders WHERE id = ? AND passenger_id = ? AND status = ?').get(orderId || '', req.userId, 'completed');
  if (!order) return res.status(400).json({ error: '冇待付款嘅訂單' });

  const now = Date.now();
  db.prepare("UPDATE orders SET status = 'paid', payment_method = ?, paid_at = ? WHERE id = ?").run(
    method || 'cash', now, order.id
  );
  const updated = getOrderById(order.id);

  sseHub.publishToOrder(order.id, 'order-paid', { order: updated });
  sseHub.publishToAdmin('order-paid', { order: updated });

  res.json({ order: updated });
});

// ========== 訂單詳情 ==========
router.get('/:id', (req, res) => {
  const order = getOrderById(req.params.id);
  if (!order) return res.status(404).json({ error: '訂單唔存在' });
  res.json({ order });
});

// ========== SSE 訂閱 ==========
router.get('/stream/order/:orderId', (req, res) => {
  // 乘客同司機都可以睇，唔做嚴格驗證，認 orderId 就夠
  const { orderId } = req.params;
  sseHub.subscribe(req, res, 'order', orderId);
});

router.get('/stream/driver-hall', authDriver, (req, res) => {
  sseHub.subscribe(req, res, 'driver-hall', null);
});

module.exports = router;
