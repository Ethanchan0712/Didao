import { axiosForBackend, scopedStorage, logger } from '@lark-apaas/client-toolkit-lite';

const API_BASE = '/api';

const api = axiosForBackend;

// ========== Auth Storage ==========
const TOKEN_KEY = 'dikdou_token';
const USER_KEY = 'dikdou_user';
const ROLE_KEY = 'dikdou_role';

export function getToken() {
  return scopedStorage.getItem(TOKEN_KEY) || '';
}

export function setAuth(token: string, user: any, role: 'passenger' | 'driver' | 'admin') {
  scopedStorage.setItem(TOKEN_KEY, token);
  scopedStorage.setItem(USER_KEY, JSON.stringify(user));
  scopedStorage.setItem(ROLE_KEY, role);
  // 同時存 raw token 到 localStorage，俾 SSE query param 用（scopedStorage 有 appId 前綴）
  if (role === 'driver') localStorage.setItem('hktaxi_driverToken', token);
  if (role === 'admin') localStorage.setItem('hktaxi_adminToken', token);
  if (role === 'passenger') localStorage.setItem('hktaxi_passengerToken', token);
}

export function clearAuth() {
  scopedStorage.removeItem(TOKEN_KEY);
  scopedStorage.removeItem(USER_KEY);
  scopedStorage.removeItem(ROLE_KEY);
  localStorage.removeItem('hktaxi_driverToken');
  localStorage.removeItem('hktaxi_adminToken');
  localStorage.removeItem('hktaxi_passengerToken');
}

export function getStoredUser(): any {
  const raw = scopedStorage.getItem(USER_KEY);
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

export function getStoredRole(): string {
  return scopedStorage.getItem(ROLE_KEY) || '';
}

// ========== Auth API ==========
export async function passengerRegister(data: { username: string; password: string; name?: string; phone?: string }) {
  const res = await api.post(`${API_BASE}/auth/passenger/register`, data);
  return res.data;
}

export async function passengerLogin(data: { username: string; password: string }) {
  const res = await api.post(`${API_BASE}/auth/passenger/login`, data);
  return res.data;
}

export async function driverRegister(data: {
  username: string; password: string; name?: string; phone?: string;
  plate?: string; carModel?: string; driverLicense?: string;
}) {
  const res = await api.post(`${API_BASE}/auth/driver/register`, data);
  return res.data;
}

export async function driverLogin(data: { username: string; password: string }) {
  const res = await api.post(`${API_BASE}/auth/driver/login`, data);
  return res.data;
}

export async function adminLogin(data: { username: string; password: string }) {
  const res = await api.post(`${API_BASE}/auth/admin/login`, data);
  return res.data;
}

export async function fetchPassengerMe() {
  const res = await api.get(`${API_BASE}/auth/passenger/me`);
  return res.data.user;
}

export async function fetchDriverMe() {
  const res = await api.get(`${API_BASE}/auth/driver/me`);
  return res.data;
}

// ========== Orders API ==========
export async function requestOrder(data: any) {
  const res = await api.post(`${API_BASE}/orders/passenger/request`, data);
  return res.data.order;
}

export async function cancelOrder() {
  const res = await api.post(`${API_BASE}/orders/passenger/cancel`);
  return res.data;
}

export async function getPassengerCurrentOrder() {
  const res = await api.get(`${API_BASE}/orders/passenger/current`);
  return res.data.order;
}

export async function getPassengerHistory() {
  const res = await api.get(`${API_BASE}/orders/passenger/history`);
  return res.data.orders;
}

export async function rateDriver(orderId: string, rating: number) {
  const res = await api.post(`${API_BASE}/orders/passenger/rate`, { orderId, rating });
  return res.data;
}

export async function getDriverHallOrders() {
  const res = await api.get(`${API_BASE}/orders/driver/hall`);
  return res.data.orders;
}

export async function acceptOrder(orderId: string) {
  const res = await api.post(`${API_BASE}/orders/driver/accept/${orderId}`);
  return res.data.order;
}

export async function rejectOrder(orderId: string) {
  const res = await api.post(`${API_BASE}/orders/driver/reject/${orderId}`);
  return res.data;
}

export async function getDriverCurrentOrder() {
  const res = await api.get(`${API_BASE}/orders/driver/current`);
  return res.data.order;
}

export async function driverArrivePickup() {
  const res = await api.post(`${API_BASE}/orders/driver/arrive-pickup`);
  return res.data.order;
}

export async function driverComplete(actualFare: number) {
  const res = await api.post(`${API_BASE}/orders/driver/complete`, { actualFare });
  return res.data.order;
}

export async function getDriverEarnings() {
  const res = await api.get(`${API_BASE}/orders/driver/earnings`);
  return res.data.orders;
}

export async function ratePassenger(orderId: string, rating: number) {
  const res = await api.post(`${API_BASE}/orders/driver/rate`, { orderId, rating });
  return res.data;
}

export async function setDriverOnline(online: boolean, lat?: number, lng?: number) {
  const res = await api.post(`${API_BASE}/orders/driver/online`, { online, lat, lng });
  return res.data;
}

export async function updateDriverLocation(lat: number, lng: number, orderId?: string) {
  const res = await api.post(`${API_BASE}/orders/driver/location`, { lat, lng, orderId });
  return res.data;
}

export async function updatePassengerLocation(lat: number, lng: number, orderId: string) {
  const res = await api.post(`${API_BASE}/orders/passenger/location`, { lat, lng, orderId });
  return res.data;
}

export async function payOrder(orderId: string, method: string) {
  const res = await api.post(`${API_BASE}/orders/passenger/pay`, { orderId, method });
  return res.data.order;
}

export async function getOrderDetail(orderId: string) {
  const res = await api.get(`${API_BASE}/orders/${orderId}`);
  return res.data.order;
}

// ========== Chat API ==========
export async function sendPassengerMessage(orderId: string, text: string) {
  const res = await api.post(`${API_BASE}/chat/passenger/send`, { orderId, text });
  return res.data.message;
}

export async function sendDriverMessage(orderId: string, text: string) {
  const res = await api.post(`${API_BASE}/chat/driver/send`, { orderId, text });
  return res.data.message;
}

export async function getOrderMessages(orderId: string) {
  const res = await api.get(`${API_BASE}/chat/order/${orderId}`);
  return res.data.messages;
}

// ========== Admin API ==========
export async function getAdminStats() {
  const res = await api.get(`${API_BASE}/admin/stats`);
  return res.data;
}

export async function getAdminDrivers(status: string = 'pending') {
  const res = await api.get(`${API_BASE}/admin/drivers?status=${status}`);
  return res.data.drivers;
}

export async function approveDriver(id: string) {
  const res = await api.post(`${API_BASE}/admin/drivers/${id}/approve`);
  return res.data;
}

export async function rejectDriver(id: string, reason: string) {
  const res = await api.post(`${API_BASE}/admin/drivers/${id}/reject`, { reason });
  return res.data;
}

export async function getAdminOrders(status?: string) {
  const url = status ? `${API_BASE}/admin/orders?status=${status}` : `${API_BASE}/admin/orders?status=all`;
  const res = await api.get(url);
  return res.data.orders;
}

// ========== SSE ==========
export function createOrderStream(orderId: string): EventSource {
  return new EventSource(`${API_BASE}/orders/stream/order/${orderId}`);
}

export function createDriverHallStream(token?: string): EventSource {
  const t = token || localStorage.getItem('hktaxi_driverToken') || '';
  return new EventSource(`${API_BASE}/orders/stream/driver-hall?token=${encodeURIComponent(t)}`);
}

export function createAdminStream(token?: string): EventSource {
  const t = token || localStorage.getItem('hktaxi_adminToken') || '';
  return new EventSource(`${API_BASE}/admin/stream?token=${encodeURIComponent(t)}`);
}

export default api;
