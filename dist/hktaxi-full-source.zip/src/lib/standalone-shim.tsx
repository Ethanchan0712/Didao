// Standalone shim for @lark-apaas/client-toolkit-lite — 用於單檔脫離平台運行
// 只實現今次 App 用到嘅功能，其餘返回空

import { NavLink as RRNavLink } from 'react-router-dom';
import { useState, useEffect, type ReactElement, type ReactNode, createElement } from 'react';

const nativeConsole = globalThis.console;

// ============== logger ==============
export const logger = {
  info: (...args: any[]) => nativeConsole.log('[info]', ...args),
  error: (...args: any[]) => nativeConsole.error('[error]', ...args),
  warn: (...args: any[]) => nativeConsole.warn('[warn]', ...args),
};

// ============== scopedStorage ==============
const SCOPE = 'hktaxi_';

function scopedKey(key: string) {
  if (key.startsWith('__app_hktaxi_') || key.startsWith('hktaxi_')) return key;
  return SCOPE + key;
}

export const scopedStorage = {
  getItem(key: string): string | null {
    try {
      return localStorage.getItem(scopedKey(key));
    } catch {
      return null;
    }
  },
  setItem(key: string, value: string): void {
    try {
      localStorage.setItem(scopedKey(key), value);
    } catch {
      // ignore
    }
  },
  removeItem(key: string): void {
    try {
      localStorage.removeItem(scopedKey(key));
    } catch {
      // ignore
    }
  },
};

// ============== NavLink (用 react-router-dom 嘅 NavLink) ==============
export const NavLink = RRNavLink;

// ============== UniversalLink ==============
export function UniversalLink(props: { to: string; children: ReactNode; className?: string }) {
  return createElement(
    'a',
    { href: props.to, className: props.className, target: '_blank', rel: 'noreferrer' },
    props.children
  );
}

// ============== AppContainer ==============
export function AppContainer(props: { children: ReactNode }) {
  return <>{props.children}</>;
}

// ============== ErrorRender ==============
export function ErrorRender(props: { error: unknown; resetErrorBoundary: () => void }): ReactElement {
  return (
    <div style={{ padding: 20, color: '#dc2626', fontFamily: 'sans-serif' }}>
      <h2>出咗錯</h2>
      <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>
        {String(props.error instanceof Error ? props.error.stack : props.error)}
      </pre>
    </div>
  );
}

// ============== Welcome ==============
export function Welcome() {
  return (
    <div style={{ padding: 40, textAlign: 'center' }}>歡迎使用香港飛的</div>
  );
}

// ============== PagePlaceholder ==============
export function PagePlaceholder(props: { title?: string }) {
  return (
    <div style={{ padding: 40, textAlign: 'center', color: '#64748b' }}>
      {props.title || '呢頁仲未整好'}
    </div>
  );
}

// ============== avatarImages ==============
export const avatarImages = {
  avatarImg1: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar1.jpg',
  avatarImg2: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar2.jpg',
  avatarImg3: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar3.jpg',
  avatarImg4: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar4.jpg',
  avatarImg5: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar5.jpg',
  avatarImg6: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar6.jpg',
  avatarImg7: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar7.jpg',
  avatarImg8: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar8.jpg',
  avatarImg9: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar9.jpg',
  avatarImg10: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar10.jpg',
  avatarImg11: 'https://bytednsdoc.com/obj/eden-cn/ptlz_zlp/ljhwZthlaukjlkulzlp/hktaxi/avatar11.jpg',
};

// ============== getAppId ==============
export function getAppId(): string {
  return 'hktaxi-standalone';
}

// ============== resolveAppUrl ==============
export function resolveAppUrl(path: string): string {
  return path;
}

// ============== copyToClipboard ==============
export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

// ============== useIsMobile ==============
export function useIsMobile(): boolean {
  const [isMobile, setIsMobile] = useState(false);
  useEffect(() => {
    const check = () => setIsMobile(window.innerWidth < 768);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);
  return isMobile;
}

// ============== isMobile (utility) ==============
export function isMobile(): boolean {
  return typeof window !== 'undefined' && window.innerWidth < 768;
}

// ============== capabilityClient (mock) ==============
export const capabilityClient = {
  load: () => ({
    call: async () => ({}),
    callStream: async function* () { yield { content: '' }; },
  }),
};
