import path from 'path';
import fs from 'fs';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export const customPlugins = [
  {
    name: 'shim-client-toolkit',
    resolveId(id: string) {
      if (id === '@lark-apaas/client-toolkit-lite') {
        return path.resolve(__dirname, 'src/lib/standalone-shim.tsx');
      }
      if (id === '@lark-apaas/client-toolkit-lite/styles.css') {
        return path.resolve(__dirname, 'src/lib/standalone-shim.css');
      }
      if (id === 'virtual:capabilities' || id === '@lark-apaas/client-capability') {
        return '\0virtual:capabilities-shim';
      }
      return null;
    },
    load(id: string) {
      if (id === '\0virtual:capabilities-shim') {
        return `
export default {};
export const capabilitiesMap = {};
export const capabilities = {};
export const getDataloom = () => ({});
export const capabilityClient = {
  load: () => ({
    call: async () => ({}),
    callStream: async function* () { yield {}; },
  }),
};
`;
      }
      return null;
    },
  },
  {
    name: 'singlefile-inline',
    closeBundle() {
      const outDir = path.resolve(__dirname, 'dist-standalone');
      const htmlPath = path.join(outDir, 'index-standalone.html');
      if (!fs.existsSync(htmlPath)) return;

      let html = fs.readFileSync(htmlPath, 'utf-8');

      // inline JS files
      const jsRegex = /<script[^>]*src="([^"]+\.js[^"]*)"[^>]*><\/script>/g;
      html = html.replace(jsRegex, (match, src) => {
        const cleanSrc = src.replace(/^\.\//, '').split('?')[0];
        const filePath = path.join(outDir, cleanSrc);
        if (fs.existsSync(filePath)) {
          const content = fs.readFileSync(filePath, 'utf-8');
          const isModule = /type=["']module["']/.test(match);
          return isModule
            ? `<script type="module">${content}</script>`
            : `<script>${content}</script>`;
        }
        return match;
      });

      // inline CSS files (rel=stylesheet before href)
      const cssRegex = /<link[^>]*rel=["']stylesheet["'][^>]*href="([^"]+\.css[^"]*)"[^>]*\/?>/gi;
      html = html.replace(cssRegex, (match, href) => {
        const cleanHref = href.replace(/^\.\//, '').split('?')[0];
        const filePath = path.join(outDir, cleanHref);
        if (fs.existsSync(filePath)) {
          const content = fs.readFileSync(filePath, 'utf-8');
          return `<style>${content}</style>`;
        }
        return match;
      });

      // inline CSS files (href before rel=stylesheet)
      const cssRegex2 = /<link[^>]*href="([^"]+\.css[^"]*)"[^>]*rel=["']stylesheet["'][^>]*\/?>/gi;
      html = html.replace(cssRegex2, (match, href) => {
        const cleanHref = href.replace(/^\.\//, '').split('?')[0];
        const filePath = path.join(outDir, cleanHref);
        if (fs.existsSync(filePath)) {
          const content = fs.readFileSync(filePath, 'utf-8');
          return `<style>${content}</style>`;
        }
        return match;
      });

      // 清理 modulepreload link
      html = html.replace(/<link[^>]*rel=["']modulepreload["'][^>]*\/?>/gi, '');

      const finalPath = path.join(outDir, 'index.html');
      fs.writeFileSync(finalPath, html);
      const sizeKB = fs.statSync(finalPath).size / 1024;
      console.log('\n✅ 單檔 HTML 已生成：dist-standalone/index.html');
      console.log(`   檔案大小：${sizeKB.toFixed(1)} KB (${(sizeKB/1024).toFixed(2)} MB)`);
    },
  },
];

export default defineConfig({
  plugins: [react(), tailwindcss(), ...customPlugins],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
      '@shared': path.resolve(__dirname, 'shared'),
    },
  },
  build: {
    outDir: 'dist-standalone',
    rollupOptions: {
      input: {
        main: path.resolve(__dirname, 'index-standalone.html'),
      },
    },
  },
  base: './',
});
